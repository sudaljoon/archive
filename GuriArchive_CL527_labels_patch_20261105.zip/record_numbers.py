"""Immutable display numbers, separate from IDs used by records, files and loans."""
import hashlib
import json
import re

import core
import activity_log

FIELDS=('managementNo','legacyManagementNo','managementNumberAssignedAt')
SCHEMA='''
CREATE TABLE IF NOT EXISTS record_management_numbers(
 record_id TEXT PRIMARY KEY, management_no TEXT NOT NULL UNIQUE,
 production_year INTEGER NOT NULL, department TEXT NOT NULL, sequence INTEGER NOT NULL,
 assigned_at TEXT NOT NULL, assigned_by TEXT NOT NULL,
 UNIQUE(production_year,sequence));
CREATE TABLE IF NOT EXISTS record_number_sequences(
 production_year INTEGER PRIMARY KEY, last_value INTEGER NOT NULL CHECK(last_value>=0));
'''


def ensure_tables(cfg):
    with core.dbconnect(cfg) as db:db.executescript(SCHEMA)


def basis(record):
    year=record.get('year');dept=record.get('dept')
    if isinstance(year,bool) or not isinstance(year,(str,int)) or not re.fullmatch(r'[0-9]{4}',str(year)) or not 1900<=int(year)<=2100:
        raise core.UserError('생산·처리완결연도(1900~2100)를 확인해 주세요.')
    if not isinstance(dept,str) or not dept.strip() or len(dept.strip())>80 or any(ord(c)<32 for c in dept):
        raise core.UserError('생산부서명을 확인해 주세요. (80자 이하, 줄바꿈 제외)')
    return int(year),dept.strip()


def format_number(year,dept,sequence):
    if not 1<=sequence<=9999999:raise core.UserError('해당 연도의 7자리 순번 발급 한도를 초과했습니다.',409)
    return f'{year}-{dept}-기록물철-{sequence:07d}'


def mappings(db):
    return {r['record_id']:dict(r) for r in db.execute('SELECT * FROM record_management_numbers')}


def fields(row):
    return {'managementNo':row['management_no'],'legacyManagementNo':row['record_id'],'managementNumberAssignedAt':row['assigned_at']}


def decorate(db,doc,strict=False):
    known=mappings(db)
    for record in doc.get('records',[]):
        if not isinstance(record,dict):continue
        row=known.get(record.get('id'))
        if row:
            if strict and record.get('managementNo') not in (None,'',row['management_no']):
                raise core.UserError('이미 부여한 내부관리번호는 변경할 수 없습니다.',409)
            record.update(fields(row))
        else:
            if strict and record.get('managementNo'):raise core.UserError('내부관리번호는 서버에서만 부여할 수 있습니다.',409)
            for key in FIELDS:record.pop(key,None)
    return doc


def highwater(db,year):
    row=db.execute('SELECT last_value FROM record_number_sequences WHERE production_year=?',(year,)).fetchone()
    maximum=db.execute('SELECT MAX(sequence) n FROM record_management_numbers WHERE production_year=?',(year,)).fetchone()['n'] or 0
    return max(row['last_value'] if row else 0,maximum)


def register(db,record,user,number=None):
    existing=db.execute('SELECT * FROM record_management_numbers WHERE record_id=?',(record['id'],)).fetchone()
    if existing:return dict(existing)
    if number:
        if not isinstance(number,str):raise core.UserError('백업 내부관리번호는 문자열이어야 합니다.')
        match=re.fullmatch(r'([0-9]{4})-(.+)-기록물철-([0-9]{7})',number)
        if not match:raise core.UserError('백업의 내부관리번호 형식을 확인해 주세요.')
        year,dept,seq=int(match[1]),match[2],int(match[3])
        basis({'year':year,'dept':dept});format_number(year,dept,seq)
        # Never let a restored record consume a number already reserved for another ID.
        conflict=db.execute('SELECT record_id FROM record_management_numbers WHERE management_no=? OR (production_year=? AND sequence=?)',(number,year,seq)).fetchone()
        if conflict:raise core.UserError('백업 번호가 기존 기록물에 이미 부여되어 있습니다. 기존 번호를 보존하기 위해 복원을 중단했습니다.',409)
    else:
        year,dept=basis(record);seq=highwater(db,year)+1;number=format_number(year,dept,seq)
    db.execute('INSERT INTO record_management_numbers VALUES(?,?,?,?,?,?,?)',(record['id'],number,year,dept,seq,core.now(),user))
    last=max(highwater(db,year),seq)
    db.execute('INSERT INTO record_number_sequences VALUES(?,?) ON CONFLICT(production_year) DO UPDATE SET last_value=MAX(last_value,excluded.last_value)',(year,last))
    core.audit(db,user,'내부관리번호 부여','record',record['id'],record['id']+' → '+number)
    return dict(db.execute('SELECT * FROM record_management_numbers WHERE record_id=?',(record['id'],)).fetchone())


def import_restore(db,doc,user):
    if not isinstance(doc,dict) or not isinstance(doc.get('records'),list):return
    for record in doc['records']:
        if not isinstance(record,dict) or not isinstance(record.get('id'),str):continue
        if record.get('managementNo') and not db.execute('SELECT 1 FROM record_management_numbers WHERE record_id=?',(record['id'],)).fetchone():
            register(db,record,user,record['managementNo'])


def allocate_new(db,old,doc,user,restore=False):
    old_ids={r['id'] for r in old['records']}
    for record in doc['records']:
        if record['id'] not in old_ids:
            if not restore and db.execute('SELECT 1 FROM record_management_numbers WHERE record_id=?',(record['id'],)).fetchone():
                raise core.UserError('이미 사용한 시스템 ID입니다. 새로고침 후 다시 등록하세요.',409)
            register(db,record,user)
    return decorate(db,doc,strict=True)


def preview(db):
    state=db.execute('SELECT * FROM archive_state WHERE id=1').fetchone()
    doc=json.loads(state['json_data']);known=mappings(db)
    pending=[];invalid=[];counters={}
    # Stable order for a repeatable review; numbering is shared by all departments in a year.
    for r in sorted(doc['records'],key=lambda r:(str(r.get('year','')),str(r.get('created','')),r['id'])):
        if r['id'] in known:continue
        item={'id':r['id'],'title':r.get('title',''),'old_number':r['id'],'year':r.get('year',''),'department':r.get('dept','')}
        try:
            year,dept=basis(r)
            if year not in counters:counters[year]=highwater(db,year)
            counters[year]+=1
            item['new_number']=format_number(year,dept,counters[year]);item['error']='';pending.append(item)
        except core.UserError as e:
            item['new_number']='';item['error']=str(e);invalid.append(item)
    batch=pending[:1000]
    signature=json.dumps({'revision':state['revision'],'items':batch},sort_keys=True,ensure_ascii=False)
    return {'revision':state['revision'],'token':hashlib.sha256(signature.encode()).hexdigest(),
            'items':batch,'invalid':invalid,'assigned_count':sum(r['id'] in known for r in doc['records']),
            'eligible_count':len(pending),'remaining_count':max(0,len(pending)-len(batch)),
            'rule':'생산·처리완결연도-생산부서명-기록물철-7자리 연도별 전체 순번'}


def handler_get(handler):
    core.confirm_role(handler,'admin')
    with core.dbconnect(handler.cfg) as db:
        db.execute('BEGIN')
        result=preview(db)
    return handler.json_out(result)


def handler_apply(handler):
    ses=handler.check_csrf()
    if ses['role']!='admin':raise core.UserError('관리자만 내부관리번호를 부여할 수 있습니다.',403)
    payload=handler.json_in()
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        db.execute('BEGIN IMMEDIATE');plan=preview(db)
        if payload.get('token')!=plan['token'] or type(payload.get('revision')) is not int or payload.get('revision')!=plan['revision']:
            raise core.UserError('자료 또는 번호 발급 상태가 변경되었습니다. 미리보기를 다시 확인해 주세요.',409)
        if not plan['items']:raise core.UserError('이번에 번호를 부여할 기록물이 없습니다.',409)
        state=db.execute('SELECT json_data FROM archive_state WHERE id=1').fetchone()
        by_id={r['id']:r for r in json.loads(state['json_data'])['records']}
        for item in plan['items']:
            row=register(db,by_id[item['id']],ses['user'])
            if row['management_no']!=item['new_number']:raise core.UserError('번호가 변경되었습니다. 다시 미리보기 해주세요.',409)
            activity_log.write(handler,'관리자 작업','내부관리번호 부여',ses=ses,kind='record',target=item['id'],title=item['title'],detail=item['old_number']+' → '+row['management_no'],db=db)
        # Existing record metadata and every relationship remain byte-for-byte intact.
        db.execute('UPDATE archive_state SET revision=revision+1,updated_at=?,updated_by=? WHERE id=1',(core.now(),ses['user']))
    return handler.json_out({'ok':True,'assigned_count':len(plan['items']),'remaining_count':plan['remaining_count']})


def system_id_sequence(db,doc):
    ids=[r.get('id','') for r in doc.get('records',[])]
    ids.extend(r['record_id'] for r in db.execute('SELECT record_id FROM record_management_numbers'))
    return max((int(m[1]) for value in ids if isinstance(value,str) and (m:=re.fullmatch(r'GR-([0-9]+)',value))),default=0)
