"""Number allocation and immutable relationships: every write uses a temporary DB."""
import copy
import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

import core
import server
import record_numbers as nums
import access_requests
from test_photo_records import FakeHandler


class RecordNumberTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='guri-record-numbers-');self.addCleanup(self.temp.cleanup)
        self.cfg={'db_path':self.temp.name+'/test.sqlite3','media_dir':self.temp.name+'/media'}
        server.initialize_db(self.cfg);self.admin=FakeHandler(self.cfg);self.viewer=FakeHandler(self.cfg,'viewer')
        self.records=[{'id':'GR-0001','title':'2026 계획철','dept':'경영기획팀','year':2026,'created':'2026-01-01','disclosure':'공개','original':'생산-001','box':'BOX-001','location':'A-01-01-01'},
                      {'id':'GR-0002','title':'2026 회계철','dept':'재무회계팀','year':2026,'created':'2026-02-01','disclosure':'비공개'},
                      {'id':'GR-0003','title':'2027 계획철','dept':'경영기획팀','year':2027,'created':'2027-01-01','disclosure':'공개'}]
        self.state={**server.EMPTY,'records':copy.deepcopy(self.records),'loans':[{'id':'L-1','recordId':'GR-0001','returnDate':''}],'inspections':[{'id':'I-1','recordId':'GR-0001'}]}
        self.set_state(self.state)
        self.initial=self.raw_state()

    def set_state(self,state):
        with core.dbconnect(self.cfg) as db:db.execute('UPDATE archive_state SET json_data=? WHERE id=1',(json.dumps(state,ensure_ascii=False),))

    def raw_state(self):
        with core.dbconnect(self.cfg) as db:return db.execute('SELECT json_data FROM archive_state WHERE id=1').fetchone()[0]

    def snapshot(self):
        self.admin.path='/api/v2/state';return server.FullArchiveHandler.route_get(self.admin)

    def preview(self):return nums.handler_get(self.admin)

    def apply(self,plan=None):
        plan=plan or self.preview();self.admin.payload={'token':plan['token'],'revision':plan['revision']};return nums.handler_apply(self.admin)

    def put(self,doc,revision=None,restore=False):
        if revision is None:revision=self.snapshot()['revision']
        self.admin.path='/api/v2/state';self.admin.headers={'Content-Type':'application/json'}
        self.admin.raw=json.dumps({'data':doc,'revision':revision,'restore':restore}).encode()
        with patch.object(server.pdf_ocr_search,'queue_auto_index'),patch.object(self.admin,'json_out') as output:
            server.FullArchiveHandler.route_put(self.admin)
            return output.call_args.args[0]

    def test_preview_is_read_only_and_startup_does_not_renumber(self):
        server.initialize_db(self.cfg);p=self.preview()
        self.assertEqual(self.raw_state(),self.initial)
        self.assertEqual(self.preview()['token'],p['token'])
        with core.dbconnect(self.cfg) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM record_management_numbers').fetchone()[0],0)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM record_number_sequences').fetchone()[0],0)

    def test_annual_sequence_shared_by_korean_departments_and_resets_by_year(self):
        p=self.preview();self.apply(p)
        rows=self.snapshot()['data']['records']
        self.assertEqual([r['managementNo'] for r in rows],['2026-경영기획팀-기록물철-0000001','2026-재무회계팀-기록물철-0000002','2027-경영기획팀-기록물철-0000001'])
        self.assertEqual([r['id'] for r in rows],['GR-0001','GR-0002','GR-0003'])
        self.assertEqual(self.raw_state(),self.initial)
        self.assertEqual(self.preview()['eligible_count'],0)

    def test_existing_pdf_request_photo_link_and_loan_relationships_are_intact(self):
        with core.dbconnect(self.cfg) as db:
            db.execute("INSERT INTO record_pdf_files VALUES(?,?,?,?,?,?,?,?)",('a'*32,'GR-0001','scan.pdf','a'*32+'.pdf',12,'hash',core.now(),'test_admin'))
            db.execute("INSERT INTO access_requests(id,record_id,applicant,method,reason,requested_at) VALUES('request','GR-0001','test_admin','online','test reason',?)",(core.now(),))
        self.apply();new=self.snapshot()['data']
        self.assertEqual(new['loans'],self.state['loans']);self.assertEqual(new['inspections'],self.state['inspections'])
        with core.dbconnect(self.cfg) as db:
            self.assertEqual(db.execute('SELECT record_id FROM record_pdf_files').fetchone()[0],'GR-0001')
            self.assertEqual(db.execute('SELECT record_id FROM access_requests').fetchone()[0],'GR-0001')
        self.assertEqual(access_requests.catalog(self.viewer)['records'][0]['managementNo'],'2026-경영기획팀-기록물철-0000001')
        req=access_requests.listing(self.admin)['requests'][0]
        self.assertEqual(req['record_management_no'],'2026-경영기획팀-기록물철-0000001')

    def test_new_record_put_gets_number_and_form_response_map(self):
        doc=copy.deepcopy(self.state);doc['records'].append({'id':'GR-0004','title':'추가 기록물','dept':'시설관리팀','year':2026})
        result=self.put(doc)
        self.assertEqual(result['managementNumbers']['GR-0004']['managementNo'],'2026-시설관리팀-기록물철-0000001')
        self.assertFalse(self.snapshot()['data']['records'][0].get('managementNo'))
        self.apply();self.assertEqual(self.snapshot()['data']['records'][0]['managementNo'],'2026-경영기획팀-기록물철-0000002')

    def test_number_stays_fixed_after_department_and_year_changes(self):
        self.apply();doc=self.snapshot()['data'];before=doc['records'][0]['managementNo']
        doc['records'][0].update(dept='기록정보팀',year=2028)
        self.put(doc)
        self.assertEqual(self.snapshot()['data']['records'][0]['managementNo'],before)

    def test_client_cannot_edit_existing_or_invent_new_numbers(self):
        self.apply();doc=self.snapshot()['data'];doc['records'][0]['managementNo']='2026-가짜부서-기록물철-0000009'
        with self.assertRaises(core.UserError) as e:self.put(doc)
        self.assertEqual(e.exception.code,409)
        doc=self.snapshot()['data'];doc['records'].append({'id':'FAKE','title':'가짜','year':2026,'dept':'시설팀','managementNo':'2026-시설팀-기록물철-0000099'})
        with self.assertRaises(core.UserError):self.put(doc)

    def test_invalid_legacy_basis_is_reported_and_skipped(self):
        doc=copy.deepcopy(self.state);doc['records'].append({'id':'BAD','title':'확인 필요','year':'','dept':''});self.set_state(doc)
        plan=self.preview();self.assertEqual(len(plan['invalid']),1);self.assertEqual(plan['eligible_count'],3)
        self.apply(plan);self.assertFalse(self.snapshot()['data']['records'][-1].get('managementNo'))

    def test_invalid_new_registration_rolls_back_every_allocation(self):
        doc=copy.deepcopy(self.state)
        doc['records'] += [{'id':'NEW1','title':'valid','year':2026,'dept':'기획팀'},{'id':'NEW2','title':'invalid','year':True,'dept':'기획팀'}]
        with self.assertRaises(core.UserError):self.put(doc)
        self.assertEqual(self.raw_state(),self.initial)
        with core.dbconnect(self.cfg) as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM record_management_numbers').fetchone()[0],0)

    def test_stale_preview_and_old_state_revision_are_rejected(self):
        plan=self.preview();old=self.snapshot();self.apply(plan)
        with self.assertRaises(core.UserError) as e:self.apply(plan)
        self.assertEqual(e.exception.code,409)
        with self.assertRaises(core.UserError):self.put(old['data'],old['revision'])

    def test_concurrent_apply_issues_each_number_once(self):
        plan=self.preview()
        def work(_):
            h=FakeHandler(self.cfg);h.payload={'token':plan['token'],'revision':plan['revision']}
            try:return nums.handler_apply(h)['code']
            except core.UserError as e:return e.code
        with ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(work,range(2)))
        self.assertEqual(sorted(result),[200,409])
        with core.dbconnect(self.cfg) as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM record_management_numbers').fetchone()[0],3)

    def test_restoration_retains_reserved_numbers_even_when_record_was_absent(self):
        self.apply();original=self.snapshot()['data']
        self.put({**server.EMPTY},restore=True)
        new={**server.EMPTY,'records':[{'id':'NEW','title':'복원 후 신규','year':2026,'dept':'기획팀'}]}
        self.put(new);self.assertEqual(self.snapshot()['data']['records'][0]['managementNo'],'2026-기획팀-기록물철-0000003')
        self.put(original,restore=True)
        self.assertEqual(self.snapshot()['data']['records'][0]['managementNo'],'2026-경영기획팀-기록물철-0000001')

    def test_backup_number_import_advances_counter_and_conflicts_fail_atomically(self):
        doc=copy.deepcopy(self.state);doc['records'][0]['managementNo']='2026-경영기획팀-기록물철-0000100'
        self.put(doc,restore=True)
        doc=self.snapshot()['data'];doc['records'].append({'id':'NEW','title':'신규','year':2026,'dept':'재무팀'})
        self.put(doc);self.assertEqual(self.snapshot()['data']['records'][-1]['managementNo'],'2026-재무팀-기록물철-0000101')
        doc=self.snapshot()['data'];doc['records'].append({'id':'CONFLICT','title':'충돌','year':2026,'dept':'타부서','managementNo':'2026-타부서-기록물철-0000100'})
        with self.assertRaises(core.UserError):self.put(doc,restore=True)
        self.assertEqual(len(self.snapshot()['data']['records']),4)

    def test_disposed_record_number_does_not_break_frozen_record_validation(self):
        doc=copy.deepcopy(self.state);doc['records'][0]['evaluation']={'decision':'폐기 결정','executedAt':'2026-01-01'};self.set_state(doc)
        self.apply();snap=self.snapshot();self.put(snap['data'],snap['revision'])
        self.assertEqual(self.snapshot()['data']['records'][0]['evaluation'],doc['records'][0]['evaluation'])

    def test_retired_system_id_cannot_be_reused_for_a_new_record(self):
        self.apply();self.put({**server.EMPTY},restore=True)
        self.assertEqual(self.snapshot()['recordIdSequence'],3)
        doc={**server.EMPTY,'records':[{'id':'GR-0001','title':'another record','year':2026,'dept':'기획팀'}]}
        with self.assertRaises(core.UserError) as error:self.put(doc)
        self.assertEqual(error.exception.code,409)
        self.assertEqual(self.snapshot()['data']['records'],[])

    def test_numbering_is_admin_only_and_has_no_seven_digit_overflow(self):
        with self.assertRaises(core.UserError):nums.handler_get(self.viewer)
        self.viewer.payload={'token':'x','revision':1}
        with self.assertRaises(core.UserError):nums.handler_apply(self.viewer)
        with core.dbconnect(self.cfg) as db:db.execute('INSERT INTO record_number_sequences VALUES(2026,9999999)')
        plan=self.preview();self.assertEqual(len(plan['invalid']),2)
        self.apply(plan)
        self.assertFalse(self.snapshot()['data']['records'][0].get('managementNo'))


if __name__=='__main__':unittest.main()
