"""CL527 print layout in millimetres. Read-only labels, no data or numbering changes."""
import html
import json
import math
import re
from urllib.parse import parse_qs, urlsplit

import core
import activity_log
import record_numbers

SPEC={'model':'아이라벨 CL527','paper_width_mm':210,'paper_height_mm':297,
      'columns':2,'rows':7,'slots':14,'label_width_mm':80,'label_height_mm':40,
      'left_mm':20,'right_mm':20,'top_mm':8,'bottom_mm':9,'column_gap_mm':10,'row_gap_mm':0,'radius_mm':2}


def records(cfg):
    with core.dbconnect(cfg) as db:
        db.execute('BEGIN')
        row=db.execute('SELECT json_data FROM archive_state WHERE id=1').fetchone()
        doc=record_numbers.decorate(db,json.loads(row['json_data']))
    result=[]
    keys=('id','managementNo','title','dept','year','retention','box','location')
    for r in doc['records']:
        ev=r.get('evaluation') or {}
        if ev.get('decision')=='폐기 결정' and ev.get('executedAt'):continue
        result.append({key:r.get(key,'') for key in keys})
    return result


def integer(value,low,high,label):
    if isinstance(value,bool) or not isinstance(value,(str,int)) or not re.fullmatch(r'[0-9]+',str(value)):raise core.UserError(label+'는 정수로 입력하세요.')
    n=int(value)
    if not low<=n<=high:raise core.UserError(f'{label} 범위는 {low}~{high}입니다.')
    return n


def offset(value,label):
    try:n=float(value)
    except (TypeError,ValueError):raise core.UserError(label+' 보정값을 확인하세요.')
    if not math.isfinite(n) or not -5<=n<=5:raise core.UserError(label+' 보정은 -5~5mm 범위입니다.')
    return round(n,2)


def plan(cfg,params):
    def arg(key,default=''):return params.get(key,[default])[0]
    dx,dy=offset(arg('dx','0'),'좌우'),offset(arg('dy','0'),'상하')
    trial=arg('test','0')=='1'
    start=1 if trial else integer(arg('start','1'),1,14,'출력 시작 칸')
    copies=1 if trial else integer(arg('copies','1'),1,100,'기록물별 출력 매수')
    try:
        ids=[] if trial else json.loads(arg('ids','[]'));used=[] if trial else json.loads(arg('used','[]'))
    except (ValueError,TypeError):raise core.UserError('선택 기록물 또는 사용한 칸 정보를 확인하세요.')
    if not isinstance(ids,list) or len(ids)>200 or any(not isinstance(i,str) or len(i)>90 for i in ids) or len(ids)!=len(set(ids)):
        raise core.UserError('기록물은 중복 없이 최대 200건까지 선택하세요.')
    if not isinstance(used,list) or any(type(i) is not int or not 1<=i<=14 for i in used) or len(used)!=len(set(used)):
        raise core.UserError('사용한 칸은 1~14번 중에서 선택하세요.')
    if trial:
        chosen=[{'id':'test-'+str(i),'managementNo':'CL527 시험출력','title':f'{i}번 칸 · 위치 확인','dept':'구리농수산물공사','year':'','retention':'','box':'','location':''} for i in range(1,15)]
        start=1;used=[];copies=1
    else:
        available={r['id']:r for r in records(cfg)}
        if not ids:raise core.UserError('출력할 기록물철을 선택하세요.')
        if any(i not in available for i in ids):raise core.UserError('선택한 기록물이 없거나 폐기 완료 상태입니다. 목록을 새로 조회하세요.',409)
        chosen=[available[i] for i in ids for _ in range(copies)]
    if len(chosen)>200:raise core.UserError('한 번에 최대 200장 라벨을 출력할 수 있습니다. 선택 건수 또는 매수를 줄여 주세요.')
    first=[i for i in range(start,15) if i not in used]
    if not first:raise core.UserError('첫 장에 출력 가능한 칸이 없습니다. 시작 칸·사용한 칸을 변경하거나 새 용지를 선택하세요.')
    pages=[];position=0;remaining=chosen
    while remaining:
        slots=first if not pages else list(range(1,15))
        page={'page':len(pages)+1,'labels':[]}
        for slot,record in zip(slots,remaining):
            row,col=divmod(slot-1,2)
            page['labels'].append({'slot':slot,'x_mm':20+col*90+dx,'y_mm':8+row*40+dy,'record':record,'order':position+1})
            position+=1
        remaining=remaining[len(page['labels']):];pages.append(page)
    return {'spec':SPEC,'pages':pages,'total_labels':len(chosen),'page_count':len(pages),'start':start,
            'used':used,'dx':dx,'dy':dy,'trial':trial,
            'legacy_count':0 if trial else sum(not r.get('managementNo') for r in chosen)}


def listing(handler):
    core.confirm_role(handler,'admin')
    return handler.json_out({'records':records(handler.cfg),'spec':SPEC})


def layout(handler):
    core.confirm_role(handler,'admin')
    return handler.json_out(plan(handler.cfg,parse_qs(urlsplit(handler.path).query)))


def print_document(handler):
    ses=core.confirm_role(handler,'admin')
    job=plan(handler.cfg,parse_qs(urlsplit(handler.path).query))
    esc=lambda value:html.escape(str(value or ''),quote=True)
    sheets=[]
    for page in job['pages']:
        labels=[]
        for item in page['labels']:
            r=item['record'];retention=str(r.get('retention',''))
            if retention.isdigit():retention+='년'
            classes='label trial' if job['trial'] else 'label'
            title=esc(r['title'])
            labels.append(f'''<article class="{classes}" data-slot="{item['slot']}" data-record-id="{esc(r['id'])}"
                style="left:{item['x_mm']}mm;top:{item['y_mm']}mm">
                <header>구리농수산물공사 <span>기록물철</span></header>
                <div class="number" data-fit="number">{esc(r.get('managementNo') or r['id'])}</div>
                <div class="title" data-fit="title" title="{title}">{title}</div>
                <div class="meta">생산부서: {esc(r.get('dept'))} · {esc(r.get('year'))}</div>
                <div class="meta">보존기간: {esc(retention)} · 상자: {esc(r.get('box') or '미배정')}</div>
                <div class="meta">보존위치: {esc(r.get('location') or '미배정')}</div>
                {'<aside>'+str(item['slot'])+'번 칸 · 80 × 40mm</aside>' if job['trial'] else ''}</article>''')
        sheets.append(f'<section class="sheet" data-page="{page["page"]}">'+''.join(labels)+'</section>')
    title='CL527 일반용지 시험출력' if job['trial'] else 'CL527 기록물철 라벨 출력'
    doc=f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title>{title}</title><link rel="stylesheet" href="/labels-print.css?v=20261105cl527"></head><body>
        <nav class="print-controls"><strong>{title}</strong><span>{job['total_labels']}개 · A4 {job['page_count']}장</span>
        <button id="print" disabled>글꼴·배치 확인 중</button><p>용지 A4 · 배율 100% / 실제 크기 · 여백 없음 · 머리글/바닥글 끄기 · 페이지 맞춤 사용 안 함. 먼저 일반 용지에 시험 출력하세요.</p>
        <p id="fitWarning" role="alert"></p></nav>{''.join(sheets)}<script src="/labels-print.js?v=20261105cl527"></script></body></html>'''
    activity_log.write(handler,'관리자 작업','라벨 출력문서 생성',ses=ses,kind='label',target='CL527',
                       detail=f"라벨 {job['total_labels']}개 / 용지 {job['page_count']}장 / 시작 {job['start']} / 보정 {job['dx']},{job['dy']}mm / 시험 {job['trial']}")
    return handler.response_bytes(doc.encode('utf-8'),ctype='text/html; charset=utf-8')
