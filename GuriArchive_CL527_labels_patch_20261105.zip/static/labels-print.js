'use strict';
(async()=>{
 const button=document.getElementById('print'),warning=document.getElementById('fitWarning');
 try{
  await document.fonts.load('12px GuriLabel','구리농수산물공사');
  await document.fonts.ready;
  if(!document.fonts.check('12px GuriLabel'))throw Error('한글 글꼴을 불러오지 못했습니다. watermark_assets 폴더를 확인하고 새로고침해 주세요.');
  let abbreviated=0,invalid=0;
  document.querySelectorAll('[data-fit]').forEach(el=>{
   let size=parseFloat(getComputedStyle(el).fontSize),minimum=el.dataset.fit==='number'?7.3:8;
   while((el.scrollHeight>el.clientHeight||el.scrollWidth>el.clientWidth)&&size>minimum){size=Math.max(minimum,size-.2);el.style.fontSize=size+'px'}
   if(el.scrollHeight>el.clientHeight||el.scrollWidth>el.clientWidth){
    if(el.dataset.fit==='number'){invalid++;return}
    // Keep the immutable ID in full; long titles use a visibly abbreviated label caption.
    const full=el.textContent;let end=full.length;
    while(end>0&&(el.scrollHeight>el.clientHeight||el.scrollWidth>el.clientWidth)){end--;el.textContent=full.slice(0,end)+'…'}
    abbreviated++;
   }
  });
  if(invalid)throw Error('내부관리번호가 라벨 영역을 초과한 '+invalid+'건이 있습니다. 번호 전체 표시를 위해 인쇄를 중단했습니다.');
  if(abbreviated)warning.textContent='긴 기록물철명 '+abbreviated+'개는 라벨에 일부 생략(…) 표시됩니다. 내부관리번호는 전체 표시됩니다.';
  button.disabled=false;button.textContent='인쇄 / PDF 저장';button.onclick=()=>window.print();
  document.documentElement.dataset.ready='true';
 }catch(e){warning.textContent=e.message;button.textContent='배치 확인 필요';document.documentElement.dataset.ready='error'}
})();
