"""CL527 geometry and selection checks, with temporary data only."""
import copy
import json
import tempfile
import unittest
from urllib.parse import urlencode

import core
import server
import record_labels as labels
from test_photo_records import FakeHandler


class RecordLabelTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='guri-cl527-test-');self.addCleanup(self.temp.cleanup)
        self.cfg={'db_path':self.temp.name+'/test.sqlite3','media_dir':self.temp.name+'/media'}
        server.initialize_db(self.cfg);self.a=FakeHandler(self.cfg);self.v=FakeHandler(self.cfg,'viewer')
        records=[{'id':f'GR-{i:04}','title':f'기록물철 {i}','dept':'경영기획팀','year':2026,'retention':'10','box':'BOX-1','location':'A-01-01-01'} for i in range(1,31)]
        self.doc={**server.EMPTY,'records':records}
        self.raw=json.dumps(self.doc,ensure_ascii=False)
        with core.dbconnect(self.cfg) as db:db.execute('UPDATE archive_state SET json_data=? WHERE id=1',(self.raw,))

    def params(self,count=1,**args):
        values={'ids':json.dumps([r['id'] for r in self.doc['records'][:count]]),'start':'3','used':'[]','copies':'1','dx':'0','dy':'0',**args}
        return {k:[str(v)] for k,v in values.items()}

    def test_spec_matches_supplied_cl527_dimensions(self):
        s=labels.SPEC
        self.assertEqual((s['columns'],s['rows'],s['slots']),(2,7,14))
        self.assertEqual(s['left_mm']+s['label_width_mm']*2+s['column_gap_mm']+s['right_mm'],210)
        self.assertEqual(s['top_mm']+s['label_height_mm']*7+s['bottom_mm'],297)

    def test_one_label_starts_in_third_slot_second_row_left(self):
        p=labels.plan(self.cfg,self.params())
        self.assertEqual(p['page_count'],1);self.assertEqual(p['total_labels'],1)
        self.assertEqual((p['pages'][0]['labels'][0]['slot'],p['pages'][0]['labels'][0]['x_mm'],p['pages'][0]['labels'][0]['y_mm']),(3,20,48))

    def test_first_page_start_only_and_next_page_fresh(self):
        p=labels.plan(self.cfg,self.params(13));self.assertEqual(p['page_count'],2)
        self.assertEqual([r['slot'] for r in p['pages'][0]['labels']],list(range(3,15)))
        self.assertEqual([r['slot'] for r in p['pages'][1]['labels']],[1])
        self.assertEqual(p['pages'][1]['labels'][0]['y_mm'],8)

    def test_used_slots_skipped_on_first_page_only(self):
        p=labels.plan(self.cfg,self.params(14,used='[3,5,9]'))
        self.assertEqual([r['slot'] for r in p['pages'][0]['labels']],[4,6,7,8,10,11,12,13,14])
        self.assertEqual([r['slot'] for r in p['pages'][1]['labels']],[1,2,3,4,5])

    def test_repeat_copies_and_position_calibration(self):
        p=labels.plan(self.cfg,self.params(2,copies='2',dx='1.2',dy='-0.7'))
        self.assertEqual([r['record']['id'] for r in p['pages'][0]['labels']],['GR-0001','GR-0001','GR-0002','GR-0002'])
        self.assertEqual(p['pages'][0]['labels'][0]['x_mm'],21.2)
        self.assertEqual(p['pages'][0]['labels'][0]['y_mm'],47.3)

    def test_unusable_first_page_and_invalid_inputs_are_rejected(self):
        bad=[{'start':'0'},{'start':'15'},{'copies':'1.5'},{'dx':'NaN'},{'dy':'Infinity'},{'dx':'5.1'},
             {'used':'[true]'},{'used':'[1,1]'},{'used':'[15]'},{'used':'"test"'},
             {'ids':'["GR-0001","GR-0001"]'},{'ids':'["missing"]'},{'ids':'[]'},
             {'used':json.dumps(list(range(1,15)))},{'copies':'100'}]
        for case in bad:
            with self.subTest(case=case),self.assertRaises(core.UserError):labels.plan(self.cfg,self.params(3,**case))

    def test_trial_is_all_fourteen_slots_without_record_selection(self):
        p=labels.plan(self.cfg,self.params(0,test='1',used=json.dumps(list(range(1,15))),copies='0',start='14'))
        self.assertTrue(p['trial']);self.assertEqual(p['total_labels'],14)
        self.assertEqual([r['slot'] for r in p['pages'][0]['labels']],list(range(1,15)))

    def test_html_escapes_titles_and_never_modifies_records_or_numbers(self):
        self.doc['records'][0]['title']='<script>alert(1)</script>'
        with core.dbconnect(self.cfg) as db:db.execute('UPDATE archive_state SET json_data=? WHERE id=1',(json.dumps(self.doc),))
        self.a.path='/api/v2/labels/print?'+urlencode({k:v[0] for k,v in self.params().items()})
        page=labels.print_document(self.a)['data'].decode()
        self.assertIn('&lt;script&gt;',page);self.assertNotIn('<script>alert(1)',page)
        self.assertIn('left:20.0mm;top:48.0mm',page)
        with core.dbconnect(self.cfg) as db:
            self.assertEqual(json.loads(db.execute('SELECT json_data FROM archive_state').fetchone()[0]),self.doc)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM record_management_numbers').fetchone()[0],0)
            self.assertEqual(db.execute("SELECT COUNT(*) FROM activity_events WHERE event='라벨 출력문서 생성'").fetchone()[0],1)

    def test_admin_guards_include_assets_and_print_routes(self):
        for path in ('/labels','/labels.js','/labels-print.css','/labels-font.otf','/api/v2/labels/records','/api/v2/labels/layout','/api/v2/labels/print'):
            self.v.path=path
            with self.subTest(path=path),self.assertRaises(core.UserError) as e:server.FullArchiveHandler.route_get(self.v)
            self.assertEqual(e.exception.code,403)

    def test_disposed_records_cannot_be_selected_for_printing(self):
        self.doc['records'][0]['evaluation']={'decision':'폐기 결정','executedAt':'2026-01-01'}
        with core.dbconnect(self.cfg) as db:db.execute('UPDATE archive_state SET json_data=? WHERE id=1',(json.dumps(self.doc),))
        self.assertNotIn('GR-0001',{r['id'] for r in labels.records(self.cfg)})
        with self.assertRaises(core.UserError):labels.plan(self.cfg,self.params())


if __name__=='__main__':unittest.main()
