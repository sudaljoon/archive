"""Administrative publication register. Additive tables; no deletion or automatic publication."""
import csv
import datetime as dt
import hashlib
import io
import json
import re
import secrets
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

import core
import activity_log
import access_requests
import pdf_attachments

CHOICES={
 'source':('공사 발간','외부 수집'),
 'publication_type':('연감','백서','통계집','업무편람','업무안내서','사업·용역보고서','법규집','회의자료','연설·강연집','사료집','연혁집','목록류','전시·도감·화보집','기타'),
 'cycle':('단행본','일간','주간','격주간','순간','월간','격월간','계간','반년간','연간','격년간','3년간','4년간','5년간','부정기'),
 'medium':('책자','전자파일','책자·전자파일'),
 'registration_target':('검토 중','신청 대상','생략 대상'),
 'application_status':('미신청','신청 중','발급 완료','변경 신청 중'),
 'disclosure':('공개','부분공개','비공개'),
 'usage_consent':('미검토','동의','미동의'),
 'kogl':('미검토','미적용','제1유형','제2유형','제3유형','제4유형'),
 'pdf_review':('미확인','확인 완료','보완 필요'),
}
TEXT_FIELDS=('title','publisher','department','contact','author','volume','edition','isbn','issn','summary',
 'registration_no','registration_authority','application_ref','exemption_reason','change_reason',
 'disclosure_basis','disclosure_reason','restricted_scope','consent_reason','rights_note',
 'linked_record_id','notes')
DATES=('published_on','applied_on','restricted_from','restricted_until')
DEFAULTS={'source':'공사 발간','publication_type':'기타','cycle':'단행본','medium':'책자',
 'registration_target':'검토 중','application_status':'미신청','disclosure':'비공개',
 'usage_consent':'미검토','kogl':'미검토','pdf_review':'미확인'}
SCHEMA='''
CREATE TABLE IF NOT EXISTS publications(
 id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, title TEXT NOT NULL, year INTEGER NOT NULL,
 json_data TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL, created_by TEXT NOT NULL, updated_at TEXT NOT NULL, updated_by TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_publications_year ON publications(year,title);
CREATE TABLE IF NOT EXISTS publication_copies(
 id TEXT PRIMARY KEY, publication_id TEXT NOT NULL REFERENCES publications(id), accession_no TEXT NOT NULL UNIQUE,
 location TEXT NOT NULL, purpose TEXT NOT NULL, condition TEXT NOT NULL, notes TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_publication_copies_parent ON publication_copies(publication_id);
CREATE TABLE IF NOT EXISTS publication_shipments(
 id TEXT PRIMARY KEY, publication_id TEXT NOT NULL REFERENCES publications(id), recipient TEXT NOT NULL,
 medium TEXT NOT NULL, quantity INTEGER NOT NULL, due_on TEXT NOT NULL, sent_on TEXT NOT NULL,
 received_on TEXT NOT NULL, reference TEXT NOT NULL, notes TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_publication_shipments_parent ON publication_shipments(publication_id);
CREATE TABLE IF NOT EXISTS publication_files(
 id TEXT PRIMARY KEY, publication_id TEXT NOT NULL REFERENCES publications(id), original_name TEXT NOT NULL,
 disk_name TEXT NOT NULL UNIQUE, byte_size INTEGER NOT NULL, sha256 TEXT NOT NULL,
 created_at TEXT NOT NULL, created_by TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_publication_files_parent ON publication_files(publication_id);
'''


def ensure_tables(cfg):
    with core.dbconnect(cfg) as db:db.executescript(SCHEMA)


def text(value,limit=1000):
    result=str(value or '').strip()
    if '\x00' in result or len(result)>limit:raise core.UserError('입력 내용의 길이 또는 형식을 확인해 주세요.')
    return result


def date(value):
    result=text(value,10)
    if result:
        try:
            if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',result):raise ValueError()
            dt.date.fromisoformat(result)
        except ValueError:raise core.UserError('날짜는 YYYY-MM-DD 형식으로 입력해 주세요.')
    return result


def integer(value,low,high,label):
    if isinstance(value,bool):raise core.UserError(label+' 값을 확인해 주세요.')
    if not isinstance(value,(int,str)) or not re.fullmatch(r'\d+',str(value)):raise core.UserError(label+'는 정수로 입력해 주세요.')
    n=int(value)
    if not low<=n<=high:raise core.UserError(label+' 범위를 확인해 주세요.')
    return n


def actor(handler):
    ses=handler.check_csrf()
    if ses['role']!='admin':raise core.UserError('간행물 관리는 관리자 전용입니다.',403)
    return ses


def one(db,pid):
    row=db.execute('SELECT * FROM publications WHERE id=?',(pid,)).fetchone()
    if not row:raise core.UserError('간행물을 찾을 수 없습니다.',404)
    return dict(row)


def unpack(row):
    item=json.loads(row['json_data']);item.update({k:row[k] for k in ('id','code','revision','created_at','updated_at')})
    return item


def sanitize(payload):
    result={k:text(payload.get(k),5000 if k in ('summary','notes','rights_note') else 600) for k in TEXT_FIELDS}
    if not result['title']:raise core.UserError('간행물 제목은 필수입니다.')
    result['year']=integer(payload.get('year'),1900,2100,'발행연도')
    for k,values in CHOICES.items():
        result[k]=payload.get(k,DEFAULTS[k])
        if result[k] not in values:raise core.UserError(k+' 선택값을 확인해 주세요.')
    for k in DATES:result[k]=date(payload.get(k))
    if result['published_on'] and int(result['published_on'][:4])!=result['year']:
        raise core.UserError('발행일과 발행연도가 일치해야 합니다.')
    result['pages']=integer(payload.get('pages') or 0,0,100000,'페이지 수')
    result['size']=text(payload.get('size'),80)
    if result['source']=='공사 발간':
        if not result['publisher'] or not result['department']:raise core.UserError('공사 발간물의 발행기관·발행부서를 입력하세요.')
        if result['registration_target']=='생략 대상' and not result['exemption_reason']:
            raise core.UserError('발간등록 생략 판단 사유를 입력하세요.')
        if result['application_status']=='발급 완료' and not result['registration_no']:
            raise core.UserError('발급받은 공식 발간등록번호를 입력하세요.')
        if result['application_status']=='변경 신청 중' and not result['change_reason']:
            raise core.UserError('변경신청 사유를 입력하세요.')
    if result['disclosure']!='공개':
        if not result['disclosure_basis'] or not result['disclosure_reason']:
            raise core.UserError('부분공개·비공개 근거와 사유를 입력하세요.')
        if result['disclosure']=='부분공개' and not result['restricted_scope']:
            raise core.UserError('부분공개 제한 범위(쪽수·목차 등)를 입력하세요.')
    if result['restricted_from'] and result['restricted_until'] and result['restricted_from']>result['restricted_until']:
        raise core.UserError('공개제한 종료일은 시작일보다 빠를 수 없습니다.')
    if result['usage_consent']=='미동의' and not result['consent_reason']:
        raise core.UserError('저작물 이용 미동의 사유를 입력하세요.')
    if result['kogl'] not in ('미검토','미적용') and not result['rights_note']:
        raise core.UserError('공공누리 적용에 필요한 권리 보유·이용허락 확인 내용을 입력하세요.')
    return result


def log(handler,db,ses,event,pid,title,detail=''):
    core.audit(db,ses['user'],event,'publications',pid,detail)
    activity_log.write(handler,'관리자 작업',event,ses=ses,kind='publication',target=pid,title=title,detail=detail,db=db)


def save(handler,pid=None):
    ses=actor(handler);p=handler.json_in();data=sanitize(p);is_update=pid is not None
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        db.execute('BEGIN IMMEDIATE')
        if data['linked_record_id']:
            mapping=db.execute('SELECT record_id FROM record_management_numbers WHERE management_no=?',(data['linked_record_id'],)).fetchone()
            if mapping:data['linked_record_id']=mapping['record_id']
            row=db.execute('SELECT json_data FROM archive_state WHERE id=1').fetchone()
            ids={str(r.get('id')) for r in json.loads(row['json_data']).get('records',[])} if row else set()
            if data['linked_record_id'] not in ids:raise core.UserError('연계할 기존 일반기록물 관리번호를 확인해 주세요.',404)
        now=core.now()
        if pid:
            old=one(db,pid)
            if type(p.get('revision')) is not int or p.get('revision')!=old['revision']:raise core.UserError('다른 작업으로 변경되었습니다. 새로 조회한 뒤 수정하세요.',409)
            db.execute('UPDATE publications SET title=?,year=?,json_data=?,revision=revision+1,updated_at=?,updated_by=? WHERE id=?',
                       (data['title'],data['year'],json.dumps(data,ensure_ascii=False),now,ses['user'],pid))
        else:
            pid=secrets.token_hex(12);code=f"PUB-{data['year']}-{pid[:12].upper()}"
            db.execute('INSERT INTO publications VALUES(?,?,?,?,?,1,?,?,?,?)',
                       (pid,code,data['title'],data['year'],json.dumps(data,ensure_ascii=False),now,ses['user'],now,ses['user']))
        previous=json.loads(old['json_data']) if is_update else {}
        change=f"신청상태 {previous.get('application_status','신규')} → {data['application_status']} / 발간등록번호 {previous.get('registration_no','')} → {data['registration_no']} / 변경사유 {data['change_reason']}"
        log(handler,db,ses,'간행물 수정' if is_update else '간행물 등록',pid,data['title'],change)
        result=unpack(one(db,pid))
    return handler.json_out({'ok':True,'item':result},200 if is_update else 201)


def listing(handler,export=False):
    core.confirm_role(handler,'admin');q=parse_qs(urlsplit(handler.path).query)
    keyword=text(q.get('q',[''])[0],100).casefold();year=q.get('year',[''])[0]
    if year:year=integer(year,1900,2100,'발행연도')
    source=q.get('source',[''])[0];status=q.get('status',[''])[0]
    if source and source not in CHOICES['source']:raise core.UserError('자료구분을 확인해 주세요.')
    if status and status not in CHOICES['application_status']:raise core.UserError('신청상태를 확인해 주세요.')
    with core.dbconnect(handler.cfg) as db:
        rows=db.execute('SELECT * FROM publications'+(' WHERE year=?' if year else '')+' ORDER BY year DESC,created_at DESC,id', (year,) if year else ()).fetchall()
        counts={r['publication_id']:r['n'] for r in db.execute('SELECT publication_id,COUNT(*) n FROM publication_copies GROUP BY publication_id')}
    items=[]
    for r in rows:
        i=unpack(r)
        if source and i['source']!=source:continue
        if status and i['application_status']!=status:continue
        if keyword and keyword not in ' '.join(str(i.get(k,'')) for k in ('code','title','publisher','department','author','registration_no','isbn','summary')).casefold():continue
        i['copy_count']=counts.get(i['id'],0);items.append(i)
    if export:
        out=io.StringIO(newline='');writer=csv.writer(out)
        writer.writerow(['내부관리번호','제목','구분','발행연도','발행기관','발행부서','유형','발간주기','권호','발간등록번호','등록대상','신청상태','공개구분','소장권수'])
        for i in items:
            writer.writerow([csv_cell(i.get(k,'')) for k in ('code','title','source','year','publisher','department','publication_type','cycle','volume','registration_no','registration_target','application_status','disclosure','copy_count')])
        return handler.response_bytes(('\ufeff'+out.getvalue()).encode('utf-8'),ctype='text/csv; charset=utf-8',extra={'Content-Disposition':'attachment; filename=publications.csv'})
    return handler.json_out({'items':items,'choices':CHOICES,'defaults':DEFAULTS})


def csv_cell(v):
    s=str(v)
    return "'"+s if s.lstrip().startswith(('=','+','-','@')) else s


def detail(handler,pid):
    core.confirm_role(handler,'admin')
    with core.dbconnect(handler.cfg) as db:
        item=unpack(one(db,pid))
        mapping=db.execute('SELECT management_no FROM record_management_numbers WHERE record_id=?',(item['linked_record_id'],)).fetchone()
        item['linked_record_management_no']=mapping['management_no'] if mapping else item['linked_record_id']
        copies=[dict(r) for r in db.execute('SELECT * FROM publication_copies WHERE publication_id=? ORDER BY created_at,id',(pid,))]
        shipments=[dict(r) for r in db.execute('SELECT * FROM publication_shipments WHERE publication_id=? ORDER BY created_at DESC,id',(pid,))]
        files=[dict(r) for r in db.execute('SELECT id,original_name,byte_size,sha256,created_at FROM publication_files WHERE publication_id=? ORDER BY created_at DESC,id',(pid,))]
    today=dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).date().isoformat()
    for s in shipments:
        s['status']='수령 확인' if s['received_on'] else '송부 완료' if s['sent_on'] else '기한 경과' if s['due_on'] and s['due_on']<today else '송부 예정'
    return handler.json_out({'item':item,'copies':copies,'shipments':shipments,'files':files})


def child_save(handler,pid,kind,cid=None):
    ses=actor(handler);p=handler.json_in();now=core.now()
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        db.execute('BEGIN IMMEDIATE');parent=one(db,pid)
        table='publication_copies' if kind=='copies' else 'publication_shipments'
        if cid:
            old=db.execute(f'SELECT * FROM {table} WHERE id=? AND publication_id=?',(cid,pid)).fetchone()
            if not old:raise core.UserError('해당 간행물의 관리내역이 아닙니다.',404)
            if type(p.get('revision')) is not int or p.get('revision')!=old['revision']:raise core.UserError('내역이 변경되었습니다. 새로 조회해 주세요.',409)
        if kind=='copies':
            values={'location':text(p.get('location'),300),'purpose':text(p.get('purpose'),30),'condition':text(p.get('condition'),30),'notes':text(p.get('notes'),1000)}
            if not values['location']:raise core.UserError('소장위치를 입력하세요.')
            if values['purpose'] not in ('보존용','열람용','배포용'):raise core.UserError('소장용도를 확인하세요.')
            if values['condition'] not in ('양호','훼손','보수 필요','소재 확인 중'):raise core.UserError('소장상태를 확인하세요.')
        else:
            values={'recipient':text(p.get('recipient'),200),'medium':text(p.get('medium'),30),
                    'quantity':integer(p.get('quantity',0),0,100000,'송부부수'),
                    'due_on':date(p.get('due_on')),'sent_on':date(p.get('sent_on')),'received_on':date(p.get('received_on')),
                    'reference':text(p.get('reference'),300),'notes':text(p.get('notes'),1000)}
            if not values['recipient']:raise core.UserError('실제 송부처를 입력하세요.')
            if values['medium'] not in CHOICES['medium']:raise core.UserError('송부매체를 확인하세요.')
            if values['medium']!='전자파일' and values['quantity']<1:raise core.UserError('책자 송부는 부수를 입력하세요.')
            if values['received_on'] and (not values['sent_on'] or values['received_on']<values['sent_on']):raise core.UserError('수령일은 송부일 이후여야 합니다.')
        if cid:
            db.execute(f'UPDATE {table} SET '+','.join(k+'=?' for k in values)+',revision=revision+1,updated_at=? WHERE id=?',(*values.values(),now,cid))
        else:
            cid=secrets.token_hex(12)
            if kind=='copies':
                n=db.execute('SELECT COUNT(*) FROM publication_copies WHERE publication_id=?',(pid,)).fetchone()[0]+1
                values={'accession_no':parent['code']+f'-{n:04}',**values}
            cols=('id','publication_id',*values,'created_at','updated_at')
            db.execute(f'INSERT INTO {table} ({",".join(cols)}) VALUES ({",".join("?" for _ in cols)})',(cid,pid,*values.values(),now,now))
        log(handler,db,ses,'간행물 소장관리' if kind=='copies' else '간행물 송부관리',pid,parent['title'],f'{kind} / {cid}')
    return handler.json_out({'ok':True,'id':cid})


def upload(handler,pid):
    ses=actor(handler);name,raw=pdf_attachments._parse_multipart(handler)
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        parent=one(db,pid);fid=secrets.token_hex(16)
        folder=Path(handler.cfg['media_dir'])/'publication_pdfs';folder.mkdir(parents=True,exist_ok=True)
        target=folder/(fid+'.pdf')
        created=False
        try:
            with target.open('xb') as f:
                created=True
                f.write(raw)
            db.execute('INSERT INTO publication_files VALUES(?,?,?,?,?,?,?,?)',(fid,pid,name,fid+'.pdf',len(raw),hashlib.sha256(raw).hexdigest(),core.now(),ses['user']))
            log(handler,db,ses,'간행물 PDF 첨부',pid,parent['title'],fid+' / '+name)
            db.commit()
        except Exception:
            if created:target.unlink(missing_ok=True)
            raise
    return handler.json_out({'ok':True,'id':fid},201)


def content(handler,pid,fid):
    ses=core.confirm_role(handler,'admin')
    with core.dbconnect(handler.cfg) as db:
        parent=one(db,pid)
        row=db.execute('SELECT * FROM publication_files WHERE id=? AND publication_id=?',(fid,pid)).fetchone()
    if not row or not re.fullmatch(r'[a-f0-9]{32}\.pdf',row['disk_name']):raise core.UserError('첨부파일이 없습니다.',404)
    target=Path(handler.cfg['media_dir'])/'publication_pdfs'/row['disk_name']
    if not target.is_file():raise core.UserError('첨부파일을 찾을 수 없습니다.',404)
    activity_log.write(handler,'기록물 이용','간행물 PDF 열람',ses=ses,kind='publication',target=pid,title=parent['title'],detail=fid)
    return access_requests._respond_pdf(handler,target,row['original_name'])
