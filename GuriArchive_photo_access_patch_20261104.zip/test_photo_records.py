"""Isolated photo-module regression checks; never uses the uploaded database."""
import io
import json
import tempfile
import unittest
from pathlib import Path

from PIL import Image

import core
import activity_log
import photo_records
import access_requests
import server


class FakeHandler:
    def __init__(self,cfg,role='admin'):
        self.cfg=cfg
        self.session={'role':role,'user':'test_admin','csrf':'test'}
        self.path='/api/v2/photos'
        self.headers={}
        self.payload={}
        self.raw=b''
        self.command='POST'

    def current_session(self): return self.session
    def check_csrf(self): return self.session
    def json_in(self): return self.payload
    def json_out(self,obj,code=200,extra=None): return {'code':code,**obj}
    def input_bytes(self,limit):
        if len(self.raw)>limit: raise core.UserError('Too large',413)
        return self.raw
    def response_bytes(self,data,status=200,ctype='',extra=None):return {'data':data,'type':ctype,'code':status}


class PhotoRecordsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='guri-photo-test-')
        self.addCleanup(self.temp.cleanup)
        base=Path(self.temp.name)
        self.cfg={'db_path':str(base/'test.sqlite3'),'media_dir':str(base/'media')}
        core.initialize_db(self.cfg)
        photo_records.ensure_tables(self.cfg)
        access_requests.ensure_tables(self.cfg)
        activity_log.ensure_tables(self.cfg)
        self.a=FakeHandler(self.cfg)

    def series(self,disclosure='공개',department='기록관리팀'):
        self.a.payload={'title':'2026 행사 사진철','department':department,'classification':'행사관리','start_year':2026,'end_year':2026,'disclosure':disclosure}
        return photo_records.save(self.a,'series')['id']

    def item(self,sid,disclosure='공개',title='2026 개막 행사',people='',shot_date='2026-11-02'):
        self.a.payload={'title':title,'series_id':sid,'shot_date':shot_date,'shot_place':'행사장','people':people,'disclosure':disclosure}
        return photo_records.save(self.a,'items')['id']

    def photo(self):
        image=Image.new('RGB',(54,36),(12,120,90));out=io.BytesIO();image.save(out,format='PNG');return out.getvalue()

    def test_series_event_file_and_unmodified_original(self):
        sid=self.series();iid=self.item(sid)
        raw=self.photo();self.a.headers={'X-Original-Filename':'event.png'};self.a.raw=raw
        saved=photo_records.upload(self.a,iid)
        self.assertTrue(saved['ok'])
        info=photo_records.detail(self.a,iid)
        self.assertEqual(len(info['files']),1)
        file_id=info['files'][0]['id']
        self.assertEqual(photo_records.image(self.a,file_id)['data'],raw)
        self.assertEqual(photo_records.image(self.a,file_id,preview=True)['type'],'image/jpeg')
        with self.assertRaises(core.UserError) as ctx: photo_records.upload(self.a,iid)
        self.assertEqual(ctx.exception.code,409)
        self.assertEqual(len(photo_records.detail(self.a,iid)['files']),1)

    def test_employee_searches_all_disclosures_without_restricted_images(self):
        public_series=self.series();public_id=self.item(public_series)
        private_series=self.series(disclosure='비공개');private_id=self.item(private_series)
        hidden_id=self.item(public_series,disclosure='부분공개')
        viewer=FakeHandler(self.cfg,role='viewer')
        result=photo_records.listing(viewer)
        self.assertEqual({x['id'] for x in result['items']},{public_id,private_id,hidden_id})
        self.assertEqual({x['id'] for x in result['series']},{public_series,private_series})
        for hidden in (private_id,hidden_id):
            result=photo_records.detail(viewer,hidden)
            self.assertTrue(result['requires_approval'])
            self.assertEqual(result['files'],[])
            self.assertEqual(result['item']['summary'],'')

    def test_admin_can_edit_without_erasing_files(self):
        sid=self.series();iid=self.item(sid)
        self.a.headers={'X-Original-Filename':'event.png'};self.a.raw=self.photo()
        photo_records.upload(self.a,iid)
        self.a.command='PUT'
        self.a.payload={'title':'이름 변경','shot_date':'2026-11-02','disclosure':'공개'}
        photo_records.save(self.a,'items',iid)
        self.assertEqual(photo_records.detail(self.a,iid)['item']['title'],'이름 변경')
        self.assertEqual(len(photo_records.detail(self.a,iid)['files']),1)

    def test_employee_can_preview_but_cannot_download_original(self):
        sid=self.series();iid=self.item(sid)
        self.a.headers={'X-Original-Filename':'event.png'};self.a.raw=self.photo()
        file_id=photo_records.upload(self.a,iid)['id']
        viewer=FakeHandler(self.cfg,role='viewer')
        self.assertEqual(photo_records.image(viewer,file_id,preview=True)['type'],'image/jpeg')
        self.assertEqual(photo_records.image(viewer,file_id,view=True)['type'],'image/jpeg')
        # A record made by v2.9.11 has no dedicated 1800px view derivative.
        (Path(self.cfg['media_dir'])/'photo_records'/(file_id+'.view.jpg')).unlink()
        self.assertEqual(photo_records.image(viewer,file_id,view=True)['type'],'image/jpeg')
        with self.assertRaises(core.UserError) as context:photo_records.image(viewer,file_id)
        self.assertEqual(context.exception.code,403)

    def test_invalid_date_rejected(self):
        sid=self.series()
        self.a.payload={'title':'잘못된 날짜','series_id':sid,'shot_date':'2026-02-31','disclosure':'공개'}
        with self.assertRaises(core.UserError):photo_records.save(self.a,'items')

    def test_employee_photo_search_categories(self):
        a=self.series(department='시설관리팀')
        b=self.series(department='경영기획팀')
        first=self.item(a,people='김민수 본부장')
        second=self.item(b,title='2026 워크숍',people='박민지 과장',shot_date='2026-11-03')
        viewer=FakeHandler(self.cfg,role='viewer')
        criteria=[
            ('department','시설관리',{first}),
            ('people','과장',{second}),
            ('shot_date','2026-11-03',{second}),
            ('title','개막',{first}),
            ('all','경영기획팀',{second}),
            ('all','김민수',{first}),
        ]
        for field,keyword,expected in criteria:
            with self.subTest(field=field,keyword=keyword):
                viewer.path=f'/api/v2/photos?field={field}&q={keyword}'
                self.assertEqual({item['id'] for item in photo_records.listing(viewer)['items']},expected)
        for path in ('/api/v2/photos?field=invalid&q=test',
                     '/api/v2/photos?field=shot_date&q=2026-02-30'):
            viewer.path=path
            with self.assertRaises(core.UserError):photo_records.listing(viewer)

    def test_classification_catalog_and_automatic_series_link(self):
        self.a.path='/api/v2/photos/classifications?year=2026&department=경영기획팀'
        catalog=photo_records.classifications(self.a)
        self.assertIn(2026,catalog['years'])
        self.assertTrue(any(r['id']=='2026-001' for r in catalog['rows']))
        viewer=FakeHandler(self.cfg,role='viewer')
        with self.assertRaises(core.UserError):photo_records.classifications(viewer)
        self.a.payload={
            'title':'업무 행사 사진철','department':'경영기획팀',
            'start_year':2026,'end_year':2026,'classification_year':2026,
            'classification_id':'2026-001','classification':'잘못된 수기 분류',
            'retention':'영구','retention_reason':'수기 사유','disclosure':'공개'
        }
        sid=photo_records.save(self.a,'series')['id']
        with core.dbconnect(self.cfg) as db:
            item=dict(db.execute('SELECT * FROM photo_series WHERE id=?',(sid,)).fetchone())
        self.assertEqual(item['classification_id'],'2026-001')
        self.assertEqual(item['classification_year'],2026)
        self.assertEqual(item['retention'],'3년')
        self.assertIn('처리과서무',item['classification'])
        self.assertNotEqual(item['retention_reason'],'수기 사유')
        self.a.payload['department']='시설관리팀'
        self.a.payload['classification_id']='2026-123'
        with self.assertRaises(core.UserError):photo_records.save(self.a,'series')

    def test_pre_2024_photo_series_follows_existing_classification_rule(self):
        self.a.payload={'title':'2023년도 역사 사진','department':'기록관리팀',
                        'start_year':2023,'end_year':2023,'classification_year':2024,
                        'classification_id':'2024-001','disclosure':'비공개'}
        sid=photo_records.save(self.a,'series')['id']
        with core.dbconnect(self.cfg) as db:
            row=db.execute('SELECT * FROM photo_series WHERE id=?',(sid,)).fetchone()
        self.assertEqual(row['start_year'],2023)
        self.assertEqual(row['classification_year'],2024)

    def test_classification_override_takes_precedence(self):
        replacement={'id':'2026-X1','department':'경영기획팀','unit':'홍보업무',
                     'fileSeries':'홍보사진','fileRetention':'10년',
                     'unitRetention':'10년','reason':'홍보사진 생산 및 관리'}
        with core.dbconnect(self.cfg) as db:
            db.execute('CREATE TABLE archive_state(id INTEGER PRIMARY KEY,json_data TEXT NOT NULL)')
            db.execute('INSERT INTO archive_state VALUES(1,?)',(
                json.dumps({'classificationOverrides':{'2026':{'rows':[replacement]}}}),))
        self.a.path='/api/v2/photos/classifications?year=2026'
        rows=photo_records.classifications(self.a)['rows']
        self.assertEqual([r['id'] for r in rows],['2026-X1'])
        self.a.payload={'title':'홍보사진철','department':'경영기획팀','start_year':2026,
                        'classification_year':2026,'classification_id':'2026-X1','disclosure':'공개'}
        sid=photo_records.save(self.a,'series')['id']
        with core.dbconnect(self.cfg) as db:
            self.assertEqual(db.execute('SELECT retention FROM photo_series WHERE id=?',(sid,)).fetchone()['retention'],'10년')

    def test_existing_photo_series_table_migrates_without_data_loss(self):
        cfg={'db_path':str(Path(self.temp.name)/'old.sqlite3'),'media_dir':self.cfg['media_dir']}
        core.initialize_db(cfg)
        with core.dbconnect(cfg) as db:
            db.execute('''CREATE TABLE photo_series (
                id TEXT PRIMARY KEY, title TEXT NOT NULL, department TEXT NOT NULL,
                classification TEXT NOT NULL DEFAULT '', start_year INTEGER, end_year INTEGER,
                retention TEXT NOT NULL DEFAULT '', retention_reason TEXT NOT NULL DEFAULT '',
                disclosure TEXT NOT NULL DEFAULT '비공개', notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL, created_by TEXT NOT NULL, updated_at TEXT NOT NULL)''')
            db.execute('''INSERT INTO photo_series
                (id,title,department,created_at,created_by,updated_at)
                VALUES('legacy','기존 사진철','경영기획팀','2026-01-01','tester','2026-01-01')''')
        photo_records.ensure_tables(cfg)
        with core.dbconnect(cfg) as db:
            row=db.execute("SELECT * FROM photo_series WHERE id='legacy'").fetchone()
            self.assertEqual(row['title'],'기존 사진철')
            self.assertEqual(row['classification_id'],'')
            self.assertIsNone(row['classification_year'])

    def test_server_startup_and_routes(self):
        server.initialize_db(self.cfg)
        self.a.path='/photos?embedded=1'
        html=server.FullArchiveHandler.route_get(self.a)['data']
        self.assertIn(b'/photos.js',html)
        self.a.path='/api/v2/photos'
        self.assertEqual(server.FullArchiveHandler.route_get(self.a)['series'],[])
        self.a.path='/photos/public'
        self.a.session['role']='viewer'
        self.assertIn(b'/portal.js',server.FullArchiveHandler.route_get(self.a)['data'])
        self.a.path='/photos'
        with self.assertRaises(core.UserError):server.FullArchiveHandler.route_get(self.a)

    def test_employee_page_integrated_photo_tab(self):
        html=(core.STATIC_ROOT/'index.html').read_text(encoding='utf-8')
        js=(core.STATIC_ROOT/'portal.js').read_text(encoding='utf-8')
        self.assertIn('id="menu-photos" class="nav" data-tab="photos"',html)
        self.assertLess(html.index('id="menu-photos"'),html.index('id="menu-applications"'))
        self.assertIn('시청각기록물 열람',html)
        self.assertIn('id="photos-view" hidden',html)
        self.assertIn('id="photo-search-category"',html)
        self.assertIn('id="photo-date" type="date"',html)
        self.assertIn('id="photo-dialog"',html)
        self.assertIn("$('#photos-view').hidden=tab!=='photos'",js)
        self.assertIn('/view`',js)
        self.assertNotIn('/api/v2/photos/files/${f.id}/original',js)


if __name__=='__main__':unittest.main()
