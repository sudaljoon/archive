"""Personalized watermarks, permission preservation and immutable originals; temp DB only."""
import hashlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image
import core
import photo_records as photos
import photo_watermark as watermark
import test_photo_access as base


class PhotoWatermarkTests(unittest.TestCase):
    setUp=base.PhotoAccessTests.setUp
    item=base.PhotoAccessTests.item
    upload=base.PhotoAccessTests.upload
    apply=base.PhotoAccessTests.apply
    decide=base.PhotoAccessTests.decide
    denied=base.PhotoAccessTests.denied

    def public_photo(self):
        self.admin.payload={'title':'공개사진철','department':'총무팀','disclosure':'공개'}
        sid=photos.save(self.admin,'series')['id']
        iid=self.item(sid);return self.upload(iid,55)

    def test_user_and_time_are_rendered_on_every_view_not_from_query(self):
        fid=self.public_photo();seen=[]
        from PIL import ImageDraw
        original=ImageDraw.ImageDraw.text
        def spy(draw,xy,text,*args,**kwargs):
            seen.append(text);return original(draw,xy,text,*args,**kwargs)
        self.viewer.path=f'/api/v2/photos/files/{fid}/view?user=someone-else&time=fake'
        with patch.object(watermark,'timestamp',return_value='2026-11-04 15:30:00 KST'),patch.object(ImageDraw.ImageDraw,'text',spy):
            first=photos.image(self.viewer,fid,view=True)['data']
        self.assertIn('열람자 ID: employee1',seen)
        self.assertIn('열람일시: 2026-11-04 15:30:00 KST',seen)
        self.assertIn('열람용 · 원본 다운로드 불가',seen)
        self.assertFalse(any('someone-else' in s for s in seen))
        with patch.object(watermark,'timestamp',return_value='2026-11-04 15:30:00 KST'):
            other=photos.image(self.other,fid,view=True)['data']
        with patch.object(watermark,'timestamp',return_value='2026-11-04 15:30:01 KST'):
            later=photos.image(self.viewer,fid,view=True)['data']
        self.assertNotEqual(first,other);self.assertNotEqual(first,later)
        with core.dbconnect(self.cfg) as db:
            row=db.execute("SELECT * FROM activity_events WHERE event='시청각 이미지 열람' AND username='employee1' ORDER BY id LIMIT 1").fetchone()
        self.assertIn('2026-11-04 15:30:00 KST',row['detail'])

    def test_original_and_all_derivative_files_are_unchanged(self):
        fid=self.public_photo();folder=Path(self.cfg['media_dir'])/'photo_records'
        before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir()}
        original=photos.image(self.admin,fid)['data']
        for handler in (self.viewer,self.other,self.admin):
            photos.image(handler,fid,view=True);photos.image(handler,fid,preview=True)
        after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir()}
        self.assertEqual(before,after)
        self.assertEqual(photos.image(self.admin,fid)['data'],original)
        self.denied(self.viewer,fid)

    def test_preview_cannot_bypass_watermark_or_private_grants(self):
        fid=self.public_photo()
        with patch.object(watermark,'render',wraps=watermark.render) as render:
            photos.image(self.viewer,fid,preview=True)
            self.assertEqual(render.call_count,1)
        with patch.object(watermark,'render',wraps=watermark.render) as render:
            self.denied(self.viewer,self.files[0],preview=True)
            self.denied(self.viewer,self.files[0],view=True)
            self.assertEqual(render.call_count,0)
        rid=self.apply();self.decide(rid)
        photos.image(self.viewer,self.files[0],preview=True)
        self.denied(self.viewer,self.files[1],preview=True)
        self.denied(self.other,self.files[0],view=True)
        self.denied(self.viewer,self.files[0])

    def test_missing_assets_fail_closed_and_write_no_success_view(self):
        fid=self.public_photo()
        with patch.object(watermark,'_font',side_effect=OSError('missing bundled font')):
            with self.assertRaises(core.UserError) as ctx:photos.image(self.viewer,fid,view=True)
        self.assertEqual(ctx.exception.code,503)
        with core.dbconnect(self.cfg) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM activity_events WHERE event='시청각 이미지 열람'").fetchone()[0],0)

    def test_legacy_photo_without_view_derivative_stays_watermarked(self):
        fid=self.public_photo();folder=Path(self.cfg['media_dir'])/'photo_records'
        (folder/(fid+'.view.jpg')).unlink()
        raw=photos.image(self.viewer,fid,view=True)['data']
        with Image.open(io.BytesIO(raw)) as im:
            self.assertGreaterEqual(im.width,640)
            self.assertGreater(im.height,48)
            self.assertFalse(im.getexif())
        self.assertFalse((folder/(fid+'.view.jpg')).exists())

    def test_portrait_landscape_tiny_transparent_and_large_images(self):
        with tempfile.TemporaryDirectory(prefix='guri-watermark-images-') as tmp:
            for n,size in enumerate(((1,1),(300,1100),(1600,800),(4000,2000))):
                path=Path(tmp)/f'{n}.png'
                Image.new('RGBA',size,(80,110,180,180)).save(path)
                raw=watermark.render(path,'employee_abcdefghijklmnopqrstuvwxyz01','2026-11-04 15:30:00 KST')
                with Image.open(io.BytesIO(raw)) as output:
                    self.assertEqual(output.format,'JPEG')
                    self.assertLessEqual(output.width,1800)
                    self.assertLessEqual(output.height,2000)
                    self.assertGreaterEqual(output.width,640)
                    self.assertGreater(output.height,(1,1100,800,900)[n])

    def test_korean_font_logo_shape_and_timezone(self):
        self.assertTrue(watermark.timestamp().endswith(' KST'))
        self.assertEqual(watermark.KST.utcoffset(None).total_seconds(),9*3600)
        font=watermark._font(18)
        self.assertNotEqual(bytes(font.getmask('열')),bytes(font.getmask('람')))
        alpha=watermark._logo()
        self.assertGreater(alpha.width,alpha.height)
        self.assertEqual(alpha.getextrema(),(0,255))


if __name__=='__main__':unittest.main()
