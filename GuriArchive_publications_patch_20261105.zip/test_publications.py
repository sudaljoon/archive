"""Publication workflow checks; fresh temporary SQLite and media only."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import core
import server
import publications as pubs
from test_photo_records import FakeHandler


class PublicationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='guri-publications-test-');self.addCleanup(self.temp.cleanup)
        self.cfg={'db_path':self.temp.name+'/db.sqlite3','media_dir':self.temp.name+'/media'}
        server.initialize_db(self.cfg)
        self.admin=FakeHandler(self.cfg);self.viewer=FakeHandler(self.cfg,'viewer')
        self.payload={**pubs.DEFAULTS,'title':'2026년 공사 연차보고서','year':2026,'publisher':'구리농수산물공사','department':'경영기획팀','disclosure':'공개'}

    def create(self,**changes):
        self.admin.payload={**self.payload,**changes}
        return pubs.save(self.admin)['item']

    def test_create_edit_revision_and_unknown_target(self):
        item=self.create();self.assertTrue(item['code'].startswith('PUB-2026-'))
        self.assertEqual(item['registration_no'],'')
        self.admin.payload={**item,'title':'연차보고서 수정'}
        saved=pubs.save(self.admin,item['id'])['item'];self.assertEqual(saved['revision'],2)
        with self.assertRaises(core.UserError) as e:pubs.save(self.admin,item['id'])
        self.assertEqual(e.exception.code,409)
        self.assertEqual(pubs.detail(self.admin,item['id'])['item']['title'],'연차보고서 수정')
        with self.assertRaises(core.UserError):pubs.detail(self.admin,'missing')

    def test_validation_for_registration_disclosure_and_rights(self):
        bad=[{'year':True},{'year':2026.5},{'published_on':'2026-02-30'},
             {'published_on':'2025-12-31'}, {'registration_target':'생략 대상'},
             {'application_status':'발급 완료'}, {'application_status':'변경 신청 중'},
             {'disclosure':'부분공개','disclosure_basis':'정보공개법 제9조제1항제6호','disclosure_reason':'개인정보'},
             {'disclosure':'비공개'}, {'usage_consent':'미동의'}, {'kogl':'제1유형'},
             {'restricted_from':'2026-12-01','restricted_until':'2026-11-01'}]
        for data in bad:
            with self.subTest(data=data),self.assertRaises(core.UserError):self.create(**data)
        self.assertEqual(pubs.listing(self.admin)['items'],[])

    def test_creation_cannot_be_confused_with_an_update(self):
        self.admin.payload={**self.payload,'revision':999}
        result=pubs.save(self.admin)
        self.assertEqual(result['code'],201)
        self.assertEqual(result['item']['revision'],1)

    def test_exempt_publication_is_still_managed_and_has_no_auto_number(self):
        item=self.create(registration_target='생략 대상',exemption_reason='단순 시스템 사용 매뉴얼로 검토')
        self.assertEqual(item['exemption_reason'],'단순 시스템 사용 매뉴얼로 검토')
        self.assertEqual(item['registration_no'],'')
        self.assertEqual(len(pubs.listing(self.admin)['items']),1)

    def test_restricted_fields_and_publication_number_are_preserved(self):
        item=self.create(disclosure='부분공개',disclosure_basis='정보공개법 제9조제1항제6호',disclosure_reason='개인정보',restricted_scope='15~18쪽',restricted_from='2026-11-05',restricted_until='2030-11-05',registration_no='TEST-OFFICIAL-001',application_status='발급 완료',registration_authority='관할기관 확인',usage_consent='미동의',consent_reason='권리 확인 전')
        self.assertEqual(pubs.detail(self.admin,item['id'])['item']['restricted_scope'],'15~18쪽')
        self.assertEqual(item['registration_no'],'TEST-OFFICIAL-001')

    def test_copies_have_distinct_accession_numbers_and_safe_editing(self):
        a=self.create();b=self.create(title='다른 간행물')
        self.admin.payload={'location':'1서고 A-01','purpose':'보존용','condition':'양호'}
        c1=pubs.child_save(self.admin,a['id'],'copies')['id'];pubs.child_save(self.admin,a['id'],'copies')
        copies=pubs.detail(self.admin,a['id'])['copies']
        self.assertEqual(len({c['accession_no'] for c in copies}),2)
        copy=next(c for c in copies if c['id']==c1)
        self.admin.payload={**copy,'location':'2서고'}
        with self.assertRaises(core.UserError):pubs.child_save(self.admin,b['id'],'copies',c1)
        pubs.child_save(self.admin,a['id'],'copies',c1)
        with self.assertRaises(core.UserError):pubs.child_save(self.admin,a['id'],'copies',c1)
        self.assertEqual(len(pubs.detail(self.admin,a['id'])['copies']),2)

    def test_shipments_due_sent_received_and_validation(self):
        item=self.create();self.admin.payload={'recipient':'기관 기준에 따라 지정한 송부처','medium':'책자','quantity':3,'due_on':'2000-01-01'}
        cid=pubs.child_save(self.admin,item['id'],'shipments')['id']
        s=pubs.detail(self.admin,item['id'])['shipments'][0];self.assertEqual(s['status'],'기한 경과')
        self.admin.payload={**s,'sent_on':'2026-11-05'};pubs.child_save(self.admin,item['id'],'shipments',cid)
        s=pubs.detail(self.admin,item['id'])['shipments'][0];self.assertEqual(s['status'],'송부 완료')
        self.admin.payload={**s,'received_on':'2026-11-04'}
        with self.assertRaises(core.UserError):pubs.child_save(self.admin,item['id'],'shipments',cid)
        self.admin.payload['received_on']='2026-11-06';pubs.child_save(self.admin,item['id'],'shipments',cid)
        self.assertEqual(pubs.detail(self.admin,item['id'])['shipments'][0]['status'],'수령 확인')
        self.admin.payload={'recipient':'확인한 전자 송부처','medium':'전자파일','quantity':0}
        pubs.child_save(self.admin,item['id'],'shipments')

    def test_role_guards_and_no_delete_routes(self):
        item=self.create();self.viewer.payload=self.payload
        for f,args in [(pubs.listing,()),(pubs.save,()),(pubs.detail,(item['id'],)),(pubs.child_save,(item['id'],'copies')),(pubs.upload,(item['id'],)),(pubs.content,(item['id'],'a'*32))]:
            with self.subTest(f=f),self.assertRaises(core.UserError) as e:f(self.viewer,*args)
            self.assertEqual(e.exception.code,403)
        self.admin.path='/api/v2/publications/'+item['id']+'/delete'
        with self.assertRaises(core.UserError):server.FullArchiveHandler.route_post(self.admin)
        self.assertEqual(len(pubs.listing(self.admin)['items']),1)

    def test_search_filters_and_csv_injection_protection(self):
        self.create(title='=HYPERLINK("test")');self.create(title='외부 참고자료',source='외부 수집',year=2025)
        self.admin.path='/api/v2/publications?year=2026&source=공사 발간&q=연차'
        self.assertEqual(pubs.listing(self.admin)['items'],[])
        self.admin.path='/api/v2/publications?year=2026&source=공사 발간'
        self.assertEqual(len(pubs.listing(self.admin)['items']),1)
        out=pubs.listing(self.admin,True)['data'].decode('utf-8-sig')
        self.assertIn("'=HYPERLINK",out);self.assertNotIn('외부 참고자료',out)

    def test_linked_general_record_is_validated_and_unchanged(self):
        with core.dbconnect(self.cfg) as db:
            state={**server.EMPTY,'records':[{'id':'GR-1','title':'발간 결재문서'}]}
            text=json.dumps(state);db.execute('UPDATE archive_state SET json_data=? WHERE id=1',(text,))
        with self.assertRaises(core.UserError):self.create(linked_record_id='unknown')
        item=self.create(linked_record_id='GR-1')
        self.assertEqual(item['linked_record_id'],'GR-1')
        with core.dbconnect(self.cfg) as db:self.assertEqual(db.execute('SELECT json_data FROM archive_state').fetchone()[0],text)

    def test_pdf_append_preserves_previous_files_and_rejects_foreign_parent(self):
        a=self.create();b=self.create(title='다른 간행물');raw=b'%PDF-1.4\nunit test\n%%EOF'
        with patch.object(pubs.pdf_attachments,'_parse_multipart',return_value=('test.pdf',raw)):
            one=pubs.upload(self.admin,a['id'])['id'];pubs.upload(self.admin,a['id'])
        self.assertEqual(len(pubs.detail(self.admin,a['id'])['files']),2)
        folder=Path(self.cfg['media_dir'])/'publication_pdfs'
        self.assertEqual((folder/(one+'.pdf')).read_bytes(),raw)
        with self.assertRaises(core.UserError):pubs.content(self.admin,b['id'],one)

    def test_additive_reinitialization_preserves_existing_data(self):
        item=self.create()
        with core.dbconnect(self.cfg) as db:
            before={r['name']:list(db.execute('SELECT * FROM "'+r['name']+'"')) for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        server.initialize_db(self.cfg);server.initialize_db(self.cfg)
        with core.dbconnect(self.cfg) as db:
            for table,rows in before.items():self.assertEqual([tuple(r) for r in rows],[tuple(r) for r in db.execute('SELECT * FROM "'+table+'"')],table)
        self.assertEqual(pubs.detail(self.admin,item['id'])['item']['title'],self.payload['title'])

    def test_routes_and_embedded_menu(self):
        self.admin.path='/publications?embedded=1'
        self.assertIn(b'/publications.js',server.FullArchiveHandler.route_get(self.admin)['data'])
        self.admin.path='/api/v2/publications'
        self.assertEqual(server.FullArchiveHandler.route_get(self.admin)['items'],[])
        html=(core.STATIC_ROOT/'manager.html').read_text();js=(core.STATIC_ROOT/'manager.js').read_text()
        self.assertIn('data-page="publications"',html)
        self.assertIn("publications:{url:'/publications'",js)


if __name__=='__main__':unittest.main()
