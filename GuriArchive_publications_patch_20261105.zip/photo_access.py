"""Photo grants use the existing request inbox; originals are never granted."""
import datetime as dt
import json
import re
import secrets
from pathlib import Path

import core
import activity_log
import access_requests as requests


def selected_ids(req):
    try:
        ids = json.loads(req.get('photo_file_ids') or '[]')
        return ids if isinstance(ids, list) and all(isinstance(x, str) and re.fullmatch(r'[a-f0-9]{32}', x) for x in ids) else []
    except (TypeError, ValueError):
        return []


def public(item, series):
    return item['disclosure'] == series['disclosure'] == '공개'


def grants(db, user, item_id):
    """Recheck current approval, expiry and file membership on every request."""
    result = {}
    rows = db.execute("""SELECT * FROM access_requests WHERE target_kind='photo'
        AND applicant=? AND record_id=? AND method='online' AND status='승인'
        AND grant_mode='photo'""", (user, item_id))
    for row in rows:
        req = dict(row)
        if req['grant_expires_at'] and requests._not_expired(req):
            for fid in selected_ids(req):
                result[fid] = req['id']
    return result


def create(handler, ses, data):
    import photo_records
    iid = str(data.get('record_id', '')).strip()
    reason = str(data.get('reason', '')).strip()
    if not re.fullmatch(r'[a-f0-9]{24}', iid):
        raise core.UserError('사진기록물 번호를 확인해 주세요.')
    if data.get('method') != 'online':
        raise core.UserError('사진은 온라인 열람으로 신청해 주세요.')
    if not 5 <= len(reason) <= 1000:
        raise core.UserError('신청사유는 5~1000자로 입력해 주세요.')
    with core.WRITE_LOCK, core.dbconnect(handler.cfg) as db:
        item = photo_records._one(db, 'photo_items', iid)
        rows = db.execute("""SELECT * FROM access_requests WHERE target_kind='photo'
            AND applicant=? AND record_id=? AND status IN ('신청','승인')""", (ses['user'], iid))
        if any(r['status'] == '신청' or (r['grant_expires_at'] and requests._not_expired(dict(r))) for r in rows):
            raise core.UserError('이미 처리 중이거나 열람기간이 남은 사진 신청이 있습니다.', 409)
        rid = secrets.token_hex(12)
        db.execute('''INSERT INTO access_requests
            (id,record_id,applicant,method,reason,requested_at,target_kind)
            VALUES(?,?,?,'online',?,?,'photo')''', (rid, iid, ses['user'], reason, core.now()))
        core.audit(db, ses['user'], '시청각 열람신청', 'access_requests', rid, iid)
        activity_log.write(handler, '기록물 이용', '열람신청', ses=ses, kind='photo_item',
                           target=iid, title=item['title'], detail='시청각 / 신청번호 '+rid, db=db)
    return handler.json_out({'ok': True, 'id': rid, 'status': '신청'}, 201)


def options(handler, rid):
    core.confirm_role(handler, 'admin')
    with core.dbconnect(handler.cfg) as db:
        req = requests._load(db, rid)
        if req['target_kind'] != 'photo':
            raise core.UserError('시청각 신청이 아닙니다.', 409)
        files = [dict(r) for r in db.execute('''SELECT id,original_name,size_bytes FROM photo_files
            WHERE item_id=? ORDER BY uploaded_at,id''', (req['record_id'],))]
    return handler.json_out({'files': files})


def decision(handler, db, ses, req, payload, decision, note):
    import photo_records
    item = photo_records._one(db, 'photo_items', req['record_id'])
    ids, expires = [], ''
    if decision == '반려' and len(note) < 3:
        raise core.UserError('반려 사유를 3자 이상 입력하세요.')
    if decision == '승인':
        days = payload.get('grant_days')
        if type(days) is not int or days not in (1, 7, 30):
            raise core.UserError('열람기간은 1일, 7일, 30일 중 선택하세요.')
        ids = payload.get('file_ids')
        if (not isinstance(ids, list) or not 1 <= len(ids) <= 2000
                or any(not isinstance(x, str) or not re.fullmatch(r'[a-f0-9]{32}', x) for x in ids)
                or len(set(ids)) != len(ids)):
            raise core.UserError('열람을 허용할 사진을 하나 이상 선택하세요.')
        files = {r['id']: r for r in db.execute('SELECT * FROM photo_files WHERE item_id=?', (item['id'],))}
        if not set(ids).issubset(files):
            raise core.UserError('해당 사진기록물에 속한 사진만 승인할 수 있습니다.', 403)
        folder = Path(handler.cfg['media_dir']) / 'photo_records'
        if any(not (folder / files[fid]['stored_name']).is_file() for fid in ids):
            raise core.UserError('저장된 사진 파일을 찾을 수 없습니다.', 404)
        expires = (requests._utcnow() + dt.timedelta(days=days)).isoformat()
    db.execute('''UPDATE access_requests SET status=?,decision_note=?,decided_at=?,decided_by=?,
        grant_mode=?,photo_file_ids=?,grant_expires_at=? WHERE id=?''',
        (decision, note, core.now(), ses['user'], 'photo' if decision == '승인' else '', json.dumps(ids), expires, req['id']))
    core.audit(db, ses['user'], '시청각 열람 '+decision, 'access_requests', req['id'],
               json.dumps({'files': ids, 'expires': expires, 'note': note}, ensure_ascii=False))
    activity_log.write(handler, '기록물 이용', '열람 승인' if decision == '승인' else '열람 반려',
                       ses=ses, kind='photo_item', target=item['id'], title=item['title'],
                       detail=f"시청각 / 신청번호 {req['id']} / {len(ids)}장 / 만료 {expires}", db=db)
    return {'ok': True, 'status': decision, 'grant_expires_at': expires}
