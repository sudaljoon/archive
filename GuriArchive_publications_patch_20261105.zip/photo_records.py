"""Photo record-series, events and unmodified originals (v2.9.11).

An item is one event/subject; it may contain multiple original image files.
The legacy archive_state JSON and museum photographs are not changed here.
"""
import hashlib
import io
import json
import re
import secrets
import sqlite3
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlsplit

import core
import activity_log
import photo_access
import photo_watermark

SCHEMA = '''
CREATE TABLE IF NOT EXISTS photo_series (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, department TEXT NOT NULL,
 classification TEXT NOT NULL DEFAULT '', classification_year INTEGER,
 classification_id TEXT NOT NULL DEFAULT '', start_year INTEGER, end_year INTEGER,
 retention TEXT NOT NULL DEFAULT '', retention_reason TEXT NOT NULL DEFAULT '',
 disclosure TEXT NOT NULL DEFAULT '비공개', notes TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL, created_by TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS photo_items (
 id TEXT PRIMARY KEY, series_id TEXT NOT NULL REFERENCES photo_series(id),
 title TEXT NOT NULL, subtitle TEXT NOT NULL DEFAULT '', produced_date TEXT NOT NULL DEFAULT '',
 shot_date TEXT NOT NULL DEFAULT '', shot_place TEXT NOT NULL DEFAULT '',
 photographer TEXT NOT NULL DEFAULT '', producer TEXT NOT NULL DEFAULT '',
 people TEXT NOT NULL DEFAULT '', summary TEXT NOT NULL DEFAULT '',
 related_records TEXT NOT NULL DEFAULT '', media_type TEXT NOT NULL DEFAULT '디지털사진',
 disclosure TEXT NOT NULL DEFAULT '비공개', rights TEXT NOT NULL DEFAULT '',
 notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, created_by TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS photo_record_links (
 item_id TEXT NOT NULL REFERENCES photo_items(id), record_id TEXT NOT NULL,
 created_at TEXT NOT NULL, created_by TEXT NOT NULL,
 PRIMARY KEY(item_id,record_id)
);
CREATE INDEX IF NOT EXISTS ix_photo_links_record ON photo_record_links(record_id);
CREATE INDEX IF NOT EXISTS ix_photo_items_series ON photo_items(series_id);
CREATE TABLE IF NOT EXISTS photo_files (
 id TEXT PRIMARY KEY, item_id TEXT NOT NULL REFERENCES photo_items(id),
 original_name TEXT NOT NULL, stored_name TEXT NOT NULL UNIQUE,
 format TEXT NOT NULL, size_bytes INTEGER NOT NULL, sha256 TEXT NOT NULL,
 width INTEGER NOT NULL, height INTEGER NOT NULL, uploaded_at TEXT NOT NULL,
 uploaded_by TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_photo_files_item ON photo_files(item_id);
CREATE UNIQUE INDEX IF NOT EXISTS ix_photo_files_hash ON photo_files(sha256);
'''
SERIES_FIELDS=('title','department','classification','classification_year','classification_id','start_year','end_year','retention','retention_reason','disclosure','notes')
ITEM_FIELDS=('title','subtitle','produced_date','shot_date','shot_place','photographer','producer','people','summary','related_records','media_type','disclosure','rights','notes')
VISIBILITY=('공개','부분공개','비공개')
IMAGE_FORMATS={'JPEG':('jpg','image/jpeg'),'PNG':('png','image/png'),'WEBP':('webp','image/webp'),'TIFF':('tif','image/tiff')}
MAX_IMAGE=30*1024*1024


def ensure_tables(cfg):
    with core.dbconnect(cfg) as db:
        db.executescript(SCHEMA)
        # Existing v2.9.11–13 databases contain photo_series without these
        # linkage fields. Migrate additively; never rewrite prior records.
        cols={r['name'] for r in db.execute('PRAGMA table_info(photo_series)')}
        if 'classification_year' not in cols:
            db.execute('ALTER TABLE photo_series ADD COLUMN classification_year INTEGER')
        if 'classification_id' not in cols:
            db.execute("ALTER TABLE photo_series ADD COLUMN classification_id TEXT NOT NULL DEFAULT ''")


@lru_cache(maxsize=1)
def _bundled_classifications():
    """Read exactly the catalogs displayed by manager.js; avoid a second copy."""
    source=(core.STATIC_ROOT/'manager.js').read_text(encoding='utf-8')
    marker='const CLASSIFICATION_BUNDLED='
    if marker not in source:raise core.UserError('기록물분류기준표를 읽을 수 없습니다.',500)
    catalogs,_=json.JSONDecoder().raw_decode(source.split(marker,1)[1])
    return catalogs


def _classification_overrides(db):
    try:row=db.execute('SELECT json_data FROM archive_state WHERE id=1').fetchone()
    except sqlite3.OperationalError:return {}
    if not row:return {}
    state=json.loads(row['json_data'])
    values=state.get('classificationOverrides') or {}
    return values if isinstance(values,dict) else {}


def _catalog(db,year):
    override=_classification_overrides(db).get(str(year))
    if isinstance(override,dict) and isinstance(override.get('rows'),list):return override['rows']
    return _bundled_classifications().get(str(year),[])


def _retention(value):
    value=str(value or '').strip()
    return value[:-1] if re.fullmatch(r'\d+년',value) else value


def _weight(value):
    value=_retention(value)
    return 100000 if value=='영구' else 10000 if value=='준영구' else int(value) if value.isdigit() else -1


def _classification_row(db,year,identity):
    return next((r for r in _catalog(db,year) if str(r.get('id',''))==identity),None)


def classifications(handler):
    core.confirm_role(handler,'admin')
    query=parse_qs(urlsplit(handler.path).query)
    year_arg=query.get('year',[''])[0]
    dept=_text(query.get('department',[''])[0],100)
    with core.dbconnect(handler.cfg) as db:
        overrides=_classification_overrides(db)
        years=sorted({int(y) for y in [*_bundled_classifications(),*overrides] if str(y).isdigit() and 1900<=int(y)<=2100},reverse=True)
        rows=[]
        if year_arg:
            if not re.fullmatch(r'\d{4}',year_arg):raise core.UserError('기준표 연도가 올바르지 않습니다.')
            rows=_catalog(db,int(year_arg))
        if dept:rows=[r for r in rows if r.get('department') in (dept,'처리과 공통')]
    # The browser receives catalog metadata, not the entire archive_state.
    return handler.json_out({'years':years,'rows':[
        {k:str(r.get(k,'') or '') for k in ('id','department','big','middle','small','unit','fileSeries','fileRetention','unitRetention','reason')}
        for r in rows if isinstance(r,dict)
    ]})


def _one(db,table,identity):
    row=db.execute(f'SELECT * FROM {table} WHERE id=?',(identity,)).fetchone()
    if not row: raise core.UserError('해당 사진기록물을 찾을 수 없습니다.',404)
    return dict(row)


def _text(value,limit=1000):
    value=str(value or '').strip()
    if len(value)>limit: raise core.UserError('입력 내용이 너무 깁니다.')
    return value


def _sanitize(payload,fields):
    result={}
    for name in fields:
        if name in ('start_year','end_year','classification_year'):
            value=payload.get(name)
            if value in ('',None): result[name]=None
            else:
                try: result[name]=int(value)
                except (ValueError,TypeError): raise core.UserError('생산연도는 숫자로 입력해 주세요.')
                if not 1900<=result[name]<=2100: raise core.UserError('연도 범위를 확인해 주세요.')
        else:
            result[name]=_text(payload.get(name),5000 if name in ('summary','notes','retention_reason') else 600)
    if not result['title']: raise core.UserError('사진기록물명은 필수입니다.')
    if 'department' in fields and not result['department']: raise core.UserError('생산부서를 입력해 주세요.')
    if result['disclosure'] not in VISIBILITY: raise core.UserError('공개구분을 선택해 주세요.')
    if 'start_year' in fields and result['start_year'] and result['end_year'] and result['start_year']>result['end_year']:
        raise core.UserError('생산 종료연도는 시작연도보다 빠를 수 없습니다.')
    if 'shot_date' in fields:
        for field in ('produced_date','shot_date'):
            if result[field]:
                try: datetime.strptime(result[field],'%Y-%m-%d')
                except ValueError: raise core.UserError('날짜 형식은 YYYY-MM-DD입니다.')
    return result


def _actor(handler):
    session=handler.check_csrf()
    if session['role']!='admin': raise core.UserError('관리자만 사진기록물을 등록·수정할 수 있습니다.',403)
    return session['user']


def listing(handler):
    session=core.confirm_role(handler)
    admin=session['role']=='admin'
    query=parse_qs(urlsplit(handler.path).query)
    selected=query.get('series',[''])[0]
    keyword=_text(query.get('q',[''])[0],100)
    field=query.get('field',['all'])[0]
    search_fields={
        'title':('i.title',),
        'department':('s.department',),
        'shot_date':('i.shot_date',),
        'people':('i.people',),
        'shot_place':('i.shot_place',),
        'all':('i.title','i.subtitle','i.summary','i.shot_place','i.people','s.department','i.shot_date')
    }
    if field not in search_fields:raise core.UserError('지원하지 않는 사진 검색항목입니다.')
    with core.dbconnect(handler.cfg) as db:
        visible=''
        series=[dict(row) for row in db.execute('SELECT * FROM photo_series'+visible+' ORDER BY created_at DESC,id DESC')]
        conditions=[]; params=[]
        if selected:
            conditions.append('i.series_id=?');params.append(selected)
        if keyword:
            if field=='shot_date':
                try:
                    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',keyword):raise ValueError('bad date format')
                    datetime.strptime(keyword,'%Y-%m-%d')
                except ValueError:raise core.UserError('촬영일자는 YYYY-MM-DD 형식으로 선택해 주세요.')
                conditions.append('i.shot_date=?');params.append(keyword)
            else:
                fields=search_fields[field]
                conditions.append('('+' OR '.join(col+' LIKE ?' for col in fields)+')')
                params.extend(['%'+keyword+'%']*len(fields))
        clause=' WHERE '+' AND '.join(conditions) if conditions else ''
        items=[dict(row) for row in db.execute('''
          SELECT i.*,s.title AS series_title,s.department AS department,s.disclosure AS series_disclosure,
          (SELECT count(*) FROM photo_files f WHERE f.item_id=i.id) AS file_count,
          (SELECT f.id FROM photo_files f WHERE f.item_id=i.id ORDER BY uploaded_at,f.id LIMIT 1) AS cover_file
          FROM photo_items i JOIN photo_series s ON s.id=i.series_id
        '''+clause+' ORDER BY i.created_at DESC,i.id DESC LIMIT 2000',params)]
        if not admin:
            for item in items:
                item['effective_disclosure']=('비공개' if '비공개' in (item['disclosure'],item['series_disclosure']) else '부분공개' if '부분공개' in (item['disclosure'],item['series_disclosure']) else '공개')
                if item['effective_disclosure']!='공개':
                    item['cover_file']=None
                    # Search metadata is available; protected descriptive content stays private.
                    for key in ('subtitle','summary','shot_place','photographer','producer','people','rights'):
                        item[key]=''
    if not admin:
        series_keys=('id','title','department','classification','start_year','end_year','retention','disclosure')
        item_keys=('id','series_id','title','subtitle','produced_date','shot_date','shot_place',
                   'photographer','producer','people','summary','media_type','disclosure','rights',
                   'series_title','department','file_count','cover_file','effective_disclosure')
        series=[{k:s[k] for k in series_keys} for s in series]
        items=[{k:i[k] for k in item_keys} for i in items]
    return handler.json_out({'series':series,'items':items,'watermark':photo_watermark.status()})


def detail(handler,item_id):
    session=core.confirm_role(handler)
    with core.dbconnect(handler.cfg) as db:
        item=_one(db,'photo_items',item_id)
        parent=_one(db,'photo_series',item['series_id'])
        is_public=photo_access.public(item,parent)
        allowed={} if session['role']=='admin' or is_public else photo_access.grants(db,session['user'],item_id)
        files=[dict(row) for row in db.execute('SELECT * FROM photo_files WHERE item_id=? ORDER BY uploaded_at,id',(item_id,))]
        expiries={r['id']:r['grant_expires_at'] for r in db.execute("SELECT id,grant_expires_at FROM access_requests WHERE target_kind='photo' AND applicant=? AND record_id=?",(session['user'],item_id))} if allowed else {}
        for f in files:f['grant_expires_at']=expiries.get(allowed.get(f['id']), '')
    file_count=len(files)
    if session['role']!='admin':
        if not is_public:
            files=[f for f in files if f['id'] in allowed]
            for key in ('subtitle','summary','shot_place','photographer','producer','people','related_records','rights'):
                item[key]=''
        item_keys=('id','series_id','title','subtitle','produced_date','shot_date','shot_place',
                   'photographer','producer','people','summary','related_records','media_type','disclosure','rights')
        series_keys=('id','title','department','classification','start_year','end_year','retention','disclosure')
        file_keys=('id','item_id','original_name','format','size_bytes','width','height','grant_expires_at')
        item={k:item[k] for k in item_keys}
        parent={k:parent[k] for k in series_keys}
        files=[{k:f[k] for k in file_keys} for f in files]
    activity_log.write(handler,'기록물 이용','시청각 상세정보 조회',ses=session,
                       kind='photo_item',target=item_id,title=item['title'])
    return handler.json_out({'item':item,'series':parent,'files':files,'file_count':file_count,
        'requires_approval':not is_public,'can_view':bool(files),'watermark':photo_watermark.status(),
        'effective_disclosure':'공개' if is_public else '비공개' if '비공개' in (item['disclosure'],parent['disclosure']) else '부분공개'})


def save(handler,kind,identity=None):
    if kind not in ('series','items'): raise core.UserError('지원하지 않는 등록 형식입니다.',404)
    actor=_actor(handler)
    payload=handler.json_in()
    fields=SERIES_FIELDS if kind=='series' else ITEM_FIELDS
    data=_sanitize(payload,fields)
    table='photo_series' if kind=='series' else 'photo_items'
    now=core.now()
    with core.dbconnect(handler.cfg) as db:
        if kind=='series':
            classification_id=data['classification_id']
            if classification_id:
                year=data['classification_year']
                if not year:raise core.UserError('연계할 기록물분류기준표 연도를 선택해 주세요.')
                if data['start_year'] and max(2024,data['start_year'])!=year:
                    raise core.UserError('기준표 연도는 생산 시작연도에 해당하는 연도여야 합니다. (2024년 이전은 2024년 기준표)')
                row=_classification_row(db,year,classification_id)
                if not row:raise core.UserError('선택한 기록물분류기준표 항목을 찾을 수 없습니다.')
                if row.get('department') not in (data['department'],'처리과 공통'):
                    raise core.UserError('선택한 분류기준표의 생산부서가 기록물철과 다릅니다.')
                retention=str(row.get('fileRetention','')).strip()
                if _weight(retention)<0 or _weight(retention)>_weight(row.get('unitRetention')):
                    raise core.UserError('분류기준표의 보존기간이 단위과제 기준과 맞지 않습니다.')
                data['classification']=_text(' > '.join(str(row.get(k,'')).strip() for k in ('unit','fileSeries') if row.get(k)),600)
                data['retention']=retention
                data['retention_reason']=_text(row.get('reason'),5000)
            else:
                data['classification_year']=None
        if identity:
            _one(db,table,identity)
            values=[data[k] for k in fields]+[now,identity]
            db.execute(f'UPDATE {table} SET '+','.join(k+'=?' for k in fields)+',updated_at=? WHERE id=?',values)
        else:
            identity=secrets.token_hex(12)
            if kind=='items':
                parent=_text(payload.get('series_id'),80)
                _one(db,'photo_series',parent)
                cols=('id','series_id',*fields,'created_at','created_by','updated_at')
                values=[identity,parent,*[data[k] for k in fields],now,actor,now]
            else:
                cols=('id',*fields,'created_at','created_by','updated_at')
                values=[identity,*[data[k] for k in fields],now,actor,now]
            db.execute(f'INSERT INTO {table} ({",".join(cols)}) VALUES ({",".join("?" for _ in cols)})',values)
        core.audit(db,actor,'사진기록물 '+('수정' if handler.command=='PUT' else '등록'),table,identity,data['title'])
    return handler.json_out({'ok':True,'id':identity})


def upload(handler,item_id=None,series_id=None):
    actor=_actor(handler)
    from PIL import Image,UnidentifiedImageError
    data=None
    if series_id:
        try: payload=json.loads(unquote(handler.headers.get('X-Photo-Metadata','{}')))
        except (ValueError,TypeError): raise core.UserError('일괄등록 정보가 올바르지 않습니다.')
        if not isinstance(payload,dict): raise core.UserError('일괄등록 정보를 확인해 주세요.')
        data=_sanitize(payload,ITEM_FIELDS)
        item_id=secrets.token_hex(12)
    with core.dbconnect(handler.cfg) as db:
        _one(db,'photo_series' if series_id else 'photo_items',series_id or item_id)
    original=unquote(handler.headers.get('X-Original-Filename',''))
    original=Path(original.replace('\\','/')).name
    if not original or len(original)>240: raise core.UserError('원본 파일명을 확인해 주세요.')
    raw=handler.input_bytes(MAX_IMAGE)
    if not raw: raise core.UserError('빈 사진 파일입니다.')
    try:
        with Image.open(io.BytesIO(raw)) as im:
            fmt=im.format
            width,height=im.size
            if fmt not in IMAGE_FORMATS or width<1 or height<1 or width*height>80_000_000:
                raise core.UserError('JPG·PNG·WEBP·TIFF 이미지(8천만 픽셀 이하)만 등록할 수 있습니다.')
            im.verify()
        with Image.open(io.BytesIO(raw)) as im:
            im.thumbnail((480,480))
            if im.mode not in ('RGB','L'): im=im.convert('RGB')
            thumb=io.BytesIO();im.save(thumb,'JPEG',quality=76)
        with Image.open(io.BytesIO(raw)) as im:
            # Employee view is a separate, reasonably large derivative.
            # Only administrators may retrieve unchanged original bytes.
            im.thumbnail((1800,1800))
            if im.mode not in ('RGB','L'): im=im.convert('RGB')
            view=io.BytesIO();im.save(view,'JPEG',quality=87)
    except core.UserError: raise
    except (UnidentifiedImageError,OSError,ValueError,SyntaxError,Image.DecompressionBombError):
        raise core.UserError('이미지 파일을 열 수 없습니다. 파일 손상을 확인해 주세요.')
    sha=hashlib.sha256(raw).hexdigest()
    folder=Path(handler.cfg['media_dir'])/'photo_records'
    suffix,mime=IMAGE_FORMATS[fmt]
    file_id=secrets.token_hex(16)
    stored_name=file_id+'.'+suffix
    folder.mkdir(parents=True,exist_ok=True)
    with core.dbconnect(handler.cfg) as db:
        existing=db.execute('SELECT id,item_id FROM photo_files WHERE sha256=?',(sha,)).fetchone()
        if existing: raise core.UserError('동일한 원본 파일이 이미 등록되어 있습니다. (SHA-256 중복)',409)
        original_path=folder/stored_name
        preview_path=folder/(file_id+'.preview.jpg')
        view_path=folder/(file_id+'.view.jpg')
        try:
            if data is not None:
                _one(db,'photo_series',series_id)
                cols=('id','series_id',*ITEM_FIELDS,'created_at','created_by','updated_at')
                now=core.now()
                db.execute(f'INSERT INTO photo_items ({",".join(cols)}) VALUES ({",".join("?" for _ in cols)})',
                           [item_id,series_id,*[data[k] for k in ITEM_FIELDS],now,actor,now])
                core.audit(db,actor,'사진 일괄등록','photo_items',item_id,data['title'])
            with original_path.open('xb') as f: f.write(raw)
            with preview_path.open('xb') as f: f.write(thumb.getvalue())
            with view_path.open('xb') as f: f.write(view.getvalue())
            db.execute('''INSERT INTO photo_files(id,item_id,original_name,stored_name,format,size_bytes,sha256,width,height,uploaded_at,uploaded_by)
                          VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(file_id,item_id,original,stored_name,mime,len(raw),sha,width,height,core.now(),actor))
            core.audit(db,actor,'사진 원본 등록','photo_files',file_id,original)
        except sqlite3.IntegrityError:
            original_path.unlink(missing_ok=True);preview_path.unlink(missing_ok=True);view_path.unlink(missing_ok=True)
            raise core.UserError('동일한 원본 파일이 이미 등록되어 있습니다. (SHA-256 중복)',409)
        except Exception:
            original_path.unlink(missing_ok=True);preview_path.unlink(missing_ok=True);view_path.unlink(missing_ok=True)
            raise
    return handler.json_out({'ok':True,'id':file_id,'item_id':item_id,'sha256':sha,'size_bytes':len(raw)})


def image(handler,file_id,preview=False,view=False):
    session=core.confirm_role(handler)
    with core.dbconnect(handler.cfg) as db:
        row=db.execute('''SELECT f.*,i.disclosure AS item_disclosure,s.disclosure AS series_disclosure
              FROM photo_files f JOIN photo_items i ON i.id=f.item_id
              JOIN photo_series s ON s.id=i.series_id WHERE f.id=?''',(file_id,)).fetchone()
    if not row: raise core.UserError('사진 파일을 찾을 수 없습니다.',404)
    request_id=''
    if session['role']!='admin' and (row['item_disclosure']!='공개' or row['series_disclosure']!='공개'):
        with core.dbconnect(handler.cfg) as db:
            request_id=photo_access.grants(db,session['user'],row['item_id']).get(file_id,'')
        if not request_id:raise core.UserError('승인된 사진 열람기간이 아니거나 허용되지 않은 사진입니다.',403)
    if session['role']!='admin' and not (preview or view):
        raise core.UserError('직원 열람페이지에서는 사진 원본 다운로드를 제공하지 않습니다.',403)
    folder=Path(handler.cfg['media_dir'])/'photo_records'
    filename=file_id+'.preview.jpg' if preview else file_id+'.view.jpg' if view else row['stored_name']
    path=folder/filename
    if view or preview:
        # All employee and administrator previews/views is personalized, after the disclosure/grant checks above.
        # Thumbnails remain unlogged. For legacy photos use the original only as input to a bounded, marked derivative.
        if not path.is_file():
            original=folder/row['stored_name']
            path=original if original.is_file() else folder/(file_id+'.preview.jpg')
        if not path.is_file():raise core.UserError('저장된 이미지 파일을 찾을 수 없습니다.',404)
        viewed_at=photo_watermark.timestamp()
        raw=photo_watermark.render(path,session['user'],viewed_at)
        if view:_log_image(handler,session,row,True,request_id,viewed_at)
        return handler.response_bytes(raw,ctype='image/jpeg',extra={
            'Cache-Control':'private, no-store, max-age=0','Pragma':'no-cache',
            'Vary':'Cookie','X-GuriArchive-Watermark':photo_watermark.VERSION,'Content-Disposition':'inline; filename=photo-view.jpg'})
    if not path.is_file(): raise core.UserError('저장된 이미지 파일을 찾을 수 없습니다.',404)
    ext=row['stored_name'].rsplit('.',1)[-1]
    header={'Content-Disposition':f"attachment; filename=photo-{file_id}.{ext}; filename*=UTF-8''{quote(row['original_name'],safe='')}"} if not (preview or view) else None
    raw=path.read_bytes()
    if not preview: _log_image(handler,session,row,view,request_id)
    return handler.response_bytes(raw,ctype='image/jpeg' if preview or view else row['format'],
                                  extra={**(header or {}),'Cache-Control':'no-store'})


def _log_image(handler,session,row,view,request_id,viewed_at=''):
    activity_log.write(handler,'기록물 이용','시청각 이미지 열람' if view else '시청각 원본 다운로드',
                       ses=session,kind='photo_item',target=row['item_id'],title=row['original_name'],detail='파일 ID: '+row['id']+(' / 신청번호 '+request_id if request_id else ' / 공개 또는 관리자 열람')+(' / 워터마크 열람일시: '+viewed_at if viewed_at else ''))


def links(handler,update=False):
    core.confirm_role(handler,'admin')
    actor=_actor(handler) if update else None
    payload=handler.json_in() if update else {}
    q=parse_qs(urlsplit(handler.path).query)
    item_id=_text(payload.get('item_id') if update else q.get('item',[''])[0],80)
    record_id=_text(payload.get('record_id') if update else q.get('record',[''])[0],100)
    with core.dbconnect(handler.cfg) as db:
        row=db.execute('SELECT json_data FROM archive_state WHERE id=1').fetchone()
        records=json.loads(row['json_data']).get('records',[]) if row else []
        by_id={str(r['id']):r for r in records}
        if update:
            _one(db,'photo_items',item_id)
            action=payload.get('action')
            if action not in ('add','remove'): raise core.UserError('연계 작업을 확인해 주세요.')
            if action=='add':
                if record_id not in by_id: raise core.UserError('일반기록물을 찾을 수 없습니다.',404)
                db.execute('INSERT OR IGNORE INTO photo_record_links VALUES(?,?,?,?)',(item_id,record_id,core.now(),actor))
            else: db.execute('DELETE FROM photo_record_links WHERE item_id=? AND record_id=?',(item_id,record_id))
            core.audit(db,actor,'사진 연계 '+action,'photo_items',item_id,record_id)
            return handler.json_out({'ok':True})
        if item_id:
            _one(db,'photo_items',item_id)
            linked=[r['record_id'] for r in db.execute('SELECT record_id FROM photo_record_links WHERE item_id=?',(item_id,))]
            keyword=q.get('q',[''])[0].strip().lower()
            candidates=[r for r in records if not keyword or keyword in (str(r['id'])+' '+r.get('title','')+' '+r.get('dept','')).lower()][:100]
            def summary(r): return {k:r.get(k,'') for k in ('id','title','dept','year','disclosure')}
            return handler.json_out({'linked':[summary(by_id[r]) if r in by_id else {'id':r,'title':'삭제 또는 복원으로 현재 목록에 없는 기록물'} for r in linked],
                                     'candidates':[summary(r) for r in candidates]})
        if record_id not in by_id: raise core.UserError('일반기록물을 찾을 수 없습니다.',404)
        items=[dict(r) for r in db.execute('SELECT i.id,i.title,i.series_id FROM photo_items i JOIN photo_record_links l ON l.item_id=i.id WHERE l.record_id=?',(record_id,))]
        return handler.json_out({'record':{k:by_id[record_id].get(k,'') for k in ('id','title','dept','year','disclosure')},'items':items})

