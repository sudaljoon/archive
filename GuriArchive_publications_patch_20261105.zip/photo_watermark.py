"""Personalized in-memory photo derivatives. Never writes original or cached images."""
import datetime as dt
import io
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps, UnidentifiedImageError
import core

ASSETS = Path(__file__).resolve().parent / 'watermark_assets'
KST = dt.timezone(dt.timedelta(hours=9))
VERSION = '2026.11.05-v3-center'


def status():
    try:
        if not (ASSETS / 'GuriArchiveWatermarkSans.otf').is_file():
            raise OSError('Missing font')
        if not (core.STATIC_ROOT / 'logo.png').is_file():
            raise OSError('Missing logo')
        _font(13)
        _logo()
        return {'version': VERSION, 'ready': True}
    except (OSError, ValueError):
        return {'version': VERSION, 'ready': False}


def timestamp():
    return dt.datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S KST')


@lru_cache(maxsize=1)
def _logo():
    # Reuse the institution's existing transparent logo; alpha preserves its exact shape.
    with Image.open(core.STATIC_ROOT / 'logo.png') as im:
        alpha = im.convert('RGBA').getchannel('A')
        if alpha.getbbox() is None:
            raise OSError('Empty institution logo')
        return alpha.crop(alpha.getbbox())


@lru_cache(maxsize=48)
def _font(size):
    # Bundled font keeps Korean readable on Windows and Linux without font installation.
    return ImageFont.truetype(str(ASSETS / 'GuriArchiveWatermarkSans.otf'), size)


def render(path, user, viewed_at):
    """Blend a translucent, personalized watermark into the center of the photo."""
    try:
        with Image.open(path) as source:
            if source.width * source.height > 80_000_000:
                raise ValueError('Image exceeds supported size')
            image = ImageOps.exif_transpose(source).convert('RGB')
            image.thumbnail((1800, 1800), Image.Resampling.LANCZOS)
        # Enlarge only small derivatives for legibility; preserve the photo's aspect ratio.
        scale = min(480 / min(image.size), 1800 / max(image.size))
        if scale > 1:
            image = image.resize(tuple(max(1, round(v * scale)) for v in image.size), Image.Resampling.LANCZOS)
        width, height = image.size
        identity = str(user).replace('\r', ' ').replace('\n', ' ').replace('\x00', '')[:64]
        labels = (f'열람자 ID: {identity}', f'열람일시: {viewed_at}', '열람용 · 원본 다운로드 불가')
        size = max(1, min(36, round(width * .026), round(height * .04)))
        measure = ImageDraw.Draw(image)
        while size > 1 and any(measure.textlength(t, font=_font(size)) > width * .88 for t in labels):
            size -= 1
        font = _font(size)
        line_height = max(1, round(size * 1.55))
        gap = max(1, round(size * .5))
        logo = _logo().copy()
        logo.thumbnail((max(1, round(width * .68)), max(1, round(height * .16))), Image.Resampling.LANCZOS)
        group_height = logo.height + gap + line_height * len(labels)
        top = max(0, (height - group_height) // 2)
        left = (width - logo.width) // 2
        # White ink with a subtle black outline stays visible on mixed light/dark areas.
        # The entire layer is alpha-composited, including its outline, so it is translucent.
        overlay = Image.new('RGBA', image.size, (0, 0, 0, 0))
        logo_shadow = Image.new('RGBA', image.size, (0, 0, 0, 0))
        from PIL import ImageFilter
        outline = logo.filter(ImageFilter.MaxFilter(3))
        logo_shadow.paste((0, 0, 0, 58), (left, top), outline)
        overlay = Image.alpha_composite(overlay, logo_shadow)
        ink = Image.new('RGBA', logo.size, (255, 255, 255, 0))
        ink.putalpha(logo.point(lambda value: round(value * .29)))
        overlay.alpha_composite(ink, (left, top))
        draw = ImageDraw.Draw(overlay)
        for n, label in enumerate(labels):
            draw.text((width // 2, top + logo.height + gap + n * line_height), label,
                      anchor='mt', font=font, fill=(255, 255, 255, 98),
                      stroke_width=max(1, size // 18), stroke_fill=(0, 0, 0, 65))
        result = Image.alpha_composite(image.convert('RGBA'), overlay).convert('RGB')
        out = io.BytesIO()
        result.save(out, 'JPEG', quality=87, optimize=True)
        return out.getvalue()
    except (OSError, ValueError, SyntaxError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        # Fail closed: never return an unmarked image when rendering fails.
        raise core.UserError('워터마크 생성에 실패했습니다. 로고·글꼴 및 사진 파일을 확인해 주세요.', 503) from exc
