"""구리농수산물공사 비전자기록물 관리 v1.9: 내부망 시범용 표준 라이브러리 서버.

실제 운영 전: 기관 보안승인, HTTPS 역방향 프록시, 개인별 직원 인증/SSO,
별도 백업, 접근권한·비공개 관리 정책 및 보안점검이 필요합니다.
"""
import base64
import csv
from contextlib import contextmanager
import datetime as dt
import hashlib
import hmac
import io
import json
import logging
import mimetypes
import os
import secrets
import sqlite3
import sys
import threading
import time
import urllib.parse
import uuid
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / 'config.json'
STATIC_ROOT = ROOT / 'static'
MAX_JSON = 1_000_000
MAX_XLSX = 7_000_000
MAX_PHOTO = 8_000_000
WRITE_LOCK = threading.RLock()
ACTIVE_SESSIONS = {}  # process-memory only; expires after 8h, resets on restart
LOGIN_FAILURES = {}   # IP -> recent failure timestamps
RECORD_TYPES = {'일반문서', '대장', '도면', '사진', '카드', '기타'}
RETENTION = {'1년', '3년', '5년', '10년', '30년', '준영구', '영구'}
DISCLOSURE = {'공개', '부분공개', '비공개'}
ARTIFACT_TYPES = {'관인류', '견본류', '상징류', '기념류', '상장·상패류', '사무집기류', '그 밖의 유형'}
DECISIONS = {'보류', '보존기간 연장', '폐기 결정'}

class UserError(Exception):
    def __init__(self, message, code=400):
        super().__init__(message)
        self.code = code


def today(): return dt.date.today().isoformat()
def now(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')

def secure_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    value = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 550_000)
    return f'pbkdf2_sha256$550000${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(value).decode()}'

def check_hash(password, stored):
    try:
        method, iterations, salt, val = stored.split('$')
        if method != 'pbkdf2_sha256': return False
        rawsalt = base64.urlsafe_b64decode(salt)
        digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), rawsalt, int(iterations))
        return hmac.compare_digest(digest, base64.urlsafe_b64decode(val))
    except (ValueError, TypeError): return False

def config():
    if not CONFIG_PATH.exists():
        raise RuntimeError('먼저 python setup.py 를 실행하세요. (config.json 없음)')
    cfg = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
    cfg['db_path'] = str(Path(cfg['db_path']).expanduser().resolve())
    cfg['media_dir'] = str(Path(cfg['media_dir']).expanduser().resolve())
    return cfg

@contextmanager
def dbconnect(cfg):
    conn = sqlite3.connect(cfg['db_path'], timeout=15)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA foreign_keys = ON')
        conn.execute('PRAGMA busy_timeout = 15000')
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def initialize_db(cfg):
    Path(cfg['db_path']).parent.mkdir(parents=True, exist_ok=True)
    Path(cfg['media_dir']).mkdir(parents=True, exist_ok=True)
    with dbconnect(cfg) as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
        CREATE TABLE IF NOT EXISTS users (
          username TEXT PRIMARY KEY, password_hash TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('admin','viewer'))
        );
        CREATE TABLE IF NOT EXISTS records (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL, department TEXT NOT NULL,
          completion_year INTEGER, start_year_override INTEGER, retention TEXT NOT NULL DEFAULT '',
          item_type TEXT NOT NULL DEFAULT '일반문서', quantity INTEGER NOT NULL DEFAULT 1,
          classification TEXT NOT NULL DEFAULT '', original_no TEXT NOT NULL DEFAULT '',
          box_no TEXT NOT NULL DEFAULT '', location TEXT NOT NULL DEFAULT '',
          disclosure TEXT NOT NULL DEFAULT '비공개', note TEXT NOT NULL DEFAULT '',
          status TEXT NOT NULL DEFAULT '보존 중', decision TEXT NOT NULL DEFAULT '',
          review_ref TEXT NOT NULL DEFAULT '', review_date TEXT NOT NULL DEFAULT '',
          review_note TEXT NOT NULL DEFAULT '', execution_date TEXT NOT NULL DEFAULT '',
          executor TEXT NOT NULL DEFAULT '', execution_ref TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS loans (
          id INTEGER PRIMARY KEY AUTOINCREMENT, record_id INTEGER NOT NULL, borrower TEXT NOT NULL,
          checked_out_at TEXT NOT NULL, expected_return TEXT NOT NULL DEFAULT '',
          returned_at TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
          FOREIGN KEY(record_id) REFERENCES records(id)
        );
        CREATE TABLE IF NOT EXISTS transfers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          file_name TEXT NOT NULL, title TEXT NOT NULL, department TEXT NOT NULL,
          completion_year INTEGER, retention TEXT NOT NULL DEFAULT '',
          item_type TEXT NOT NULL DEFAULT '일반문서', quantity INTEGER NOT NULL DEFAULT 1,
          classification TEXT NOT NULL DEFAULT '', original_no TEXT NOT NULL DEFAULT '',
          disclosure TEXT NOT NULL DEFAULT '비공개', note TEXT NOT NULL DEFAULT '',
          state TEXT NOT NULL DEFAULT '접수', check_note TEXT NOT NULL DEFAULT '',
          record_id INTEGER, received_at TEXT NOT NULL,
          FOREIGN KEY(record_id) REFERENCES records(id)
        );
        CREATE TABLE IF NOT EXISTS artifacts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL, category TEXT NOT NULL, department TEXT NOT NULL,
          production_date TEXT NOT NULL DEFAULT '', end_date TEXT NOT NULL DEFAULT '',
          material TEXT NOT NULL DEFAULT '', dimensions TEXT NOT NULL DEFAULT '',
          quantity INTEGER NOT NULL DEFAULT 1, content TEXT NOT NULL DEFAULT '',
          related_no TEXT NOT NULL DEFAULT '', receipt_date TEXT NOT NULL DEFAULT '',
          receipt_cause TEXT NOT NULL DEFAULT '', selection_basis TEXT NOT NULL DEFAULT '',
          condition TEXT NOT NULL DEFAULT '', location TEXT NOT NULL DEFAULT '',
          disclosure TEXT NOT NULL DEFAULT '비공개', image_name TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit (
          id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, actor TEXT NOT NULL,
          action TEXT NOT NULL, object_type TEXT NOT NULL, object_id INTEGER,
          detail TEXT NOT NULL DEFAULT ''
        );
        ''')
        db.commit()

def audit(db, actor, action, kind, rowid, detail=''):
    db.execute('INSERT INTO audit(at,actor,action,object_type,object_id,detail) VALUES(?,?,?,?,?,?)',
               (now(), actor, action, kind, rowid, detail[:1200]))

def clean(value, limit=250):
    return str(value if value is not None else '').strip()[:limit]

def int_field(value, label, low, high, optional=False):
    if value is None or str(value).strip() == '':
        if optional: return None
        raise UserError(f'{label} 항목을 입력하세요.')
    try: n = int(value)
    except (ValueError, TypeError): raise UserError(f'{label}: 숫자로 입력하세요.')
    if not low <= n <= high: raise UserError(f'{label}: {low}~{high} 범위에서 입력하세요.')
    return n

def parse_location(value):
    loc = clean(value, 24).upper()
    if not loc: return ''
    parts = loc.split('-')
    if len(parts) != 4 or parts[0] != 'A':
        raise UserError('1번 서고 위치는 A-01-01-01 형식으로 입력하세요. 2번 서고는 아직 규격 미설정입니다.')
    try: rack,shelf,slot = map(int, parts[1:])
    except ValueError: raise UserError('위치코드가 잘못되었습니다.')
    if not (1 <= rack <= 19 and 1 <= shelf <= 6 and 1 <= slot <= 4):
        raise UserError('1번 서고 위치 범위: 모빌랙 1~19, 단 1~6, 칸 1~4')
    return f'A-{rack:02d}-{shelf:02d}-{slot:02d}'

def retention_info(year, retention, override=None):
    if not year and not override: return dict(start_year=None, expiry_year=None, review_year=None)
    start = override or (year + 1)
    if retention not in RETENTION: return dict(start_year=start, expiry_year=None, review_year=None)
    if retention in ('영구','준영구'): return dict(start_year=start, expiry_year=None, review_year=None)
    expiry = start + int(retention.removesuffix('년')) - 1
    return dict(start_year=start, expiry_year=expiry, review_year=expiry+1)

def record_data(inp):
    title, dep = clean(inp.get('title')), clean(inp.get('department'))
    if not title or not dep: raise UserError('기록물철명과 생산부서는 필수입니다.')
    year = int_field(inp.get('completion_year'), '처리완결연도', 1900, 2200, optional=True)
    retention = clean(inp.get('retention'), 12)
    if retention and retention not in RETENTION: raise UserError('보존기간을 확인하세요.')
    kind = clean(inp.get('item_type') or '일반문서', 30)
    if kind not in RECORD_TYPES: raise UserError('행정박물은 별도 행정박물 관리 메뉴에서 등록하세요.')
    disclosure = clean(inp.get('disclosure') or '비공개', 15)
    if disclosure not in DISCLOSURE: raise UserError('공개구분을 확인하세요.')
    return dict(title=title,department=dep,completion_year=year,start_year_override=int_field(inp.get('start_year_override'),'기산연도 수동지정',1900,2300,optional=True),retention=retention,
      item_type=kind,quantity=int_field(inp.get('quantity',1),'수량',1,100000),
      classification=clean(inp.get('classification')),original_no=clean(inp.get('original_no')),
      box_no=clean(inp.get('box_no')),location=parse_location(inp.get('location')),
      disclosure=disclosure,note=clean(inp.get('note'),2000))

def artifact_data(inp):
    name,dep=clean(inp.get('name')),clean(inp.get('department'))
    if not name or not dep: raise UserError('행정박물명과 생산부서는 필수입니다.')
    kind = clean(inp.get('category'),35)
    if kind not in ARTIFACT_TYPES: raise UserError('행정박물 유형을 선택하세요.')
    disclosure=clean(inp.get('disclosure') or '비공개',15)
    if disclosure not in DISCLOSURE: raise UserError('공개구분을 확인하세요.')
    return dict(name=name,category=kind,department=dep,
      production_date=clean(inp.get('production_date'),30),end_date=clean(inp.get('end_date'),30),
      material=clean(inp.get('material'),200),dimensions=clean(inp.get('dimensions'),200),
      quantity=int_field(inp.get('quantity',1),'수량',1,100000),content=clean(inp.get('content'),2000),
      related_no=clean(inp.get('related_no')),receipt_date=clean(inp.get('receipt_date'),30),
      receipt_cause=clean(inp.get('receipt_cause'),500),selection_basis=clean(inp.get('selection_basis'),600),
      condition=clean(inp.get('condition'),500),location=parse_location(inp.get('location')),
      disclosure=disclosure)

def as_public_record(row):
    x=dict(row); x.update(retention_info(x['completion_year'], x['retention'], x.get('start_year_override')))
    return x

def get_rows(db, query, args=()): return [dict(r) for r in db.execute(query, args).fetchall()]

def confirm_role(handler, required='viewer'):
    session = handler.current_session()
    if not session: raise UserError('로그인이 필요합니다.',401)
    if required=='admin' and session['role']!='admin': raise UserError('관리자만 이용할 수 있습니다.',403)
    return session

class ArchiveHandler(BaseHTTPRequestHandler):
    server_version = 'GuriArchives/1.9'
    sys_version = ''
    def log_message(self, fmt, *args): logging.info('%s %s', self.address_string(), fmt % args)
    @property
    def cfg(self): return self.server.cfg
    def response_bytes(self, raw, status=200, ctype='application/octet-stream', extra=None):
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('X-Content-Type-Options','nosniff')
        # v2.9.7: Allow same-origin embedding only for five authenticated
        # administrator HTML pages and only with the explicit embedded=1 flag.
        # All other responses keep the original anti-clickjacking restrictions.
        parsed_path=urllib.parse.urlsplit(self.path)
        admin_embeddable={'/requests','/accounts','/accounts/admin','/activity','/ocr','/photos','/publications'}
        allow_admin_embed=(parsed_path.path in admin_embeddable
            and ctype.startswith('text/html')
            and urllib.parse.parse_qs(parsed_path.query).get('embedded')==['1'])
        self.send_header('X-Frame-Options','SAMEORIGIN' if allow_admin_embed else 'DENY')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Cache-Control','no-store')
        frame_ancestors="frame-ancestors 'self'" if allow_admin_embed else "frame-ancestors 'none'"
        self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; "+frame_ancestors)
        for k,v in (extra or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(raw)
    def json_out(self,obj,code=200,extra=None):
        self.response_bytes(json.dumps(obj,ensure_ascii=False,default=str).encode(),code,'application/json; charset=utf-8',extra)
    def error_out(self,exc):
        if isinstance(exc, UserError): self.json_out({'error':str(exc)},exc.code)
        else:
            logging.exception('Unhandled request error')
            self.json_out({'error':'서버 처리 중 오류가 발생했습니다.'},500)
    def current_session(self):
        cookies=SimpleCookie()
        try: cookies.load(self.headers.get('Cookie',''))
        except Exception: return None
        session_cookie=cookies.get('guri_session')
        if not session_cookie: return None
        token=session_cookie.value
        item=ACTIVE_SESSIONS.get(token)
        if not item or item['expires'] < time.time():
            ACTIVE_SESSIONS.pop(token,None)
            if item and item['expires'] < time.time():
                import activity_log
                activity_log.scan_expired(self,token,item)
            return None
        return item
    def check_csrf(self):
        ses=confirm_role(self)
        if not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),ses['csrf']):
            raise UserError('보안 확인값이 올바르지 않습니다. 새로 로그인하세요.',403)
        origin=self.headers.get('Origin','')
        if origin and urllib.parse.urlsplit(origin).netloc != self.headers.get('Host'):
            raise UserError('다른 출처의 요청은 허용되지 않습니다.',403)
        return ses
    def input_bytes(self, limit):
        try: n=int(self.headers.get('Content-Length','-1'))
        except ValueError: n=-1
        if not 0<=n<=limit: raise UserError(f'파일 또는 입력값 용량 제한을 초과했습니다. (최대 {limit//1000000}MB)',413)
        return self.rfile.read(n)
    def json_in(self):
        if 'application/json' not in self.headers.get('Content-Type',''):
            raise UserError('JSON 요청만 허용합니다.')
        data=json.loads(self.input_bytes(MAX_JSON))
        if not isinstance(data,dict): raise UserError('요청형식이 잘못되었습니다.')
        return data
    def do_GET(self):
        try: self.route_get()
        except Exception as e:self.error_out(e)
    def do_POST(self):
        try: self.route_post()
        except Exception as e:self.error_out(e)
    def do_PUT(self):
        try: self.route_put()
        except Exception as e:self.error_out(e)
    def route_get(self):
        path=urllib.parse.urlsplit(self.path).path
        if path=='/': return self.response_bytes((STATIC_ROOT/'index.html').read_bytes(),ctype='text/html; charset=utf-8')
        if path in ('/app.js','/app.css','/logo.png'):
            c={'/app.js':'text/javascript; charset=utf-8','/app.css':'text/css; charset=utf-8','/logo.png':'image/png'}
            return self.response_bytes((STATIC_ROOT/path.lstrip('/')).read_bytes(),ctype=c[path],extra={'Cache-Control':'public, max-age=60'})
        if path=='/api/session':
            ses=self.current_session()
            return self.json_out({'authenticated':bool(ses),'role':ses['role'] if ses else None,'username':ses['user'] if ses else None,'csrf':ses['csrf'] if ses else None})
        ses=confirm_role(self)
        admin=ses['role']=='admin'
        with dbconnect(self.cfg) as db:
            if path=='/api/records':
                where='1=1' if admin else "status='보존 중' AND disclosure='공개'"
                rows=get_rows(db,f'SELECT * FROM records WHERE {where} ORDER BY id DESC LIMIT 20000')
                if not admin:
                    keys=('id','title','department','completion_year','retention','item_type','quantity','location','box_no','disclosure','status')
                    rows=[{key:r.get(key) for key in keys} for r in rows]
                return self.json_out({'rows':[as_public_record(r) for r in rows]})
            if path=='/api/artifacts':
                where='1=1' if admin else "disclosure='공개'"
                rows=get_rows(db,f'SELECT * FROM artifacts WHERE {where} ORDER BY id DESC LIMIT 10000')
                if not admin:
                    keys=('id','name','category','department','production_date','quantity','location','disclosure','image_name','material','dimensions','content')
                    rows=[{key:r.get(key) for key in keys} for r in rows]
                return self.json_out({'rows':rows})
            if path.startswith('/api/artifacts/') and path.endswith('/image'):
                artifact_id=int(path.split('/')[3])
                row=db.execute('SELECT * FROM artifacts WHERE id=?',(artifact_id,)).fetchone()
                if not row: raise UserError('존재하지 않는 행정박물입니다.',404)
                if not admin and row['disclosure'] != '공개': raise UserError('조회 권한이 없습니다.',403)
                if not row['image_name']: raise UserError('등록된 사진이 없습니다.',404)
                img=Path(self.cfg['media_dir'])/row['image_name']
                if not img.is_file(): raise UserError('사진 파일을 찾을 수 없습니다.',404)
                return self.response_bytes(img.read_bytes(),ctype='image/webp')
            if path=='/api/locations':
                where='1=1' if admin else "disclosure='공개'"
                rec=get_rows(db,f"SELECT location, SUM(quantity) AS count FROM records WHERE status='보존 중' AND location!='' AND {where} GROUP BY location")
                art=get_rows(db,f"SELECT location, SUM(quantity) AS count FROM artifacts WHERE location!='' AND {where} GROUP BY location")
                return self.json_out({'record_counts':rec,'artifact_counts':art,'rack_count':19,'shelf_count':6,'slot_count':4,'archive2_configured':False,'counts_are_filtered':not admin})
            if path=='/api/loans':
                confirm_role(self,'admin')
                return self.json_out({'rows':get_rows(db,"SELECT l.*,r.title,r.department FROM loans l JOIN records r ON r.id=l.record_id ORDER BY l.id DESC LIMIT 10000")})
            if path=='/api/transfers':
                confirm_role(self,'admin')
                return self.json_out({'rows':get_rows(db,'SELECT * FROM transfers ORDER BY id DESC LIMIT 20000')})
            if path=='/api/audit':
                confirm_role(self,'admin')
                return self.json_out({'rows':get_rows(db,'SELECT * FROM audit ORDER BY id DESC LIMIT 500')})
            if path=='/api/stats':
                where='1=1' if admin else "disclosure='공개'"
                rec=db.execute(f"SELECT COUNT(*) c, COALESCE(SUM(quantity),0) q FROM records WHERE status='보존 중' AND {where}").fetchone()
                art=db.execute(f'SELECT COUNT(*) c, COALESCE(SUM(quantity),0) q FROM artifacts WHERE {where}').fetchone()
                stats=dict(records=rec['c'],record_quantity=rec['q'],artifacts=art['c'],artifact_quantity=art['q'])
                if admin:
                    stats['transfers_pending']=db.execute("SELECT COUNT(*) FROM transfers WHERE state='접수'").fetchone()[0]
                    stats['disposed']=db.execute("SELECT COUNT(*) FROM records WHERE status='폐기 완료'").fetchone()[0]
                return self.json_out(stats)
            if path=='/api/export/records.csv':
                confirm_role(self,'admin')
                rows=get_rows(db,'SELECT * FROM records ORDER BY id')
                return self.csv_response(rows,'records.csv')
            if path=='/api/export/audit.csv':
                confirm_role(self,'admin')
                rows=get_rows(db,'SELECT * FROM audit ORDER BY id')
                return self.csv_response(rows,'audit.csv')
        raise UserError('없는 페이지입니다.',404)
    def csv_response(self,rows,name):
        buff=io.StringIO(); writer=csv.writer(buff)
        if rows:
            writer.writerow(list(rows[0].keys()))
            for row in rows: writer.writerow([v if v is not None else '' for v in row.values()])
        raw=('\ufeff'+buff.getvalue()).encode('utf-8')
        return self.response_bytes(raw,ctype='text/csv; charset=utf-8',extra={'Content-Disposition':f'attachment; filename="{name}"'})
    def route_post(self):
        path=urllib.parse.urlsplit(self.path).path
        if path=='/api/login':
            payload=self.json_in(); u=clean(payload.get('username'),40); password=str(payload.get('password',''))
            ip=self.client_address[0]
            LOGIN_FAILURES[ip]=[t for t in LOGIN_FAILURES.get(ip,[]) if t>time.time()-900]
            if len(LOGIN_FAILURES[ip]) >= 8: raise UserError('로그인 시도가 너무 많습니다. 15분 후 다시 시도하세요.',429)
            with dbconnect(self.cfg) as db: row=db.execute('SELECT * FROM users WHERE username=?',(u,)).fetchone()
            if not row or not check_hash(password,row['password_hash']):
                LOGIN_FAILURES[ip].append(time.time())
                raise UserError('아이디 또는 비밀번호를 확인하세요.',401)
            LOGIN_FAILURES[ip]=[]
            token=secrets.token_urlsafe(32); csrf=secrets.token_urlsafe(28)
            ACTIVE_SESSIONS[token]={'user':u,'role':row['role'],'csrf':csrf,'expires':time.time()+8*3600}
            flags='Path=/; HttpOnly; SameSite=Strict; Max-Age=28800'
            if self.cfg.get('https_cookie',False): flags+='; Secure'
            return self.json_out({'ok':True,'username':u,'role':row['role'],'csrf':csrf},extra={'Set-Cookie':f'guri_session={token}; {flags}'})
        ses=self.check_csrf(); actor=ses['user']
        if path=='/api/logout':
            cookie=SimpleCookie()
            try:cookie.load(self.headers.get('Cookie',''))
            except Exception:pass
            if cookie.get('guri_session'):ACTIVE_SESSIONS.pop(cookie['guri_session'].value,None)
            return self.json_out({'ok':True},extra={'Set-Cookie':'guri_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'})
        if ses['role']!='admin': raise UserError('조회 전용 계정은 변경할 수 없습니다.',403)
        if path=='/api/records':
            record=record_data(self.json_in()); t=now()
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                cols=list(record)+['created_at','updated_at']; vals=list(record.values())+[t,t]
                cursor=db.execute('INSERT INTO records ('+','.join(cols)+') VALUES ('+','.join('?' for _ in cols)+')',vals)
                audit(db,actor,'기록물 등록','record',cursor.lastrowid,record['title']); db.commit()
                return self.json_out({'ok':True,'id':cursor.lastrowid},201)
        if path=='/api/artifacts':
            artifact=artifact_data(self.json_in()); t=now()
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                cols=list(artifact)+['created_at','updated_at']; vals=list(artifact.values())+[t,t]
                cursor=db.execute('INSERT INTO artifacts ('+','.join(cols)+') VALUES ('+','.join('?' for _ in cols)+')',vals)
                audit(db,actor,'행정박물 등록','artifact',cursor.lastrowid,artifact['name']);db.commit()
                return self.json_out({'ok':True,'id':cursor.lastrowid},201)
        if path=='/api/loans':
            data=self.json_in();rid=int_field(data.get('record_id'),'기록물 번호',1,100000000)
            borrower=clean(data.get('borrower'))
            if not borrower:raise UserError('반출자를 입력하세요.')
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                row=db.execute('SELECT * FROM records WHERE id=?',(rid,)).fetchone()
                if not row or row['status']!='보존 중':raise UserError('현재 보존 중인 기록물만 반출할 수 있습니다.')
                existing=db.execute("SELECT 1 FROM loans WHERE record_id=? AND returned_at=''",(rid,)).fetchone()
                if existing:raise UserError('이미 반출 중인 기록물입니다.')
                cur=db.execute('INSERT INTO loans(record_id,borrower,checked_out_at,expected_return,note) VALUES(?,?,?,?,?)',(rid,borrower,today(),clean(data.get('expected_return'),20),clean(data.get('note'),400)))
                audit(db,actor,'기록물 반출','loan',cur.lastrowid,f'기록물 #{rid} / {borrower}');db.commit()
                return self.json_out({'ok':True,'id':cur.lastrowid},201)
        if path.startswith('/api/loans/') and path.endswith('/return'):
            loan_id=int(path.strip('/').split('/')[2]);data=self.json_in()
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                row=db.execute('SELECT * FROM loans WHERE id=?',(loan_id,)).fetchone()
                if not row:raise UserError('반출 내역이 없습니다.',404)
                if row['returned_at']:raise UserError('이미 반납 완료된 기록물입니다.')
                date=clean(data.get('returned_at') or today(),20)
                db.execute('UPDATE loans SET returned_at=? WHERE id=?',(date,loan_id))
                audit(db,actor,'기록물 반납','loan',loan_id,f'기록물 #{row["record_id"]} / {date}');db.commit()
                return self.json_out({'ok':True})
        if path=='/api/transfers/import':
            from openpyxl import load_workbook
            from openpyxl.utils.exceptions import InvalidFileException
            blob=self.input_bytes(MAX_XLSX)
            if blob[:2]!=b'PK': raise UserError('XLSX 파일만 불러올 수 있습니다.')
            try:
                book=load_workbook(io.BytesIO(blob),read_only=True,data_only=True)
                sheet=book['이관목록'] if '이관목록' in book.sheetnames else book.active
                iterator=sheet.iter_rows(values_only=True)
                headings=[clean(v,100) for v in next(iterator)]
                expected=['기록물철명','생산부서','생산연도','단위과제·분류명','보존기간','수량(철)','원등록번호','기록물형태','공개구분','비고']
                if headings[:10]!=expected: raise UserError('확정된 이관목록 서식의 열 제목과 순서가 다릅니다.')
                items=[]
                for n,row in enumerate(iterator,2):
                    if n>2001:break
                    if not any(v is not None and str(v).strip() for v in row[:10]):continue
                    data=dict(zip(expected,row))
                    try:
                        r=record_data({'title':data['기록물철명'],'department':data['생산부서'],
                            'completion_year':data['생산연도'],'classification':data['단위과제·분류명'],
                            'retention':data['보존기간'],'quantity':data['수량(철)'] or 1,
                            'original_no':data['원등록번호'],'item_type':data['기록물형태'] or '일반문서',
                            'disclosure':data['공개구분'] or '비공개','note':data['비고']})
                    except UserError as ex:raise UserError(f'{n}행: {ex}')
                    items.append(r)
                book.close()
            except (InvalidFileException,ValueError,KeyError,StopIteration) as ex:
                if isinstance(ex,UserError):raise
                raise UserError('엑셀 파일을 해석할 수 없습니다.')
            if not items: raise UserError('접수할 기록물이 없습니다.')
            filename=clean(urllib.parse.unquote(self.headers.get('X-Filename') or '이관목록.xlsx'),120)
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                for it in items:
                    db.execute('''INSERT INTO transfers(file_name,title,department,completion_year,retention,item_type,quantity,classification,
                    original_no,disclosure,note,received_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                    (filename,it['title'],it['department'],it['completion_year'],it['retention'],it['item_type'],it['quantity'],
                      it['classification'],it['original_no'],it['disclosure'],it['note'],now()))
                audit(db,actor,'이관목록 엑셀 접수','transfer',None,f'{filename} / {len(items)}건');db.commit()
            return self.json_out({'ok':True,'count':len(items)},201)
        if path.startswith('/api/transfers/') and path.endswith('/confirm'):
            tid=self.path.strip('/').split('/')[2]
            tid=int(tid); data=self.json_in()
            if data.get('physical_checked') is not True: raise UserError('실물대조 확인을 체크해야 합니다.')
            loc=parse_location(data.get('location'))
            if not loc: raise UserError('인수확정 시 보존위치를 입력하세요.')
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                row=db.execute('SELECT * FROM transfers WHERE id=?',(tid,)).fetchone()
                if not row: raise UserError('접수자료를 찾을 수 없습니다.',404)
                if row['state']!='접수': raise UserError('이미 처리된 자료입니다.')
                obj={k:row[k] for k in ('title','department','completion_year','retention','item_type','quantity','classification','original_no','disclosure','note')}
                obj.update(start_year_override=None,box_no=clean(data.get('box_no')),location=loc)
                t=now();cols=list(obj)+['created_at','updated_at'];vals=list(obj.values())+[t,t]
                cursor=db.execute('INSERT INTO records ('+','.join(cols)+') VALUES ('+','.join('?' for _ in cols)+')',vals)
                db.execute("UPDATE transfers SET state='등록 완료',record_id=?,check_note=? WHERE id=?",
                  (cursor.lastrowid,clean(data.get('check_note'),500),tid))
                audit(db,actor,'실물대조 후 이관등록','transfer',tid,f'기록물 #{cursor.lastrowid} / {loc}');db.commit()
            return self.json_out({'ok':True,'id':cursor.lastrowid})
        if path.startswith('/api/records/') and path.endswith('/review'):
            rid=int(path.strip('/').split('/')[2]); data=self.json_in()
            decision=clean(data.get('decision'),30)
            if decision not in DECISIONS: raise UserError('심의결과를 선택하세요.')
            ref=clean(data.get('review_ref'))
            review_date=clean(data.get('review_date'),20)
            if not ref or not review_date: raise UserError('심의문서번호와 심의일자를 입력하세요.')
            if decision=='보존기간 연장':
                new_retention=clean(data.get('new_retention'),12)
                if new_retention not in RETENTION: raise UserError('연장 후 보존기간을 선택하세요.')
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                row=db.execute('SELECT * FROM records WHERE id=?',(rid,)).fetchone()
                if not row:raise UserError('기록물이 없습니다.',404)
                if row['status']=='폐기 완료': raise UserError('폐기 완료 기록물은 다시 평가할 수 없습니다.')
                new_r=clean(data.get('new_retention'),12) if decision=='보존기간 연장' else row['retention']
                db.execute('UPDATE records SET decision=?,review_ref=?,review_date=?,review_note=?,retention=?,updated_at=? WHERE id=?',
                  (decision,ref,review_date,clean(data.get('review_note'),800),new_r,now(),rid))
                audit(db,actor,'심의결과 '+decision,'record',rid,f'{ref} / {review_date}');db.commit()
            return self.json_out({'ok':True})
        if path.startswith('/api/records/') and path.endswith('/dispose'):
            rid=int(path.strip('/').split('/')[2]); data=self.json_in()
            executor=clean(data.get('executor')); day=clean(data.get('execution_date'),20); ref=clean(data.get('execution_ref'))
            if not executor or not day or not ref: raise UserError('폐기집행자, 집행일자, 집행증빙문서번호는 필수입니다.')
            if data.get('physical_destroyed') is not True: raise UserError('실물 폐기 완료를 확인해야 합니다.')
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                row=db.execute('SELECT * FROM records WHERE id=?',(rid,)).fetchone()
                if not row: raise UserError('기록물이 없습니다.',404)
                if row['status']=='폐기 완료': raise UserError('이미 폐기 완료된 기록물입니다.')
                if row['decision']!='폐기 결정': raise UserError('먼저 법정 심의결과를 ‘폐기 결정’으로 등록하세요.')
                if db.execute("SELECT 1 FROM loans WHERE record_id=? AND returned_at=''",(rid,)).fetchone():
                    raise UserError('반출 중인 기록물은 폐기 완료할 수 없습니다. 먼저 반납 처리하세요.')
                db.execute("UPDATE records SET status='폐기 완료',decision='폐기 완료',execution_date=?,executor=?,execution_ref=?,updated_at=? WHERE id=?",
                    (day,executor,ref,now(),rid))
                audit(db,actor,'실물 폐기 완료','record',rid,f'{day} / {executor} / {ref} / 종전 위치 {row["location"]}');db.commit()
            return self.json_out({'ok':True})
        if path.startswith('/api/artifacts/') and path.endswith('/photo'):
            from PIL import Image,ImageOps,UnidentifiedImageError
            aid=int(path.strip('/').split('/')[2]);payload=self.input_bytes(MAX_PHOTO)
            with WRITE_LOCK,dbconnect(self.cfg) as db:
                row=db.execute('SELECT * FROM artifacts WHERE id=?',(aid,)).fetchone()
                if not row:raise UserError('행정박물을 찾을 수 없습니다.',404)
                try:
                    with Image.open(io.BytesIO(payload)) as im:
                        if im.format not in ('JPEG','PNG','WEBP'):raise UserError('JPG, PNG, WEBP만 업로드할 수 있습니다.')
                        if im.width*im.height>30_000_000:raise UserError('이미지 해상도가 너무 큽니다.')
                        corrected=ImageOps.exif_transpose(im).convert('RGB')
                        corrected.thumbnail((2500,2500))
                        buffer=io.BytesIO();corrected.save(buffer,'WEBP',quality=88,method=4)
                except (UnidentifiedImageError,OSError,ValueError):raise UserError('손상되었거나 지원하지 않는 사진입니다.')
                filename=secrets.token_hex(20)+'.webp'
                media=Path(self.cfg['media_dir']);media.mkdir(parents=True,exist_ok=True)
                (media/filename).write_bytes(buffer.getvalue())
                old=row['image_name']
                db.execute('UPDATE artifacts SET image_name=?,updated_at=? WHERE id=?',(filename,now(),aid))
                audit(db,actor,'행정박물 사진 등록','artifact',aid,filename);db.commit()
                if old:
                    try:(media/old).unlink(missing_ok=True)
                    except OSError:logging.warning('Old photo cleanup failed: %s',old)
                return self.json_out({'ok':True})
        raise UserError('없는 API입니다.',404)
    def route_put(self):
        ses=self.check_csrf()
        if ses['role']!='admin':raise UserError('수정 권한이 없습니다.',403)
        path=urllib.parse.urlsplit(self.path).path
        parts=path.strip('/').split('/')
        if len(parts)!=3 or parts[0]!='api' or parts[1] not in ('records','artifacts'):
            raise UserError('수정할 API가 없습니다.',404)
        target=parts[1];rid=int(parts[2]);data=self.json_in()
        if target=='records':
            obj=record_data(data);table='records'
        else:
            obj=artifact_data(data);table='artifacts'
        with WRITE_LOCK,dbconnect(self.cfg) as db:
            row=db.execute(f'SELECT * FROM {table} WHERE id=?',(rid,)).fetchone()
            if not row:raise UserError('수정 대상이 없습니다.',404)
            if target=='records' and row['status']=='폐기 완료':raise UserError('폐기 완료 기록물의 기본정보는 수정할 수 없습니다.')
            sql=', '.join(f'{col}=?' for col in obj)
            db.execute(f'UPDATE {table} SET {sql},updated_at=? WHERE id=?',list(obj.values())+[now(),rid])
            audit(db,ses['user'],'기본정보 수정',target[:-1],rid,clean(obj.get('title') or obj.get('name')));db.commit()
        self.json_out({'ok':True})

def make_server(cfg=None,host=None,port=None):
    cfg=cfg or config()
    initialize_db(cfg)
    server=ThreadingHTTPServer((host or cfg.get('bind','127.0.0.1'), int(port or cfg.get('port',8765))),ArchiveHandler)
    server.cfg=cfg
    return server

def main():
    logging.basicConfig(format='%(asctime)s %(levelname)s: %(message)s',level=logging.INFO)
    try:
        cfg=config()
        db=make_server(cfg)
        print(f'\n구리농수산물공사 서고관리 v1.9: http://{db.server_address[0]}:{db.server_address[1]}')
        print('초기 설정/계정은 setup.py 에서 생성합니다. 종료 Ctrl+C')
        if cfg.get('bind')!='127.0.0.1':print('주의: LAN 바인딩은 반드시 정보보안 승인 및 HTTPS 구성 후 사용하세요.')
        db.serve_forever(poll_interval=.5)
    except KeyboardInterrupt: print('\n종료합니다.')
    except Exception as e:
        print('시작 실패:',e);sys.exit(1)

if __name__=='__main__':main()
