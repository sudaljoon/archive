'use strict';
const $=q=>document.querySelector(q);let csrf='',requests=[],requestStatusFilter='all',requestSearchText='',requestMethodFilter='all';
const e=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(p,o={}){let r=await fetch(p,{credentials:'same-origin',cache:'no-store',...o});let d={};if(r.headers.get('content-type')?.includes('json'))d=await r.json();if(!r.ok)throw Error(d.error||'오류 '+r.status);return d}
const post=(p,body)=>api(p,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)});
async function start(){try{const s=await api('/api/session');if(!s.authenticated||s.role!=='admin'){location.replace('/');return}csrf=s.csrf;$('#account').insertAdjacentHTML('afterbegin',`<span>${e(s.username)}</span>`);await reload()}catch(err){alert(err.message)}}
async function reload(){
 const a=await api('/api/v2/access-requests');
 requests=a.requests||[];
 renderRequestList();
}
function countStatus(status){return requests.filter(r=>r.status===status).length}
function renderRequestList(){
 const counters=[['all',requests.length],['신청',countStatus('신청')],['승인',countStatus('승인')],['대출중',countStatus('대출중')],['반려',countStatus('반려')],['열람완료',countStatus('열람완료')],['반납완료',countStatus('반납완료')]];
 $('#summary').innerHTML=`<div class="request-stat"><small>전체 신청</small><strong>${requests.length}<em>건</em></strong></div><div class="request-stat" data-tone="waiting"><small>접수 대기</small><strong>${countStatus('신청')}<em>건</em></strong></div><div class="request-stat"><small>승인 완료</small><strong>${countStatus('승인')}<em>건</em></strong></div><div class="request-stat" data-tone="loan"><small>실물 대출 중</small><strong>${countStatus('대출중')}<em>건</em></strong></div>`;
 for(const [status,total] of counters){const marker=document.querySelector(`[data-filter-count="${status}"]`);if(marker)marker.textContent=total}
 document.querySelectorAll('[data-request-filter]').forEach(btn=>{const on=btn.dataset.requestFilter===requestStatusFilter;btn.classList.toggle('is-selected',on);btn.setAttribute('aria-pressed',String(on))});
 const q=requestSearchText.trim().toLocaleLowerCase('ko-KR');
 const matches=requests.filter(r=>{
  if(requestStatusFilter!=='all'&&r.status!==requestStatusFilter)return false;
  if(requestMethodFilter!=='all'&&(r.target_kind==='photo'?'photo':r.method)!==requestMethodFilter)return false;
  return !q||[r.record_title,r.record_id,r.applicant,r.reason,r.decision_note,r.id].some(x=>String(x||'').toLocaleLowerCase('ko-KR').includes(q));
 });
 $('#request-result-count').textContent=`조회 결과 ${matches.length}건`;
 $('#request-table').innerHTML=matches.map(r=>{
  let button='';
  if(r.status==='신청')button=`<button class="primary" data-decision="${e(r.id)}">승인 / 반려</button>`;
  if(r.status==='승인'&&r.method==='physical')button=`<button class="primary" data-issue="${e(r.id)}">반출 처리</button>`;
  if(r.status==='대출중')button=`<button class="primary" data-return="${e(r.id)}">반납 확인</button>`;
  if(r.status==='승인'&&r.method==='online')button=`<button class="subtle" data-complete="${e(r.id)}">열람 완료 처리</button>`;
  return `<tr><td>${e((r.requested_at||'').replace('T',' ').slice(0,16))}<small>신청자: ${e(r.applicant)}</small></td><td><strong class="request-record-title">${e(r.record_title)}</strong><small>${e(r.record_id)}</small></td><td><span class="request-method" data-method="${r.method==='online'?'online':'physical'}">${r.target_kind==='photo'?'시청각 사진':r.method==='online'?'온라인 PDF':'실물 열람·대출'}</span></td><td>${e(r.reason)}</td><td><span class="request-status" data-status="${e(r.status)}">${e(r.status)}</span>${r.due_date?`<small>반납예정 ${e(r.due_date)}</small>`:''}${r.grant_expires_at?`<small>원문 허용만료 ${e(new Date(r.grant_expires_at).toLocaleString('ko-KR',{timeZone:'Asia/Seoul'}))}${r.grant_expired?' (기간 만료)':''}</small>`:''}${r.target_kind==='photo'?`<small>허용 사진 ${e(r.selected_photo_count)}장</small>`:''}${r.view_count?`<small>PDF 열람 요청 ${e(r.view_count)}회</small>`:''}${r.decision_note?`<small>의견: ${e(r.decision_note)}</small>`:''}</td><td>${button||'처리 완료'}</td></tr>`
 }).join('')||'<tr><td colspan="6" class="empty">해당 조건의 열람신청 내역이 없습니다.</td></tr>';
}

const get=id=>requests.find(x=>x.id===id);const close=id=>{let d=document.getElementById(id);if(d?.open)d.close()};
async function openDecision(id){const r=get(id);if(!r)return;
$('#decision-id').value=id;$('#decision-subject').textContent=`${r.record_title} · ${r.applicant} · ${r.target_kind==='photo'?'시청각 사진':r.method==='online'?'온라인 열람':'실물 열람·대출'}`;
$('#decision-status').value='승인';$('#decision-note').value='';$('#decision-msg').textContent='';$('#approval-pdf').value='';
$('#decision-pdf-mode').value='original';$('#grant-days').value='7';$('#confirm-original').checked=false;$('#confirm-original').parentElement.hidden=false;
$('#online-decision-options').hidden=r.method!=='online';$('#original-pdf-options').textContent='기존 PDF 목록 확인 중...';
$('#decision-dialog').showModal(); updateOnlineOptions();
if(r.target_kind==='photo'){await loadPhotoOptions(id);return}
if(r.method==='online')try{const data=await api(`/api/v2/access-requests/${id}/pdf-files`);
const box=$('#original-pdf-options');box.replaceChildren();
if(!data.files?.length){box.textContent='첨부된 PDF가 없습니다. 먼저 관리자 기록물 등록 화면에서 PDF를 첨부해 주세요.';return}
for(const f of data.files){
  // 미리보기와 승인대상 선택은 별개입니다. 미리보기만으로 직원 권한이 부여되지 않습니다.
  const row=document.createElement('div');row.className='pdf-option-row';
  const allowLabel=document.createElement('label');allowLabel.className='pdf-allow-label';
  const cb=document.createElement('input');cb.type='checkbox';cb.value=f.file_id;cb.className='allow-pdf';cb.checked=true;
  const allowText=document.createElement('span');allowText.textContent='허용';
  allowLabel.append(cb,allowText);
  const meta=document.createElement('span');meta.className='pdf-file-meta';
  const link=document.createElement('a');link.className='pdf-preview-link';
  link.href=`/api/v2/records/${encodeURIComponent(r.record_id)}/pdfs/${encodeURIComponent(f.file_id)}/content`;
  link.target='_blank';link.rel='noopener noreferrer';
  link.textContent=f.original_name;link.title='PDF 원본 미리보기 (새 탭)';
  link.setAttribute('aria-label',`${f.original_name} PDF 원본 미리보기, 새 탭에서 열기`);
  const size=document.createElement('small');size.textContent=`${(f.byte_size/1024/1024).toFixed(1)}MB · 파일명 클릭하여 미리보기`;
  meta.append(link,size);row.append(allowLabel,meta);box.append(row);
}
$('#confirm-original').parentElement.hidden=data.disclosure==='공개';
}catch(err){$('#original-pdf-options').textContent=err.message}
}
function updateOnlineOptions(){const r=get($('#decision-id').value),approved=$('#decision-status').value==='승인',online=r?.method==='online'&&r?.target_kind!=='photo';const mode=$('#decision-pdf-mode').value;
$('#online-decision-options').hidden=!approved||!online;
$('#photo-decision-options').hidden=!approved||r?.target_kind!=='photo';
$('#original-pdfs-box').hidden=mode!=='original';$('#copy-upload-box').hidden=mode!=='redacted';}

function openIssue(id){const r=get(id);if(!r)return;$('#issue-id').value=id;$('#issue-subject').textContent=r.record_title;$('#issue-msg').textContent='';let date=new Date();date.setDate(date.getDate()+7);$('#due-date').value=date.toLocaleDateString('en-CA');$('#issue-dialog').showModal()}
async function submitDecision(ev){ev.preventDefault();const btn=ev.submitter;if(btn)btn.disabled=true;
try{const id=$('#decision-id').value,d=$('#decision-status').value,r=get(id);let body={decision:d,note:$('#decision-note').value.trim()};
if(d==='승인'&&r.target_kind==='photo'){
 body.file_ids=[...document.querySelectorAll('.allow-photo:checked')].map(x=>x.value);
 body.grant_days=Number($('#photo-grant-days').value);
 if(!body.file_ids.length)throw Error('열람 허용할 사진을 선택해 주세요.');
}
if(d==='승인'&&r.method==='online'&&r.target_kind!=='photo'){
  body.pdf_mode=$('#decision-pdf-mode').value;body.grant_days=Number($('#grant-days').value);
  if(body.pdf_mode==='original'){
    body.file_ids=[...document.querySelectorAll('.allow-pdf:checked')].map(x=>x.value);
    body.confirm_original_release=$('#confirm-original').checked||$('#confirm-original').parentElement.hidden;
    if(!body.file_ids.length)throw Error('열람 허용할 원본 PDF를 선택해 주세요.');
    if(!body.confirm_original_release)throw Error('부분공개·비공개 원본 전체 제공 여부를 확인해 주세요.');
  }else{
    const f=$('#approval-pdf').files[0];
    if(f){if(f.size>25*1024*1024||!f.name.toLowerCase().endsWith('.pdf'))throw Error('25MB 이하 PDF를 첨부해 주세요.');
      const fd=new FormData();fd.append('file',f);
      await api(`/api/v2/access-requests/${id}/approval-copy`,{method:'POST',headers:{'X-CSRF-Token':csrf},body:fd});
    }
  }
}
await post(`/api/v2/access-requests/${id}/decision`,body);close('decision-dialog');await reload();
}catch(err){$('#decision-msg').textContent=err.message}finally{if(btn)btn.disabled=false}}

async function submitIssue(ev){ev.preventDefault();const b=ev.submitter;if(b)b.disabled=true;try{await post(`/api/v2/access-requests/${$('#issue-id').value}/issue`,{due_date:$('#due-date').value});close('issue-dialog');await reload()}catch(err){$('#issue-msg').textContent=err.message}finally{if(b)b.disabled=false}}
async function perform(id,action){let txt=action==='return'?'실물 기록물 반납을 확인했습니까?':'온라인 열람 완료로 처리할까요?';if(!confirm(txt))return;try{await post(`/api/v2/access-requests/${id}/${action}`,{});await reload()}catch(err){alert(err.message)}}
document.addEventListener('click',ev=>{let closebtn=ev.target.closest('[data-close]');if(closebtn){close(closebtn.dataset.close);return}let a=ev.target.closest('[data-decision]');if(a){openDecision(a.dataset.decision).catch(err=>alert(err.message));return}a=ev.target.closest('[data-issue]');if(a){openIssue(a.dataset.issue);return}a=ev.target.closest('[data-return]');if(a){perform(a.dataset.return,'return');return}a=ev.target.closest('[data-complete]');if(a){perform(a.dataset.complete,'complete');return}});
document.querySelectorAll('[data-request-filter]').forEach(b=>b.addEventListener('click',()=>{requestStatusFilter=b.dataset.requestFilter;renderRequestList()}));
$('#request-search').addEventListener('input',ev=>{requestSearchText=ev.target.value;renderRequestList()});
$('#request-method-filter').addEventListener('change',ev=>{requestMethodFilter=ev.target.value;renderRequestList()});
$('#request-filter-reset').addEventListener('click',()=>{requestStatusFilter='all';requestSearchText='';requestMethodFilter='all';$('#request-search').value='';$('#request-method-filter').value='all';renderRequestList()});
$('#reload').onclick=()=>reload().catch(err=>alert(err.message));$('#decision-status').onchange=updateOnlineOptions;$('#decision-pdf-mode').onchange=updateOnlineOptions;$('#decision-form').onsubmit=submitDecision;$('#issue-form').onsubmit=submitIssue;start();

async function loadPhotoOptions(id){
 const box=$('#photo-file-options');box.textContent='사진 목록 확인 중...';$('#photo-grant-days').value='7';
 try{const data=await api(`/api/v2/access-requests/${id}/photo-files`);if($('#decision-id').value!==id)return;box.replaceChildren();
 if(!data.files.length){box.textContent='등록된 사진이 없습니다. 사진 등록 후 승인할 수 있습니다.';return}
 for(const f of data.files){const row=document.createElement('div');row.className='pdf-option-row';
 const label=document.createElement('label'),cb=document.createElement('input');cb.type='checkbox';cb.value=f.id;cb.className='allow-photo';label.append(cb,document.createTextNode(' 허용'));
 const a=document.createElement('a');a.href=`/api/v2/photos/files/${f.id}/view`;a.target='_blank';a.rel='noopener noreferrer';a.textContent=f.original_name+' · 사진 미리보기';
 row.append(label,a);box.append(row);}
 }catch(err){box.textContent=err.message}
}
