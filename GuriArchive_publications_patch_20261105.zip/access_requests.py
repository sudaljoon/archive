"""GuriArchive v2.5 pilot: per-request time-limited original PDF permission.

The original attachment remains private unless the logged-in requesting user has
an approved, currently valid, file-specific grant. Do not deploy real records
without HTTPS, network isolation, administrative permission, and security audit.
"""
import hashlib
import datetime as dt
import json
import re
import secrets
from pathlib import Path
from urllib.parse import quote
import core
import pdf_attachments
import activity_log

REQUEST_RE=re.compile(r'^/api/v2/access-requests(?:/([a-f0-9]{24})(?:/(decision|issue|return|complete|approval-copy|approval-copy/content|pdf-files|photo-files|original-pdfs(?:/[a-f0-9]{32}/content)?))?)?$')
METHODS={'online','physical'}
STATUS={'신청','승인','반려','대출중','반납완료','열람완료'}


def ensure_tables(cfg):
    with core.dbconnect(cfg) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS access_requests (
            id TEXT PRIMARY KEY, record_id TEXT NOT NULL, applicant TEXT NOT NULL,
            method TEXT NOT NULL CHECK(method IN ('online','physical')),
            reason TEXT NOT NULL, requested_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT '신청',
            decision_note TEXT NOT NULL DEFAULT '', decided_at TEXT NOT NULL DEFAULT '',
            decided_by TEXT NOT NULL DEFAULT '',
            approved_disk_name TEXT NOT NULL DEFAULT '', approved_original_name TEXT NOT NULL DEFAULT '',
            issued_at TEXT NOT NULL DEFAULT '', due_date TEXT NOT NULL DEFAULT '',
            returned_at TEXT NOT NULL DEFAULT '', loan_id TEXT NOT NULL DEFAULT ''
        )''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_access_applicant ON access_requests(applicant,requested_at)')
        db.execute('CREATE INDEX IF NOT EXISTS idx_access_record ON access_requests(record_id)')
        columns={r['name'] for r in db.execute('PRAGMA table_info(access_requests)')}
        # Additive migration: preserve v2.4 requests and uploaded approval copies.
        for column,definition in (
            ('target_kind',"TEXT NOT NULL DEFAULT 'record'"),
            ('photo_file_ids',"TEXT NOT NULL DEFAULT '[]'"),
            ('grant_mode',"TEXT NOT NULL DEFAULT ''"),
            ('original_pdf_ids',"TEXT NOT NULL DEFAULT '[]'"),
            ('grant_expires_at',"TEXT NOT NULL DEFAULT ''"),
        ):
            if column not in columns:
                db.execute(f'ALTER TABLE access_requests ADD COLUMN {column} {definition}')
        db.execute("CREATE INDEX IF NOT EXISTS idx_access_photo_grants ON access_requests(target_kind,applicant,record_id,status)")
        db.execute('''CREATE TABLE IF NOT EXISTS access_pdf_views (
            id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,
            record_id TEXT NOT NULL, file_id TEXT NOT NULL, viewer_id TEXT NOT NULL,
            viewed_at TEXT NOT NULL
        )''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_access_pdf_views_request ON access_pdf_views(request_id)')


def state(cfg):
    with core.dbconnect(cfg) as db:
        row=db.execute('SELECT json_data FROM archive_state WHERE id=1').fetchone()
    return json.loads(row['json_data']) if row else {'records':[], 'artifacts':[]}


def get_record(cfg,record_id):
    return next((r for r in state(cfg)['records'] if r.get('id')==record_id),None)


def disposed(r):
    ev=r.get('evaluation') or {}
    return ev.get('decision')=='폐기 결정' and bool(ev.get('executedAt'))


def catalog(handler):
    session=core.confirm_role(handler,'viewer')
    data=state(handler.cfg)
    # In this controlled pilot only, the minimal index is exposed to authenticated
    # viewers, including non-public titles. Review metadata sensitivity before use.
    records=[]
    # Expose only attachment presence, not filenames or file contents.
    # The PDF endpoints retain their existing disclosure and approval checks.
    with core.dbconnect(handler.cfg) as db:
        pdf_record_ids={row['record_id'] for row in db.execute('SELECT DISTINCT record_id FROM record_pdf_files')}
    loaned={l.get('recordId') for l in data.get('loans',[]) if not l.get('returnDate')}
    fields=('id','title','dept','series','year','base','retention','format','count','location','box','disclosure','condition','verifyStatus')
    for r in data['records']:
        if disposed(r):continue
        entry={k:r.get(k,'') for k in fields}
        entry['physical_loaned']=r.get('id') in loaned
        entry['has_pdf']=r.get('id') in pdf_record_ids
        records.append(entry)
    arts=[]
    for a in data['artifacts']:
        if a.get('disclosure')=='공개':
            arts.append({k:a.get(k,'') for k in ('id','title','dept','type','material','productionDate','quantity','location','disclosure','photo')})
    return handler.json_out({'records':records,'artifacts':arts})


def detail(handler,record_id):
    ses=core.confirm_role(handler,'viewer')
    record=get_record(handler.cfg,record_id)
    if not record or disposed(record):raise core.UserError('조회할 수 없는 기록물입니다.',404)
    fields=('id','title','original','series','dept','year','base','retention','format','count','location','box','disclosure','condition','verifyStatus','verifyDate','created')
    result={k:record.get(k,'') for k in fields}
    result['physical_loaned']=any(l.get('recordId')==record_id and not l.get('returnDate') for l in state(handler.cfg).get('loans',[]))
    result['pdf_available']=record.get('disclosure')=='공개'
    # Notes, protected evaluation data, inspection and audit details are never exposed.
    activity_log.write(handler,'기록물 이용','상세정보 조회',ses=ses,kind='record',target=record_id,title=record.get('title',''))
    return handler.json_out({'record':result})


def _load(db, rid):
    row=db.execute('SELECT * FROM access_requests WHERE id=?',(rid,)).fetchone()
    if not row:raise core.UserError('열람신청을 찾지 못했습니다.',404)
    return dict(row)


def _scope(handler,req):
    ses=core.confirm_role(handler,'viewer')
    if ses['role']!='admin' and req['applicant']!=ses['user']:
        raise core.UserError('본인의 신청내역만 열람할 수 있습니다.',403)
    return ses


def _utcnow():
    return dt.datetime.now(dt.timezone.utc)


def _not_expired(req):
    exp=(req.get('grant_expires_at') or '').strip()
    if not exp:  # legacy v2.4 approval-copy requests only
        return True
    try:
        value=dt.datetime.fromisoformat(exp.replace('Z','+00:00'))
        return value.tzinfo is not None and _utcnow()<value
    except (ValueError,TypeError):
        return False


def _granted_ids(req):
    try:
        ids=json.loads(req.get('original_pdf_ids') or '[]')
        if not isinstance(ids,list):return []
        return [i for i in ids if isinstance(i,str) and re.fullmatch(r'[a-f0-9]{32}',i)]
    except (ValueError,TypeError):
        return []


def listing(handler):
    ses=core.confirm_role(handler,'viewer')
    with core.dbconnect(handler.cfg) as db:
        if ses['role']=='admin':
            rows=db.execute('SELECT * FROM access_requests ORDER BY requested_at DESC, id DESC LIMIT 3000').fetchall()
        else:
            rows=db.execute('SELECT * FROM access_requests WHERE applicant=? ORDER BY requested_at DESC, id DESC LIMIT 1000',(ses['user'],)).fetchall()
        views={r['request_id']:r['n'] for r in db.execute('SELECT request_id,COUNT(*) n FROM access_pdf_views GROUP BY request_id')}
    titles={r.get('id'):r.get('title','') for r in state(handler.cfg)['records']}
    import photo_access
    with core.dbconnect(handler.cfg) as db:
        photo_titles={r['id']:r['title'] for r in db.execute('SELECT id,title FROM photo_items')}
    items=[]
    for row in rows:
        r=dict(row);a=dict(r)
        a.pop('approved_disk_name',None)
        a.pop('original_pdf_ids',None)
        a.pop('photo_file_ids',None)
        valid=r['status']=='승인' and _not_expired(r)
        a['grant_expired']=bool(r['grant_expires_at']) and not _not_expired(r)
        a['approved_copy_available']=bool(r['approved_disk_name']) and valid and r['grant_mode']!='original'
        a['original_pdf_available']=r['grant_mode']=='original' and valid and bool(_granted_ids(r))
        a['selected_pdf_count']=len(_granted_ids(r)) if ses['role']=='admin' or a['original_pdf_available'] else 0
        a['view_count']=views.get(r['id'],0) if ses['role']=='admin' else None
        is_photo=r['target_kind']=='photo'
        a['photo_available']=is_photo and r['grant_mode']=='photo' and valid and bool(r['grant_expires_at']) and bool(photo_access.selected_ids(r))
        a['selected_photo_count']=len(photo_access.selected_ids(r)) if is_photo else 0
        a['record_title']=(photo_titles if is_photo else titles).get(r['record_id'],'(목록정보 없음)')
        items.append(a)
    return handler.json_out({'requests':items})

def create(handler):
    ses=handler.check_csrf()
    if ses['role']!='viewer':raise core.UserError('직원 열람 계정으로 신청해 주세요.',403)
    data=handler.json_in()
    kind=data.get('target_kind','record')
    if kind=='photo':
        import photo_access
        return photo_access.create(handler,ses,data)
    if kind!='record':raise core.UserError('신청대상을 확인해 주세요.')
    rid=str(data.get('record_id','')).strip()
    method=data.get('method')
    reason=str(data.get('reason','')).strip()
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,90}',rid):raise core.UserError('기록물 관리번호 오류')
    if method not in METHODS:raise core.UserError('열람 방식 선택 오류')
    if len(reason)<5 or len(reason)>1000:raise core.UserError('신청사유는 5~1000자로 입력해 주세요.')
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        r=get_record(handler.cfg,rid)
        if not r or disposed(r):raise core.UserError('열람신청이 불가능한 기록물입니다.',404)
        # Online PDF permission and physical loans are independent workflows.
        # A physical loan (including an active one) must never prevent a new
        # online-PDF request for the same record; and vice versa.
        existing=db.execute("""SELECT status,grant_expires_at FROM access_requests
                              WHERE target_kind='record' AND applicant=? AND record_id=? AND method=?
                              AND status IN ('신청','승인','대출중')""",
                            (ses['user'],rid,method)).fetchall()
        if any(x['status']!='승인' or method=='physical' or _not_expired(dict(x)) for x in existing):
            raise core.UserError('동일 기록물에 동일한 열람 방식으로 처리 중인 신청이 있습니다.',409)
        req_id=secrets.token_hex(12)
        db.execute('INSERT INTO access_requests(id,record_id,applicant,method,reason,requested_at,status) VALUES(?,?,?,?,?,?,?)',
                   (req_id,rid,ses['user'],method,reason,core.now(),'신청'))
        core.audit(db,ses['user'],'열람·대출 신청','access_requests',req_id,method+' / '+rid)
        activity_log.write(handler,'기록물 이용','열람신청',ses=ses,kind='record',target=rid,title=r.get('title',''),detail=('온라인 PDF' if method=='online' else '실물 열람·대출')+' / 신청번호 '+req_id,db=db)
    return handler.json_out({'ok':True,'id':req_id,'status':'신청'},201)


def pdf_file_options(handler,rid):
    core.confirm_role(handler,'admin')
    with core.dbconnect(handler.cfg) as db:
        req=_load(db,rid)
        if req['target_kind']!='record' or req['method']!='online':raise core.UserError('온라인 열람신청에서만 PDF를 선택할 수 있습니다.',409)
        rows=db.execute('''SELECT file_id,original_name,byte_size FROM record_pdf_files
                           WHERE record_id=? ORDER BY created_at,file_id''',(req['record_id'],)).fetchall()
    return handler.json_out({'record_id':req['record_id'],
                             'files':[dict(row) for row in rows],
                             'disclosure':(get_record(handler.cfg,req['record_id']) or {}).get('disclosure','')})


def decision(handler,rid):
    ses=handler.check_csrf()
    if ses['role']!='admin':raise core.UserError('관리자만 승인·반려할 수 있습니다.',403)
    p=handler.json_in();d=p.get('decision')
    if d not in ('승인','반려'):raise core.UserError('승인 또는 반려를 선택하세요.')
    note=str(p.get('note','')).strip()
    if len(note)>800:raise core.UserError('처리 의견은 800자 이내로 작성하세요.')
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        req=_load(db,rid)
        if req['status']!='신청':raise core.UserError('접수 상태에서만 처리할 수 있습니다.',409)
        if req['target_kind']=='photo':
            import photo_access
            result=photo_access.decision(handler,db,ses,req,p,d,note)
        else:
            result=None
        if result is not None:
            # Commit before sending a successful decision response.
            db.commit()
            return handler.json_out(result)
        record=get_record(handler.cfg,req['record_id'])
        if not record or disposed(record):raise core.UserError('이미 폐기됐거나 존재하지 않는 기록물입니다.',409)
        grant_mode='';selected=[];expires=''
        if d=='반려' and len(note)<3:raise core.UserError('반려 사유를 3자 이상 입력하세요.')
        if d=='승인' and req['method']=='online':
            grant_mode=p.get('pdf_mode','original')
            if grant_mode not in ('original','redacted'):
                raise core.UserError('원본 또는 별도 가림 처리본을 선택하세요.')
            days=p.get('grant_days',7)
            if type(days) is not int or days not in (1,7,30):
                raise core.UserError('열람기간은 1일, 7일, 30일 중 선택하세요.')
            expires=(_utcnow()+dt.timedelta(days=days)).isoformat()
            if grant_mode=='original':
                raw=p.get('file_ids')
                if not isinstance(raw,list) or not 1<=len(raw)<=20 or len(set(raw))!=len(raw) or any(not isinstance(x,str) or not re.fullmatch(r'[a-f0-9]{32}',x) for x in raw):
                    raise core.UserError('열람을 허용할 기존 PDF를 하나 이상 선택하세요.')
                rows=db.execute('SELECT file_id,disk_name FROM record_pdf_files WHERE record_id=?',(req['record_id'],)).fetchall()
                allowed={r['file_id']:r['disk_name'] for r in rows}
                if not set(raw).issubset(allowed):raise core.UserError('이 기록물철의 PDF만 승인할 수 있습니다.',403)
                folder=Path(handler.cfg['media_dir'])/'record_pdfs'
                for fid in raw:
                    disk=allowed[fid]
                    if not re.fullmatch(r'[a-f0-9]{32}\.pdf',disk) or not (folder/disk).is_file():
                        raise core.UserError('첨부된 원본 PDF 파일을 찾을 수 없습니다.',404)
                if record.get('disclosure')!='공개' and p.get('confirm_original_release') is not True:
                    raise core.UserError('부분공개·비공개 기록물 원본 전체 제공 여부를 확인해 주세요.',409)
                selected=raw
            elif not req['approved_disk_name']:
                raise core.UserError('가림 처리본 방식은 별도 승인용 PDF 첨부가 필요합니다.',409)
        db.execute('''UPDATE access_requests SET status=?,decision_note=?,decided_at=?,decided_by=?,
                      grant_mode=?,original_pdf_ids=?,grant_expires_at=? WHERE id=?''',
                   (d,note,core.now(),ses['user'],grant_mode,json.dumps(selected),expires,rid))
        core.audit(db,ses['user'],'열람신청 '+d,'access_requests',rid,
                   f"{req['record_id']} / {grant_mode} / {len(selected)}파일 / 만료:{expires}")
        activity_log.write(handler,'기록물 이용','열람 승인' if d=='승인' else '열람 반려',ses=ses,
                           kind='record',target=req['record_id'],title=record.get('title',''),
                           detail='신청번호 '+rid+' / '+('온라인' if req['method']=='online' else '실물'),db=db)
    return handler.json_out({'ok':True,'status':d,'grant_mode':grant_mode,'grant_expires_at':expires})

def approval_copy_upload(handler,rid):
    ses=handler.check_csrf()
    if ses['role']!='admin':raise core.UserError('관리자 전용입니다.',403)
    # API reused from upload, including PDF magic and byte limits.
    name,payload=pdf_attachments._parse_multipart(handler)
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        req=_load(db,rid)
        if req['target_kind']!='record' or req['method']!='online' or req['status']!='신청':raise core.UserError('접수된 온라인 열람신청에만 승인용 PDF를 첨부할 수 있습니다.',409)
        r=get_record(handler.cfg,req['record_id'])
        if not r or disposed(r):raise core.UserError('해당 기록물은 열람할 수 없습니다.',409)
        folder=Path(handler.cfg['media_dir'])/'approved_copies';folder.mkdir(parents=True,exist_ok=True)
        file_name=secrets.token_hex(18)+'.pdf'
        path=folder/file_name
        with path.open('xb') as f:f.write(payload)
        old=req['approved_disk_name']
        try:
            db.execute('UPDATE access_requests SET approved_disk_name=?,approved_original_name=? WHERE id=?',
                       (file_name,name,rid))
            core.audit(db,ses['user'],'승인용 PDF 첨부','access_requests',rid,f'{req["record_id"]} / {len(payload)} bytes')
            activity_log.write(handler,'관리자 작업','승인용 PDF 업로드',ses=ses,kind='record',target=req['record_id'],
                               detail='신청번호 '+rid,db=db)
        except Exception:
            path.unlink(missing_ok=True);raise
    # Avoid removing older copy before DB commit. Orphans may be cleaned manually.
    return handler.json_out({'ok':True,'original_name':name,'size':len(payload)})


def _respond_pdf(handler,path,original):
    size=path.stat().st_size
    start=0;end=size-1;status=200
    rng=handler.headers.get('Range','').strip()
    if rng:
        m=re.fullmatch(r'bytes=(\d*)-(\d*)',rng)
        if not m or not (m.group(1) or m.group(2)):raise core.UserError('지원하지 않는 범위 요청입니다.',416)
        if m.group(1):
            start=int(m.group(1));end=min(size-1,int(m.group(2))) if m.group(2) else size-1
        else:start=max(0,size-int(m.group(2)))
        if start>=size or end<start:raise core.UserError('PDF 범위가 잘못되었습니다.',416)
        status=206
    handler.send_response(status)
    headers={'Content-Type':'application/pdf','Content-Length':str(end-start+1),'Cache-Control':'private, no-store',
             'X-Content-Type-Options':'nosniff','X-Frame-Options':'SAMEORIGIN','Content-Security-Policy':"frame-ancestors 'self'",'Accept-Ranges':'bytes',
             'Content-Disposition':"inline; filename*=UTF-8''"+quote(original)}
    if status==206:headers['Content-Range']=f'bytes {start}-{end}/{size}'
    for k,v in headers.items():handler.send_header(k,v)
    handler.end_headers()
    with path.open('rb') as f:
        f.seek(start);remaining=end-start+1
        while remaining:
            block=f.read(min(128*1024,remaining))
            if not block:break
            handler.wfile.write(block);remaining-=len(block)


def approved_content(handler,rid):
    ses=core.confirm_role(handler,'viewer')
    with core.dbconnect(handler.cfg) as db:req=_load(db,rid)
    if ses['role']!='admin' and req['applicant']!=ses['user']:raise core.UserError('신청자 본인만 조회할 수 있습니다.',403)
    if req['status']!='승인' or req['method']!='online' or not _not_expired(req) or req['grant_mode']=='original':raise core.UserError('승인된 가림 처리본 열람 기간이 아닙니다.',403)
    record=get_record(handler.cfg,req['record_id'])
    if not record or disposed(record):raise core.UserError('기록물 열람이 불가능합니다.',403)
    name=req['approved_disk_name']
    if not re.fullmatch(r'[a-f0-9]{36}\.pdf',name):raise core.UserError('승인용 PDF를 찾지 못했습니다.',404)
    target=Path(handler.cfg['media_dir'])/'approved_copies'/name
    if not target.is_file():raise core.UserError('승인용 PDF 파일이 없습니다.',404)
    if not handler.headers.get('Range','') or handler.headers.get('Range','').startswith('bytes=0-'):
        activity_log.write(handler,'기록물 이용','승인 PDF 열람',ses=ses,kind='record',
                           target=req['record_id'],title=record.get('title',''),detail='신청번호 '+rid+' / 가림 처리본')
    return _respond_pdf(handler,target,req['approved_original_name'] or 'approved.pdf')


def original_pdf_listing(handler,rid):
    ses=core.confirm_role(handler,'viewer')
    with core.dbconnect(handler.cfg) as db:
        req=_load(db,rid)
        if ses['role']!='admin' and req['applicant']!=ses['user']:
            raise core.UserError('신청자 본인만 조회할 수 있습니다.',403)
        if req['status']!='승인' or req['method']!='online' or req['grant_mode']!='original' or not _not_expired(req):
            raise core.UserError('원본 PDF 열람권한이 없거나 기간이 만료되었습니다.',403)
        rec=get_record(handler.cfg,req['record_id'])
        if not rec or disposed(rec):raise core.UserError('폐기된 기록물입니다.',403)
        ids=_granted_ids(req)
        if not ids:raise core.UserError('승인된 PDF가 없습니다.',404)
        rows=db.execute('SELECT file_id,original_name,byte_size FROM record_pdf_files WHERE record_id=?',(req['record_id'],)).fetchall()
    by_id={r['file_id']:dict(r) for r in rows}
    return handler.json_out({'files':[by_id[fid] for fid in ids if fid in by_id],
                             'expires_at':req['grant_expires_at']})


def original_pdf_content(handler,rid,file_id):
    ses=core.confirm_role(handler,'viewer')
    with core.dbconnect(handler.cfg) as db:
        req=_load(db,rid)
        if ses['role']!='admin' and req['applicant']!=ses['user']:
            raise core.UserError('신청자 본인만 열람할 수 있습니다.',403)
        if req['method']!='online' or req['status']!='승인' or req['grant_mode']!='original' or not _not_expired(req):
            raise core.UserError('원본 PDF 승인기간이 아니거나 열람이 종료됐습니다.',403)
        if file_id not in _granted_ids(req):raise core.UserError('승인되지 않은 첨부 PDF입니다.',403)
        rec=get_record(handler.cfg,req['record_id'])
        if not rec or disposed(rec):raise core.UserError('폐기된 기록물은 열람할 수 없습니다.',403)
        row=db.execute('SELECT disk_name,original_name FROM record_pdf_files WHERE file_id=? AND record_id=?',(file_id,req['record_id'])).fetchone()
        if not row:raise core.UserError('승인된 PDF를 찾을 수 없습니다.',404)
        disk=row['disk_name']
        if not re.fullmatch(r'[a-f0-9]{32}\.pdf',disk):raise core.UserError('저장경로 오류',500)
        file_path=Path(handler.cfg['media_dir'])/'record_pdfs'/disk
        if not file_path.is_file():raise core.UserError('PDF 원본 파일이 없습니다.',404)
        # Record initial PDF request, not every byte-range part.
        rng=handler.headers.get('Range','')
        if not rng or rng.startswith('bytes=0-'):
            with core.WRITE_LOCK,core.dbconnect(handler.cfg) as logs:
                logs.execute('''INSERT INTO access_pdf_views(request_id,record_id,file_id,viewer_id,viewed_at)
                                VALUES(?,?,?,?,?)''',(rid,req['record_id'],file_id,ses['user'],core.now()))
                core.audit(logs,ses['user'],'승인 원본 PDF 열람','access_requests',rid,f"{req['record_id']} / {file_id}")
                activity_log.write(handler,'기록물 이용','승인 PDF 열람',ses=ses,kind='record',
                                   target=req['record_id'],title=rec.get('title',''),detail='신청번호 '+rid+' / 파일 '+file_id,db=logs)
    return _respond_pdf(handler,file_path,row['original_name'])

def issue(handler,rid):
    ses=handler.check_csrf()
    if ses['role']!='admin':raise core.UserError('관리자 전용입니다.',403)
    p=handler.json_in();due=str(p.get('due_date',''))
    try:
        import datetime as dt
        dt.date.fromisoformat(due)
        if due<dt.date.today().isoformat():raise ValueError()
    except ValueError:raise core.UserError('반납 예정일은 오늘 이후 날짜로 입력하세요.')
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        req=_load(db,rid)
        if req['method']!='physical' or req['status']!='승인':raise core.UserError('승인된 실물 신청만 반출할 수 있습니다.',409)
        row=db.execute('SELECT json_data,revision FROM archive_state WHERE id=1').fetchone()
        doc=json.loads(row['json_data'])
        record=next((r for r in doc['records'] if r['id']==req['record_id']),None)
        if not record or disposed(record):raise core.UserError('폐기된 기록물은 반출할 수 없습니다.',409)
        if any(l['recordId']==req['record_id'] and not l.get('returnDate') for l in doc['loans']):
            raise core.UserError('이미 반출 중인 기록물입니다.',409)
        import datetime as dt
        lid='REQ-'+rid
        day=dt.date.today().isoformat()
        doc['loans'].append({'id':lid,'recordId':req['record_id'],'borrower':req['applicant'],
                            'purpose':req['reason'],'outDate':day,'dueDate':due,'returnDate':'','checker':ses['user'],'notes':'직원 열람신청 '+rid})
        db.execute('UPDATE archive_state SET json_data=?,revision=?,updated_at=?,updated_by=? WHERE id=1',
                   (json.dumps(doc,ensure_ascii=False,separators=(',',':')),row['revision']+1,core.now(),ses['user']))
        db.execute("UPDATE access_requests SET status='대출중',issued_at=?,due_date=?,loan_id=? WHERE id=?",
                   (core.now(),due,lid,rid))
        core.audit(db,ses['user'],'실물 기록물 반출','access_requests',rid,req['record_id'])
        activity_log.write(handler,'기록물 이용','실물 반출',ses=ses,kind='record',target=req['record_id'],detail='신청번호 '+rid,db=db)
    return handler.json_out({'ok':True,'status':'대출중'})


def return_item(handler,rid):
    ses=handler.check_csrf()
    if ses['role']!='admin':raise core.UserError('관리자 전용입니다.',403)
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        req=_load(db,rid)
        if req['method']!='physical' or req['status']!='대출중':raise core.UserError('대출 중인 건만 반납할 수 있습니다.',409)
        row=db.execute('SELECT json_data,revision FROM archive_state WHERE id=1').fetchone()
        doc=json.loads(row['json_data'])
        loan=next((l for l in doc['loans'] if l['id']==req['loan_id'] and not l.get('returnDate')),None)
        if not loan:raise core.UserError('반출입 대장과 일치하는 미반납 건이 없습니다.',409)
        import datetime as dt
        loan['returnDate']=dt.date.today().isoformat();loan['checker']=ses['user']
        db.execute('UPDATE archive_state SET json_data=?,revision=?,updated_at=?,updated_by=? WHERE id=1',
                   (json.dumps(doc,ensure_ascii=False,separators=(',',':')),row['revision']+1,core.now(),ses['user']))
        db.execute("UPDATE access_requests SET status='반납완료',returned_at=? WHERE id=?",(core.now(),rid))
        core.audit(db,ses['user'],'실물 기록물 반납','access_requests',rid,req['record_id'])
        activity_log.write(handler,'기록물 이용','실물 반납',ses=ses,kind='record',target=req['record_id'],detail='신청번호 '+rid,db=db)
    return handler.json_out({'ok':True,'status':'반납완료'})


def online_complete(handler,rid):
    ses=handler.check_csrf()
    if ses['role']!='admin':raise core.UserError('관리자 전용입니다.',403)
    with core.WRITE_LOCK,core.dbconnect(handler.cfg) as db:
        req=_load(db,rid)
        if req['method']!='online' or req['status']!='승인':raise core.UserError('승인된 온라인 열람만 완료 처리할 수 있습니다.',409)
        db.execute("UPDATE access_requests SET status='열람완료' WHERE id=?",(rid,))
        core.audit(db,ses['user'],'온라인 열람 완료','access_requests',rid,req['record_id'])
        activity_log.write(handler,'기록물 이용','온라인 열람 완료',ses=ses,kind='photo_item' if req['target_kind']=='photo' else 'record',target=req['record_id'],detail='신청번호 '+rid,db=db)
    return handler.json_out({'ok':True,'status':'열람완료'})


def sync_legacy_returns(db, doc, actor):
    """Keep employee application statuses in sync if manager returns an item
    from the original v1.8 반출입 menu instead of the new request page."""
    returned={x.get('id') for x in doc.get('loans',[]) if x.get('returnDate')}
    if not returned:return
    rows=db.execute("SELECT id,record_id,loan_id FROM access_requests WHERE status='대출중' AND loan_id!=''").fetchall()
    for r in rows:
        if r['loan_id'] in returned:
            db.execute("UPDATE access_requests SET status='반납완료', returned_at=? WHERE id=?",(core.now(),r['id']))
            core.audit(db,actor,'기존 반출입 대장 연계 반납','access_requests',r['id'],r['record_id'])
