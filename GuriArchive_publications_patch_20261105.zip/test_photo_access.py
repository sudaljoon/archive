"""Permission and additive-migration regression tests. All writes use TemporaryDirectory."""
import datetime as dt
import io
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image
import core
import server
import company_viewer
import access_requests as requests
import photo_access
import photo_records as photos
from test_photo_records import FakeHandler


class PhotoAccessTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='guri-access-test-')
        self.addCleanup(self.temp.cleanup)
        root=Path(self.temp.name)
        self.cfg={'db_path':str(root/'test.sqlite3'),'media_dir':str(root/'media')}
        server.initialize_db(self.cfg)
        self.admin=FakeHandler(self.cfg)
        self.viewer=FakeHandler(self.cfg,'viewer');self.viewer.session['user']='employee1'
        self.other=FakeHandler(self.cfg,'viewer');self.other.session['user']='employee2'
        self.admin.payload={'title':'비공개 사진철','department':'총무팀','disclosure':'비공개'}
        self.sid=photos.save(self.admin,'series')['id']
        self.iid=self.item(self.sid)
        self.files=[self.upload(self.iid,c) for c in (10,20)]

    def item(self,sid,disclosure='공개'):
        self.admin.payload={'title':'행사 사진','series_id':sid,'disclosure':disclosure,'summary':'민감한 설명','notes':'내부 메모'}
        return photos.save(self.admin,'items')['id']

    def upload(self,iid,color):
        out=io.BytesIO();Image.new('RGB',(64,48),(color,50,70)).save(out,'PNG')
        self.admin.raw=out.getvalue();self.admin.headers={'X-Original-Filename':'photo.png'}
        return photos.upload(self.admin,iid)['id']

    def apply(self,viewer=None,iid=None):
        h=viewer or self.viewer
        h.payload={'target_kind':'photo','record_id':iid or self.iid,'method':'online','reason':'업무 보고자료 검토'}
        return requests.create(h)['id']

    def decide(self,rid,days=7,files=None,decision='승인',note=''):
        self.admin.payload={'decision':decision,'note':note,'grant_days':days,'file_ids':self.files[:1] if files is None else files}
        return requests.decision(self.admin,rid)

    def denied(self,handler,fid,**kwargs):
        with self.assertRaises(core.UserError) as caught:photos.image(handler,fid,**kwargs)
        self.assertEqual(caught.exception.code,403)

    def test_search_and_detail_expose_metadata_without_private_files(self):
        listing=photos.listing(self.viewer)['items'][0]
        self.assertEqual(listing['id'],self.iid)
        self.assertEqual(listing['effective_disclosure'],'비공개')
        self.assertIsNone(listing['cover_file'])
        self.assertEqual(listing['summary'],'')
        detail=photos.detail(self.viewer,self.iid)
        self.assertEqual(detail['files'],[])
        self.assertEqual(detail['file_count'],2)
        self.assertNotIn('notes',detail['item'])
        for fid in self.files:
            self.denied(self.viewer,fid,preview=True);self.denied(self.viewer,fid,view=True)

    def test_selected_files_applicant_and_original_are_enforced(self):
        rid=self.apply();self.decide(rid)
        self.assertEqual([f['id'] for f in photos.detail(self.viewer,self.iid)['files']],self.files[:1])
        self.assertTrue(photos.detail(self.viewer,self.iid)['files'][0]['grant_expires_at'])
        self.assertEqual(photos.image(self.viewer,self.files[0],view=True)['type'],'image/jpeg')
        self.assertEqual(photos.image(self.viewer,self.files[0],preview=True)['type'],'image/jpeg')
        self.denied(self.viewer,self.files[1],view=True)
        self.denied(self.other,self.files[0],view=True)
        self.denied(self.viewer,self.files[0])
        self.assertEqual(photos.image(self.admin,self.files[0])['type'],'image/png')
        self.assertEqual(requests.listing(self.other)['requests'],[])
        listing=requests.listing(self.viewer)['requests'][0]
        self.assertEqual(listing['target_kind'],'photo');self.assertTrue(listing['photo_available'])
        self.assertNotIn('photo_file_ids',listing)
        self.assertNotIn('approved_disk_name',listing)
        with core.dbconnect(self.cfg) as db:
            events=[dict(r) for r in db.execute('SELECT * FROM activity_events')]
        image_events=[r for r in events if r['event']=='시청각 이미지 열람']
        self.assertEqual(len(image_events),1)
        self.assertIn(rid,image_events[0]['detail'])
        self.assertTrue(any(r['event']=='열람신청' and r['target_type']=='photo_item' for r in events))
        self.assertTrue(any(r['event']=='열람 승인' and r['target_type']=='photo_item' for r in events))

    def test_each_duration_exact_boundary_expiry_and_reapplication(self):
        now=dt.datetime(2026,11,4,4,0,tzinfo=dt.timezone.utc)
        for n,days in enumerate((1,7,30)):
            viewer=FakeHandler(self.cfg,'viewer');viewer.session['user']='duration'+str(n)
            rid=self.apply(viewer)
            with patch.object(requests,'_utcnow',return_value=now):
                decision=self.decide(rid,days)
                self.assertEqual(dt.datetime.fromisoformat(decision['grant_expires_at']),now+dt.timedelta(days=days))
                with self.assertRaises(core.UserError):self.apply(viewer)
                self.assertEqual(photos.image(viewer,self.files[0],view=True)['type'],'image/jpeg')
            with patch.object(requests,'_utcnow',return_value=now+dt.timedelta(days=days)):
                self.denied(viewer,self.files[0],view=True)
                self.denied(viewer,self.files[0],preview=True)
                self.assertEqual(photos.detail(viewer,self.iid)['files'],[])
                self.assertTrue(requests.listing(viewer)['requests'][0]['grant_expired'])
                self.assertTrue(self.apply(viewer))

    def test_rejection_requires_reason_and_allows_reapplication(self):
        rid=self.apply()
        with self.assertRaises(core.UserError):self.decide(rid,decision='반려')
        self.decide(rid,decision='반려',note='개인정보 포함으로 반려')
        self.denied(self.viewer,self.files[0],view=True)
        self.assertEqual(requests.listing(self.viewer)['requests'][0]['decision_note'],'개인정보 포함으로 반려')
        self.assertTrue(self.apply())
        with self.assertRaises(core.UserError):self.decide(rid)

    def test_invalid_selection_days_and_roles_leave_request_pending(self):
        rid=self.apply();foreign=self.upload(self.item(self.sid),30)
        for files in ([],[foreign],[self.files[0],self.files[0]],[{}],['bad']):
            with self.subTest(files=files),self.assertRaises(core.UserError):self.decide(rid,files=files)
        for days in (0,2,True,'7',31):
            with self.subTest(days=days),self.assertRaises(core.UserError):self.decide(rid,days=days)
        self.viewer.payload={'decision':'승인','grant_days':7,'file_ids':self.files}
        with self.assertRaises(core.UserError):requests.decision(self.viewer,rid)
        self.assertEqual(requests.listing(self.viewer)['requests'][0]['status'],'신청')
        self.assertEqual(photo_access.options(self.admin,rid)['files'][0]['id'] in self.files,True)
        with self.assertRaises(core.UserError):photo_access.options(self.viewer,rid)
        self.viewer.payload={'target_kind':'photo','record_id':self.iid,'method':'physical','reason':'업무 보고자료 검토'}
        with self.assertRaises(core.UserError):requests.create(self.viewer)

    def test_completion_revokes_permission_without_changing_disclosure(self):
        rid=self.apply();self.decide(rid)
        requests.online_complete(self.admin,rid)
        self.denied(self.viewer,self.files[0],view=True)
        self.assertTrue(self.apply())
        with core.dbconnect(self.cfg) as db:
            self.assertEqual(db.execute('SELECT disclosure FROM photo_series WHERE id=?',(self.sid,)).fetchone()[0],'비공개')
            self.assertEqual(db.execute('SELECT COUNT(*) FROM photo_files').fetchone()[0],2)

    def test_public_is_immediate_but_restriction_changes_are_checked(self):
        self.admin.payload={'title':'공개 사진철','department':'총무팀','disclosure':'공개'}
        sid=photos.save(self.admin,'series')['id'];iid=self.item(sid);fid=self.upload(iid,40)
        self.assertEqual(photos.image(self.viewer,fid,view=True)['type'],'image/jpeg')
        self.denied(self.viewer,fid)
        with core.dbconnect(self.cfg) as db:db.execute("UPDATE photo_items SET disclosure='부분공개' WHERE id=?",(iid,))
        self.denied(self.viewer,fid,view=True)
        self.assertEqual(photos.detail(self.viewer,iid)['effective_disclosure'],'부분공개')
        self.decide(self.apply(iid=iid),files=[fid])
        self.assertEqual(photos.image(self.viewer,fid,view=True)['type'],'image/jpeg')

    def test_photo_and_general_requests_share_inbox_without_interference(self):
        with core.dbconnect(self.cfg) as db:
            state={**server.EMPTY,'records':[{'id':self.iid,'title':'일반기록물','disclosure':'비공개'}]}
            db.execute('UPDATE archive_state SET json_data=? WHERE id=1',(json.dumps(state),))
        photo_id=self.apply()
        self.viewer.payload={'record_id':self.iid,'method':'online','reason':'업무 보고자료 검토'}
        general_id=requests.create(self.viewer)['id']
        rows=requests.listing(self.viewer)['requests']
        self.assertEqual({r['target_kind'] for r in rows},{'record','photo'})
        self.decide(photo_id)
        self.decide(general_id,decision='반려',note='별도 검토 필요')
        self.assertEqual(photos.image(self.viewer,self.files[0],view=True)['type'],'image/jpeg')
        self.viewer.path='/api/v2/access-requests'
        self.admin.path=f'/api/v2/access-requests/{photo_id}/photo-files'
        self.assertEqual(len(server.FullArchiveHandler.route_get(self.admin)['files']),2)
        self.admin.path=f'/api/v2/access-requests/{general_id}/photo-files'
        with self.assertRaises(core.UserError):server.FullArchiveHandler.route_get(self.admin)

    def test_additive_migration_preserves_legacy_request_values(self):
        path=Path(self.temp.name)/'legacy.sqlite3';cfg={**self.cfg,'db_path':str(path)}
        with sqlite3.connect(path) as db:
            # Recreate the shipped schema without new columns, including a legacy approval.
            with core.dbconnect(self.cfg) as current:
                sql=current.execute("SELECT sql FROM sqlite_master WHERE name='access_requests'").fetchone()[0]
            sql=sql.replace(', target_kind TEXT NOT NULL DEFAULT \'record\'','').replace(', photo_file_ids TEXT NOT NULL DEFAULT \'[]\'','')
            db.execute(sql)
            self.assertNotIn('target_kind',{r[1] for r in db.execute('PRAGMA table_info(access_requests)')})
            db.execute("INSERT INTO access_requests(id,record_id,applicant,method,reason,requested_at,status,grant_mode,original_pdf_ids,grant_expires_at,approved_disk_name) VALUES('legacy','GR-1','employee1','online','기존 신청사유','2026-01-01','승인','original','[\"old\"]','2027-01-01T00:00:00+00:00','copy.pdf')")
            before=dict(zip([x[1] for x in db.execute('PRAGMA table_info(access_requests)')],db.execute('SELECT * FROM access_requests').fetchone()))
        requests.ensure_tables(cfg);requests.ensure_tables(cfg)
        with core.dbconnect(cfg) as db:after=dict(db.execute('SELECT * FROM access_requests').fetchone())
        self.assertEqual({k:after[k] for k in before},before)
        self.assertEqual(after['target_kind'],'record');self.assertEqual(after['photo_file_ids'],'[]')


if __name__=='__main__':unittest.main()
