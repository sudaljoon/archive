'use strict';
const $=id=>document.getElementById(id);
let csrf='',allSeries=[],allItems=[],selectedSeries='',selectedItem='',detail=null,editorMode='',editorId='',classRows=[],classLoadSerial=0;
const S=[['title','철명 *'],['department','생산부서 *'],['start_year','생산 시작연도','number'],['end_year','생산 종료연도','number'],['classification_year','기록물분류기준표 연도','number'],['classification_id','분류기준표 기록물철 선택','catalog'],['classification','단위과제·업무 분류'],['retention','보존기간','select',['1년','3년','5년','10년','30년','준영구','영구']],['retention_reason','보존기간 책정사유','textarea'],['disclosure','공개구분','select',['공개','부분공개','비공개']],['notes','비고','textarea']];
const I=[['title','사진기록물건명(행사·주제명) *'],['subtitle','부제목'],['produced_date','생산일자','date'],['shot_date','촬영일자','date'],['shot_place','촬영장소'],['photographer','촬영자'],['producer','생산자·생산기관'],['people','주요 인물·직위'],['summary','내용요약','textarea'],['related_records','관련문서·관리번호'],['media_type','매체유형','select',['디지털사진','인화사진','필름','기타']],['disclosure','공개구분','select',['공개','부분공개','비공개']],['rights','저작권·이용조건'],['notes','비고','textarea']];
function node(tag,cls,content){const el=document.createElement(tag);if(cls)el.className=cls;if(content!==undefined)el.textContent=String(content);return el}
function warn(message){const el=$('notice');el.textContent=message;el.hidden=false;clearTimeout(warn.timer);warn.timer=setTimeout(()=>el.hidden=true,4500)}
function human(error){warn(error.message||String(error))}
async function api(path,opt={}){
 const headers={...(opt.headers||{})};if(opt.method&&opt.method!=='GET')headers['X-CSRF-Token']=csrf;
 if(opt.json){headers['Content-Type']='application/json';opt.body=JSON.stringify(opt.json);delete opt.json}
 const resp=await fetch(path,{credentials:'same-origin',...opt,headers});
 const value=await resp.json().catch(()=>({}));if(!resp.ok)throw Error(value.error||'서버 오류 ('+resp.status+')');return value;
}
function setText(id,val){$(id).textContent=String(val??'')}
async function refresh(keepItem=true){
 const result=await api('/api/v2/photos');
 const wm=result.watermark;setText('watermarkStatus',wm?.ready?'워터마크 적용 중 · '+wm.version:wm?'워터마크 글꼴·로고 파일을 확인해 주세요.':'워터마크 서버 미적용 · 파일 덮어쓰기 후 관리자·직원 서버를 모두 재시작해 주세요.');
 allSeries=result.series;allItems=result.items;
 if(selectedSeries&&!allSeries.some(s=>s.id===selectedSeries))selectedSeries='';
 if(!selectedSeries&&allSeries.length)selectedSeries=allSeries[0].id;
 setText('statSeries',allSeries.length);setText('statItems',allItems.length);setText('statFiles',allItems.reduce((n,item)=>n+item.file_count,0));
 drawSeries();drawItems();
 if(keepItem&&selectedItem&&allItems.some(x=>x.id===selectedItem&&x.series_id===selectedSeries))await showItem(selectedItem);
 else{$('itemDetail').hidden=true;selectedItem='';detail=null}
}
function drawSeries(){
 const holder=$('seriesList');holder.replaceChildren();
 if(!allSeries.length){holder.append(node('div','empty','아직 등록된 사진기록물철이 없습니다.'));return}
 for(const item of allSeries){const btn=node('button',item.id===selectedSeries?'active':'');btn.type='button';btn.append(node('b','',item.title),node('small','',`${item.department} · ${item.start_year||'-'}~${item.end_year||'-'} · ${item.retention||'보존기간 미설정'} · ${item.disclosure}${item.classification_id?' · 분류기준표 연계':''}`));btn.onclick=()=>{selectedSeries=item.id;selectedItem='';$('itemDetail').hidden=true;drawSeries();drawItems()};holder.append(btn)}
}
function drawItems(){
 const s=allSeries.find(x=>x.id===selectedSeries);setText('itemHeading',s?`${s.title} · 기록물건`:'사진기록물건');$('editSeries').disabled=!s;$('addItem').disabled=!s;
 const q=$('search').value.trim().toLocaleLowerCase();const items=allItems.filter(x=>x.series_id===selectedSeries&&(!q||[x.title,x.summary,x.people,x.shot_place].some(v=>String(v).toLocaleLowerCase().includes(q))));
 const holder=$('itemList');holder.replaceChildren();
 if(!s){holder.append(node('div','empty','먼저 사진기록물철을 등록해 주세요.'));return}
 if(!items.length){holder.append(node('div','empty','해당 기록물철에 등록된 건이 없습니다.'));return}
 for(const item of items){const btn=node('button','item');btn.type='button';
 const img=node('img');if(item.cover_file)img.src=`/api/v2/photos/files/${item.cover_file}/preview?wm=20261105v2`;img.alt='대표사진';img.loading='lazy';
 const t=node('div','itemtext');t.append(node('b','',item.title),node('small','',`${item.shot_date||item.produced_date||'날짜 미입력'} · ${item.shot_place||'장소 미입력'} · 원본 ${item.file_count}장`));
 btn.append(img,t,node('span','pill'+(item.disclosure==='공개'?'':' private'),item.disclosure));btn.onclick=()=>showItem(item.id).catch(human);holder.append(btn)}
}
function meta(holder,labels){holder.replaceChildren();for(const [label,value]of labels){const wrap=node('div');wrap.append(node('b','',label),node('span','',value||'—'));holder.append(wrap)}}
async function showItem(id){
 const result=await api(`/api/v2/photos/items/${id}`);selectedItem=id;detail=result;$('itemDetail').hidden=false;
 setText('detailTitle',result.item.title);setText('fileCount',result.files.length);setText('itemSummary',result.item.summary||'내용요약이 등록되지 않았습니다.');
 const i=result.item;meta($('itemMeta'),[['촬영일자',i.shot_date],['촬영장소',i.shot_place],['주요 인물·직위',i.people],['생산일자',i.produced_date],['촬영자',i.photographer],['공개구분',i.disclosure]]);
 meta($('itemExtra'),[['사진 부제목',i.subtitle],['생산자',i.producer],['매체유형',i.media_type],['관련문서',i.related_records],['저작권·이용조건',i.rights],['비고',i.notes]]);
 $('itemHistory').href='/activity?event=시청각&target='+encodeURIComponent(id);
 await drawLinked(id);
 const holder=$('fileList');holder.replaceChildren();if(!result.files.length){holder.append(node('div','empty','등록된 사진이 없습니다. 여러 장을 한 건에 등록할 수 있습니다.'));return}
 for(const file of result.files){const wrap=node('div','photo'),img=node('img');img.src=`/api/v2/photos/files/${file.id}/preview?wm=20261105v2`;img.alt=file.original_name;img.loading='lazy';
 const marked=node('a','btn small','워터마크 확대 열람');marked.href=`/api/v2/photos/files/${file.id}/view?wm=20261105v2`;marked.target='_blank';marked.rel='noopener noreferrer';
 const imageLink=node('a');imageLink.href=marked.href;imageLink.target='_blank';imageLink.rel='noopener noreferrer';imageLink.title='워터마크 확대 열람';imageLink.append(img);
 const a=node('a','',file.original_name+' · 원본 다운로드 (워터마크 없음)');a.href=`/api/v2/photos/files/${file.id}/original`;a.title='원본 파일 내려받기';
 wrap.append(imageLink,marked,a,node('small','',`${file.width}×${file.height} · ${(file.size_bytes/1048576).toFixed(2)}MB · SHA-256 ${file.sha256.slice(0,12)}…`));holder.append(wrap)}
}
function buildFields(spec,values={}){
 const holder=$('editorFields');holder.replaceChildren();
 for(const [key,label,type,choices]of spec){const wrap=node('label','field'+(type==='textarea'||type==='catalog'?' wide':'')),lab=node('span','',label);
 let input;if(type==='textarea'){input=node('textarea');input.rows=3}
 else if(type==='catalog'){input=node('select');input.append(new Option('기준표를 조회하는 중입니다.',''))}
 else if(type==='select'){input=node('select');input.append(new Option('선택해 주세요',''));for(const choice of choices)input.append(new Option(choice,choice))}
 else{input=node('input');input.type=type||'text';if(type==='number'){input.min='1900';input.max='2100'}}
 input.name=key;input.value=String(values[key]??(key==='disclosure'?'비공개':''));
 if(key==='title'||key==='department')input.required=true;
 wrap.append(lab,input);
 if(type==='catalog')wrap.append(node('small','muted','생산부서·생산연도에 해당하는 기존 기록물분류기준표를 조회합니다. 선택하면 분류·보존기간·책정사유가 자동 입력됩니다.'));
 holder.append(wrap)
 }
}
function edit(kind,id=''){
 if(editorBusy)return;editorQueue=[];$('editorFiles').value='';$('editorResults').replaceChildren();$('editorProgress').textContent='';$('editorSave').textContent='저장';$('editorPhotos').hidden=kind!=='items';
 editorMode=kind;editorId=id;const obj=kind==='series'?(allSeries.find(s=>s.id===id)||{}):(detail?.item?.id===id?detail.item:{});
 setText('editorHeading',`${kind==='series'?'사진기록물철':'사진기록물건'} ${id?'수정':'신규 등록'}`);buildFields(kind==='series'?S:I,obj);$('editor').showModal();
 if(kind==='series')setupClassificationEditor(obj);
}
function seriesFormField(name){return $('editorForm').elements.namedItem(name)}
function classificationWeight(value){
 const s=String(value||'').trim().replace(/년$/,'');
 return s==='영구'?100000:s==='준영구'?10000:/^\d+$/.test(s)?Number(s):-1;
}
function setClassificationLocked(locked){
 seriesFormField('classification').readOnly=locked;
 seriesFormField('retention').disabled=locked;
 seriesFormField('retention_reason').readOnly=locked;
}
function applyClassificationChoice(){
 const id=seriesFormField('classification_id').value,row=classRows.find(r=>r.id===id);
 setClassificationLocked(!!row);if(!row)return;
 if(row.department!=='처리과 공통')seriesFormField('department').value=row.department;
 if(!seriesFormField('start_year').value)seriesFormField('start_year').value=seriesFormField('classification_year').value;
 seriesFormField('classification').value=[row.unit,row.fileSeries].filter(Boolean).join(' > ');
 seriesFormField('retention').value=row.fileRetention;
 seriesFormField('retention_reason').value=row.reason;
}
async function loadClassificationOptions(preservedId=''){
 const serial=++classLoadSerial,year=seriesFormField('classification_year').value,dept=seriesFormField('department').value.trim();
 const select=seriesFormField('classification_id');select.disabled=true;select.replaceChildren(new Option('기준표 조회 중...',''));
 if(!/^\d{4}$/.test(year)){select.replaceChildren(new Option('분류기준표 연도를 입력해 주세요.',''));return}
 try{
  const params=new URLSearchParams({year,department:dept});const result=await api('/api/v2/photos/classifications?'+params.toString());
  if(serial!==classLoadSerial||editorMode!=='series'||!$('editor').open)return;
  classRows=result.rows||[];select.replaceChildren(new Option('연계하지 않음 · 수기 등록',''));
  for(const row of classRows){
   const invalid=classificationWeight(row.fileRetention)<0||classificationWeight(row.fileRetention)>classificationWeight(row.unitRetention);
   const option=new Option(`${row.department} · ${row.unit} / ${row.fileSeries} · 보존 ${row.fileRetention}${invalid?' [보존기간 상한 확인]':''}`,row.id);
   option.disabled=invalid;
   select.append(option);
  }
  if(preservedId){
   if(classRows.some(row=>row.id===preservedId))select.value=preservedId;
   else{const missing=new Option('기존 연계항목이 현 기준표에 없습니다. 다시 선택해 주세요.',preservedId);select.append(missing);select.value=preservedId}
  }
  if(!classRows.length)select.options[0].textContent='해당 연도·부서에 등록된 기준표 항목 없음 · 수기 등록';
  select.disabled=false;
  setClassificationLocked(!!select.value);
 }catch(e){if(serial!==classLoadSerial)return;classRows=[];select.replaceChildren(new Option('기준표 조회 실패: '+e.message,preservedId));select.disabled=false;setClassificationLocked(!!preservedId)}
}
function setupClassificationEditor(values){
 const start=seriesFormField('start_year'),year=seriesFormField('classification_year'),dept=seriesFormField('department'),select=seriesFormField('classification_id');
 if(!year.value)year.value=start.value?String(Math.max(2024,Number(start.value))):String(new Date().getFullYear());
 setClassificationLocked(!!values.classification_id);
 start.addEventListener('change',()=>{year.value=start.value?String(Math.max(2024,Number(start.value))):year.value;loadClassificationOptions().catch(human)});
 year.addEventListener('change',()=>loadClassificationOptions().catch(human));
 dept.addEventListener('change',()=>loadClassificationOptions().catch(human));
 select.addEventListener('change',applyClassificationChoice);
 loadClassificationOptions(values.classification_id||'').catch(human);
}
let editorBusy=false,editorQueue=[];
function editorRows(){const box=$('editorResults');box.replaceChildren();for(const row of editorQueue)box.append(node('p','',`${row.file.name} — ${row.status==='ok'?'등록 완료':row.error||'대기'}`))}
async function saveEditor(event){
 event.preventDefault();if(editorBusy)return;
 if(editorMode==='series'&&seriesFormField('classification_id').disabled){warn('분류기준표 조회가 끝난 후 저장해 주세요.');return}
 const spec=editorMode==='series'?S:I,payload={},fd=new FormData($('editorForm'));
 for(const [key]of spec)payload[key]=fd.get(key)||'';
 const seriesId=selectedSeries;let savedId=editorId;
 if(editorMode==='items'&&!savedId)payload.series_id=seriesId;
 editorBusy=true;
 const controls=[...$('editorForm').querySelectorAll('input,select,textarea,button')].map(el=>[el,el.disabled]);controls.forEach(([el])=>el.disabled=true);
 try{
  if(editorMode==='series'||savedId||!editorQueue.length){
   const saved=await api('/api/v2/photos/'+editorMode+(savedId?'/'+savedId:''),{method:savedId?'PUT':'POST',json:payload});savedId=saved.id;editorId=savedId;
  }
  if(editorMode==='items'){
   for(let n=0;n<editorQueue.length;n++){
    const row=editorQueue[n];if(row.status==='ok')continue;
    $('editorProgress').textContent=`사진 ${n+1} / ${editorQueue.length} 처리 중`;
    try{
     if(row.file.size>30*1024*1024)throw Error('30MB 초과');
     const endpoint=savedId?'/api/v2/photos/items/'+savedId+'/files':'/api/v2/photos/series/'+seriesId+'/batch';
     const saved=await api(endpoint,{method:'POST',body:row.file,headers:{'Content-Type':'application/octet-stream','X-Original-Filename':encodeURIComponent(row.file.name),'X-Photo-Metadata':encodeURIComponent(JSON.stringify(payload))}});
     savedId=saved.item_id;editorId=savedId;row.status='ok';row.error='';
    }catch(e){row.status='failed';row.error='실패: '+e.message}
    editorRows();
   }
  }
  const failed=editorQueue.filter(r=>r.status!=='ok').length,ok=editorQueue.filter(r=>r.status==='ok').length;
  if(editorMode==='series')selectedSeries=savedId;
  await refresh(false);if(editorMode==='items'&&savedId)await showItem(savedId);
  if(failed){
   $('editorProgress').textContent=`사진 ${ok}장 등록 완료 / 실패 ${failed}장. ${savedId?'저장된 같은 건에 실패 사진만 재시도합니다.':'아직 건이 생성되지 않았습니다.'}`;
   $('editorSave').textContent='저장 / 실패 사진 재시도';
  }else{$('editor').close();warn(editorMode==='items'?`건 정보와 사진 ${ok}장을 저장했습니다.`:'저장했습니다.')}
 }catch(e){$('editorProgress').textContent=e.message;human(e)}
 finally{editorBusy=false;controls.forEach(([el,disabled])=>el.disabled=disabled)}
}
async function uploadFiles(event){
 const files=[...event.target.files];event.target.value='';if(!selectedItem||!files.length)return;
 const failed=[];let success=0;
 for(const file of files){if(file.size>30*1024*1024){failed.push(file.name+': 30MB 초과');continue}
  try{await api(`/api/v2/photos/items/${selectedItem}/files`,{method:'POST',body:file,headers:{'Content-Type':'application/octet-stream','X-Original-Filename':encodeURIComponent(file.name)}});success++}
  catch(e){failed.push(file.name+': '+e.message)}
 }
 await refresh();warn(`${success}장 등록 완료.`+(failed.length?' 실패: '+failed.join(' / '):''));
}
function csvDownload(){
 const rows=[['철명','건명','생산부서','촬영일자','촬영장소','생산자','주요 인물·직위','공개구분','파일 수량','내용요약']];
 for(const x of allItems.filter(x=>!selectedSeries||x.series_id===selectedSeries))rows.push([x.series_title,x.title,x.department,x.shot_date,x.shot_place,x.producer,x.people,x.disclosure,x.file_count,x.summary]);
 const escape=v=>{let s=String(v??'');if(/^[=+@\-\t\r]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};
 const csv='\ufeff'+rows.map(r=>r.map(escape).join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
 const a=node('a');a.href=url;a.download='사진기록물목록.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
async function init(){
 const session=await api('/api/session');if(!session.authenticated||session.role!=='admin')throw Error('관리자 계정으로 로그인해 주세요.');csrf=session.csrf;
 $('addSeries').onclick=()=>edit('series');$('editSeries').onclick=()=>edit('series',selectedSeries);$('addItem').onclick=()=>edit('items');
 $('editItem').onclick=()=>edit('items',selectedItem);$('search').oninput=drawItems;$('exportCsv').onclick=csvDownload;
 $('editorForm').onsubmit=saveEditor;$('closeEditor').onclick=()=>{$('editor').close()};$('cancelEditor').onclick=()=>{$('editor').close()};$('fileInput').onchange=e=>uploadFiles(e).catch(human);
 await refresh();
 await initExtensions();
}



async function drawLinked(id){
 const d=await api('/api/v2/photos/links?item='+encodeURIComponent(id));
 const holder=$('linkedRecords');holder.replaceChildren();
 if(!d.linked.length)holder.append(node('span','muted','연계된 일반기록물이 없습니다.'));
 for(const r of d.linked){const a=node('a','btn small',r.id+' · '+r.title);a.href='/manager?record='+encodeURIComponent(r.id)+'#records';holder.append(a)}
}
async function loadLinks(){
 const id=selectedItem;
 const d=await api('/api/v2/photos/links?'+new URLSearchParams({item:id,q:$('linkSearch').value}));
 if(id!==selectedItem)return;
 for(const [key,rows,action] of [['linkCurrent',d.linked,'remove'],['linkCandidates',d.candidates.filter(r=>!d.linked.some(l=>l.id===r.id)),'add']]){
  const holder=$(key);holder.replaceChildren();
  if(!rows.length)holder.append(node('p','muted','해당 기록물이 없습니다.'));
  for(const r of rows){const b=node('button','',`${action==='add'?'연계':'해제'} · ${r.id} · ${r.title} · ${r.dept||''}`);b.onclick=async()=>{b.disabled=true;try{await api('/api/v2/photos/links',{method:'POST',json:{item_id:id,record_id:r.id,action}});await loadLinks();await drawLinked(id)}catch(e){human(e);b.disabled=false}};holder.append(b)}
 }
}
async function initExtensions(){
 $('editor').addEventListener('cancel',e=>{if(editorBusy)e.preventDefault()});
 window.addEventListener('beforeunload',e=>{if(editorBusy){e.preventDefault();e.returnValue=''}});
 $('editorFiles').onchange=()=>{
  const files=[...$('editorFiles').files];editorQueue=[];
  if(files.length>100){$('editorFiles').value='';$('editorProgress').textContent='한 번에 100장 이하로 선택해 주세요.'}
  else{editorQueue=files.map(file=>({file,status:'pending'}));$('editorProgress').textContent=files.length+'장 선택됨'}
  editorRows();$('editorSave').textContent='저장';
 };
 $('linkOpen').onclick=()=>{$('linkDialog').showModal();loadLinks().catch(human)};
 $('linkFind').onclick=()=>loadLinks().catch(human);$('linkSearch').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();loadLinks().catch(human)}};
 $('linkClose').onclick=()=>$('linkDialog').close();
 $('recordPhotosClose').onclick=()=>$('recordPhotos').close();
 const q=new URLSearchParams(location.search);
 if(q.get('item')){const item=allItems.find(i=>i.id===q.get('item'));if(item){selectedSeries=item.series_id;drawSeries();drawItems();await showItem(item.id)}}
 if(q.get('record')){
  const d=await api('/api/v2/photos/links?record='+encodeURIComponent(q.get('record')));
  $('recordPhotosTitle').textContent=d.record.id+' · '+d.record.title;
  const holder=$('recordPhotosList');holder.replaceChildren();
  if(!d.items.length)holder.append(node('p','muted','연계된 사진기록물이 없습니다. 사진 건의 일반기록물 연계 관리에서 추가할 수 있습니다.'));
  for(const item of d.items){const b=node('button','',item.title);b.onclick=()=>{$('recordPhotos').close();selectedSeries=item.series_id;drawSeries();drawItems();showItem(item.id).catch(human)};holder.append(b)}
  $('recordPhotos').showModal();
 }
}
init().catch(human);
