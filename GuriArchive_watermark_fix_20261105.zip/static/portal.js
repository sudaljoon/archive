'use strict';
const $=s=>document.querySelector(s);let applyKind='record',currentPhoto=null,photoExpiryTimer=0,photoDetailSerial=0;let csrf='',entries=[],requests=[],selectedTab='search', contentMatches=new Map(), contentQuery='', contentError='', contentTimer=0, contentSerial=0, historyPage=1, historySerial=0, historyTotalPages=1, photoSeriesReady=false, photoSerial=0, photoFiles=[], photoIndex=0;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path,opts={}){let r=await fetch(path,{credentials:'same-origin',cache:'no-store',...opts});let d={};if(r.headers.get('content-type')?.includes('json'))d=await r.json();if(!r.ok)throw Error(d.error||`요청 실패 (${r.status})`);return d}
function post(path,body){return api(path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)})}
function closeDialog(id){const d=document.getElementById(id);if(d?.open)d.close();if(id==='pdf-dialog')$('#pdf-frame').replaceChildren('열람할 PDF 파일을 선택하세요.');if(id==='photo-dialog'){photoDetailSerial++;$('#photo-large').removeAttribute('src');photoFiles=[]}}
function setTab(tab){if(!['search','applications','history','photos'].includes(tab))return;selectedTab=tab;$('#search-view').hidden=tab!=='search';$('#applications-view').hidden=tab!=='applications';$('#history-view').hidden=tab!=='history';$('#photos-view').hidden=tab!=='photos';for(let t of ['search','applications','history','photos'])$('#menu-'+t).classList.toggle('active',t===tab);if(tab==='applications')loadRequests().catch(e=>alert(e.message));if(tab==='history')loadHistory();if(tab==='photos')loadPhotos().catch(e=>$('#photo-error').textContent=e.message)}
async function start(){try{const s=await api('/api/session');if(!s.authenticated){$('#login').hidden=false;$('#viewer').hidden=true;return}csrf=s.csrf;if(s.role==='admin'){location.replace('/manager');return}$('#login').hidden=true;$('#viewer').hidden=false;$('#account').innerHTML=`<b>${esc(s.username)}</b> <button id="logout" class="subtle">로그아웃</button>`;$('#logout').onclick=logout;await loadCatalog();if(location.pathname==='/photos/public')setTab('photos')}catch(e){$('#message').textContent=e.message}}
async function logout(){try{await api('/api/logout',{method:'POST',headers:{'X-CSRF-Token':csrf}})}finally{location.replace('/')}}
async function loadCatalog(){const r=await api('/api/v2/catalog');entries=[...(r.records||[]).map(x=>({...x,kind:'records'})),...(r.artifacts||[]).map(x=>({...x,kind:'artifacts'}))];$('#fetched').textContent='서버 목록 최신 조회';refreshCatalogSearch()}
function drawCatalog(){
 const q=($('#search')?.value||'').trim().toLocaleLowerCase('ko-KR');
 const kind=$('#type-filter')?.value||'all';
 const searchBy=$('#search-category')?.value||'all';
 const disclosure=$('#disclosure-filter')?.value||'all';
 const retention=$('#retention-filter')?.value||'all';
 const hasCriteria=Boolean(q)||kind!=='all'||disclosure!=='all'||retention!=='all';
 $('#catalog-table').hidden=!hasCriteria;
 if(!hasCriteria){
  $('#count').textContent='검색어를 입력하거나 검색 조건을 선택해 주세요.';
  $('#rows').replaceChildren();
  return;
 }
 const fields={all:['id','title','dept','year','productionDate','series','location'],title:['title'],dept:['dept'],year:['year','productionDate'],id:['id'],series:['series','type'],location:['location']};
 const keys=fields[searchBy]||fields.all;
 const list=entries.filter(x=>{
  if(kind!=='all'&&kind!==x.kind)return false;
  if(disclosure!=='all'&&x.disclosure!==disclosure)return false;
  if(retention!=='all'&&(x.kind!=='records'||String(x.retention??'').trim().replace(/년$/, '')!==retention))return false;
  if(searchBy==='content')return x.kind==='records'&&q.length>=2&&contentQuery===q&&contentMatches.has(x.id);
  return !q||keys.some(key=>String(x[key]??'').toLocaleLowerCase('ko-KR').includes(q));
 });
 $('#count').textContent=searchBy==='content'?`PDF 내용검색 ${list.length}건${contentError?' · '+contentError:''}`:`검색결과 ${list.length}건 / 전체 ${entries.length}건`;
$('#rows').innerHTML=list.map(x=>{const hasPdf=x.kind==='records'&&x.has_pdf===true;const pdfLabel=hasPdf?'PDF 등록됨':'PDF 없음';return `<tr><td><span class="tag">${x.kind==='records'?'비전자기록물':'행정박물'}</span></td><td>${x.kind==='records'?`<button class="title-btn" data-detail="${esc(x.id)}">${esc(x.title)}</button>`:`<strong>${esc(x.title)}</strong>`}<small>${esc(x.id)}</small>${searchBy==='content'&&contentMatches.has(x.id)?`<small class="ocr-snippet">${x.disclosure==='공개'?esc(contentMatches.get(x.id).snippet)+' · '+esc(contentMatches.get(x.id).page)+'쪽':'PDF 본문 일치 · 열람신청 후 원문 열람 가능'}</small>`:''}</td><td>${esc(x.dept||'—')}</td><td>${esc(x.year||x.productionDate||'—')}</td><td><span class="tag ${x.disclosure==='공개'?'public':'private'}">${esc(x.disclosure||'확인 필요')}</span></td><td>${esc(x.location||'미배정')}</td><td class="pdf-status-cell"><span class="pdf-status ${hasPdf?'pdf-yes':'pdf-no'}" title="${pdfLabel}" aria-label="${pdfLabel}">${hasPdf?'O':'X'}</span></td></tr>`}).join('')||'<tr><td colspan="7" class="empty">검색결과가 없습니다.</td></tr>'}
function refreshCatalogSearch(){
 const by=$('#search-category').value;
 $('#ocr-hint').textContent=by==='content'
  ?'등록된 모든 기록물철 PDF의 본문에서 검색합니다. 부분공개·비공개 기록물은 기록물철명만 표시하며, PDF 내용과 원문은 열람 승인 후 확인할 수 있습니다. (2글자 이상 입력)'
  :'실물 반출 중에도 온라인 PDF 열람은 가능하며, 비공개 원본은 별도 열람 승인이 필요합니다.';
 if(by!=='content'){contentSerial++;clearTimeout(contentTimer);drawCatalog();return}
 const q=($('#search').value||'').trim().toLocaleLowerCase('ko-KR');
 if(q.length<2){contentMatches.clear();contentQuery='';contentError='2글자 이상 입력';contentSerial++;clearTimeout(contentTimer);drawCatalog();return}
 const current=++contentSerial;contentQuery='';contentMatches.clear();contentError='검색 중';drawCatalog();
 clearTimeout(contentTimer);
 contentTimer=setTimeout(async()=>{try{const result=await api('/api/v2/ocr/search?q='+encodeURIComponent(q));
 if(current!==contentSerial)return;
 contentQuery=q;contentMatches=new Map((result.matches||[]).map(x=>[x.record_id,x]));contentError=result.pending_files?`검색 준비 중이거나 실패한 PDF ${result.pending_files}개` : '';drawCatalog();
 }catch(e){if(current!==contentSerial)return;contentQuery=q;contentMatches.clear();contentError=e.message;drawCatalog()}},350);
}
const field=(label,value)=>`<div><span>${esc(label)}</span><strong>${esc(value||'—')}</strong></div>`;
async function showDetail(id){const res=await api(`/api/v2/records/${encodeURIComponent(id)}/detail`),r=res.record;let disclosed=r.disclosure==='공개';let detail=[['관리번호',r.id],['기록물철명',r.title],['생산부서',r.dept],['생산연도',r.year],['업무분류',r.series],['보존기간',r.retention],['기산연도',r.base],['기록물 형태',r.format],['수량',r.count],['공개구분',r.disclosure],['보존상자',r.box],['보존위치',r.location],['보존상태',r.condition],['실물대조',r.verifyStatus]];
$('#detail-content').innerHTML=`<div class="detail-grid">${detail.map(([a,b])=>field(a,b)).join('')}</div>${r.physical_loaned?'<p class="loan-note">📦 실물 반출 중 · 온라인 PDF 열람은 별도로 가능합니다.</p>':''}<div class="detail-footer">${disclosed?`<p><b>공개 기록물</b> — 첨부된 스캔 PDF를 열람할 수 있습니다.</p><button class="primary" data-pdf-public="${esc(id)}">📄 스캔 PDF 열람</button>`:`<p><b>${esc(r.disclosure||'비공개')} 기록물</b> — PDF 원문은 표시되지 않습니다. 열람하려면 담당자의 승인을 신청하세요.</p>`}<button class="subtle quick" data-request="${esc(id)}">열람신청</button><p class="hint">실물 열람·대출도 열람신청에서 선택할 수 있습니다. 온라인 원본 열람은 담당자가 허용한 파일과 기간에만 적용됩니다.</p></div>`;$('#detail-dialog').showModal()}
function requestDialog(id){applyKind='record';$('#apply-method').disabled=false;$('#apply-method').options[0].textContent='온라인 PDF 열람';const record=entries.find(x=>x.kind==='records'&&x.id===id);if(!record)return;$('#apply-record-id').value=id;$('#apply-record-title').textContent=record.title;$('#apply-reason').value='';$('#apply-method').value=record.disclosure==='공개'?'physical':'online';$('#apply-message').textContent='';methodHelp();closeDialog('detail-dialog');$('#apply-dialog').showModal()}
function methodHelp(){if(applyKind==='photo'){$('#method-help').textContent='관리자가 허용한 사진만 1·7·30일 중 승인된 기간 동안 화면에서 열람합니다. 원본 다운로드는 제공하지 않습니다.';return}$('#method-help').textContent=$('#apply-method').value==='online'?'온라인 PDF 열람은 실물 반출 여부와 관계없이 신청·승인·열람할 수 있습니다. 승인된 기존 원본 PDF만 허용기간 동안 제공되며 공개구분은 바뀌지 않습니다.':'실물 열람·대출 신청은 관리자 승인 후 별도 반출 처리 및 반납 확인이 필요합니다.'}
async function submitRequest(ev){ev.preventDefault();const b=ev.submitter;if(b)b.disabled=true;try{const data=await post('/api/v2/access-requests',{target_kind:applyKind,record_id:$('#apply-record-id').value,method:$('#apply-method').value,reason:$('#apply-reason').value.trim()});closeDialog('apply-dialog');setTab('applications');await loadRequests()}catch(e){$('#apply-message').textContent=e.message}finally{if(b)b.disabled=false}}
async function loadRequests(){const d=await api('/api/v2/access-requests');requests=d.requests||[];
$('#request-rows').innerHTML=requests.map(r=>{const original=r.method==='online'&&r.original_pdf_available;
const redacted=r.method==='online'&&r.approved_copy_available;
const expired=r.grant_expired?'<small>열람기간 만료 — 재신청 가능</small>':'';
const until=r.grant_expires_at?`<small>허용 종료 ${esc(new Date(r.grant_expires_at).toLocaleString('ko-KR',{timeZone:'Asia/Seoul'}))}</small>`:'';
return `<tr><td>${esc((r.requested_at||'').replace('T',' ').slice(0,16))}</td><td><strong>${esc(r.record_title)}</strong><small>${esc(r.record_id)}</small></td><td>${r.target_kind==='photo'?'시청각 사진 열람':r.method==='online'?'온라인 PDF 열람':'실물 열람·대출'}</td><td><span class="tag">${esc(r.status)}</span>${expired}${until}${r.due_date?`<small>반납예정 ${esc(r.due_date)}</small>`:''}</td><td>${esc(r.decision_note||'—')}${r.target_kind==='photo'?`<br><button class="${r.photo_available?'primary':'subtle'}" data-photo-item="${esc(r.record_id)}">${r.photo_available?'승인된 사진 열람 ('+esc(r.selected_photo_count)+'장)':'사진정보 · 재신청'}</button>`:''}${original?`<br><button class="primary" data-original="${esc(r.id)}">승인된 원본 PDF 열람</button>`:''}${redacted?`<br><button class="primary" data-approved="${esc(r.id)}">가림 처리본 PDF 열람</button>`:''}</td></tr>`}).join('')||'<tr><td class="empty" colspan="5">아직 신청한 기록물이 없습니다.</td></tr>'}

function kstDay(){const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());const values=Object.fromEntries(parts.map(p=>[p.type,p.value]));return `${values.year}-${values.month}-${values.day}`}
function daysBefore(end,count){const d=new Date(end+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-(count-1));return d.toISOString().slice(0,10)}
function toggleHistoryCustom(){const custom=$('#history-period').value==='custom';$('#history-custom').hidden=!custom;if(custom){const today=kstDay();if(!$('#history-to').value)$('#history-to').value=today;if(!$('#history-from').value)$('#history-from').value=daysBefore(today,30)}}
function historyParams(){const period=$('#history-period').value;let from,to;if(period==='custom'){from=$('#history-from').value;to=$('#history-to').value;if(!from||!to)throw Error('시작일과 종료일을 모두 선택해 주세요.');if(from>to)throw Error('시작일은 종료일보다 늦을 수 없습니다.')}else{const days=Number(period);if(![7,30,90].includes(days))throw Error('조회기간을 선택해 주세요.');to=kstDay();from=daysBefore(to,days)}const p=new URLSearchParams({from,to,type:$('#history-type').value,q:$('#history-keyword').value.trim(),page:String(historyPage)});return p.toString()}
function displayHistoryDate(value){const d=new Date(value);return Number.isNaN(d.getTime())?'—':d.toLocaleString('ko-KR',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false})}
const historyLabels={'로그인 성공':'로그인','로그아웃':'로그아웃','세션 만료':'세션 만료','세션 무효화':'세션 종료','상세정보 조회':'기록물 조회','PDF 원문 열람':'PDF 열람','승인 PDF 열람':'승인 PDF 열람','열람신청':'열람신청','온라인 열람 완료':'열람 완료'};
async function loadHistory(){const serial=++historySerial;$('#history-error').textContent='';let query;try{query=historyParams()}catch(e){$('#history-error').textContent=e.message;return}$('#history-count').textContent='사용기록을 불러오는 중입니다.';
 try{const data=await api('/api/v2/my-activity?'+query);if(serial!==historySerial)return;
 const summary=data.summary||{};$('#history-record-count').innerHTML=`${Number(summary.record_views||0)}<small>건</small>`;$('#history-pdf-count').innerHTML=`${Number(summary.pdf_views||0)}<small>건</small>`;$('#history-request-count').innerHTML=`${Number(summary.requests||0)}<small>건</small>`;
 const rows=data.rows||[];$('#history-rows').innerHTML=rows.map(r=>`<tr><td>${esc(displayHistoryDate(r.at))}</td><td>${esc(historyLabels[r.event]||r.event)}</td><td>${esc(r.target_title||'—')}${r.target_id?`<small>${esc(r.target_id)}</small>`:''}</td><td><span class="tag ${r.result==='성공'?'public':'private'}">${esc(r.result||'—')}</span></td></tr>`).join('')||'<tr><td class="empty" colspan="4">선택한 기간에 사용기록이 없습니다.</td></tr>';
 historyPage=Number(data.page)||historyPage;historyTotalPages=Math.max(1,Math.ceil((Number(data.total)||0)/(Number(data.page_size)||30)));
 $('#history-count').textContent=`조회결과 ${Number(data.total)||0}건`;
 $('#history-page').textContent=`${historyPage} / ${historyTotalPages}`;$('#history-prev').disabled=historyPage<=1;$('#history-next').disabled=historyPage>=historyTotalPages;
 }catch(e){if(serial!==historySerial)return;$('#history-error').textContent=e.message;$('#history-count').textContent='사용기록 조회 실패';$('#history-rows').innerHTML='<tr><td class="empty" colspan="4">기록을 불러오지 못했습니다.</td></tr>'}}

async function pdfPublic(id){$('#pdf-dialog').showModal();$('#pdf-title').textContent='공개 기록물 PDF';$('#pdf-files').textContent='불러오는 중...';$('#pdf-frame').replaceChildren('PDF 파일을 선택해 주세요.');try{const data=await api(`/api/v2/records/${encodeURIComponent(id)}/pdfs`);const list=$('#pdf-files');list.replaceChildren();if(!data.files?.length){list.textContent='첨부된 PDF가 없습니다.';return}data.files.forEach((f,i)=>{let b=document.createElement('button');b.className='subtle';b.textContent=f.original_name;b.onclick=()=>showPdf(`/api/v2/records/${encodeURIComponent(id)}/pdfs/${f.file_id}/content`);list.appendChild(b);if(i===0)b.click()})}catch(e){$('#pdf-files').textContent=e.message}}
function showPdf(path){let frame=document.createElement('iframe');frame.title='열람 승인 PDF';frame.src=path;$('#pdf-frame').replaceChildren(frame)}
function pdfApproved(id){$('#pdf-dialog').showModal();$('#pdf-title').textContent='가림 처리본 PDF 열람';$('#pdf-files').textContent='신청자에게 허용된 PDF만 표시됩니다.';showPdf(`/api/v2/access-requests/${id}/approval-copy/content`)}
async function pdfOriginal(id){$('#pdf-dialog').showModal();$('#pdf-title').textContent='승인된 원본 PDF 열람';$('#pdf-files').textContent='허용 파일 목록 조회 중...';$('#pdf-frame').replaceChildren('PDF를 선택해 주세요.');
try{const r=await api(`/api/v2/access-requests/${id}/original-pdfs`);const box=$('#pdf-files');box.replaceChildren();
if(!r.files?.length){box.textContent='열람 가능한 원본 PDF가 없습니다.';return}
r.files.forEach((f,i)=>{const b=document.createElement('button');b.className='subtle';b.textContent=f.original_name;
b.onclick=()=>showPdf(`/api/v2/access-requests/${id}/original-pdfs/${f.file_id}/content`);box.appendChild(b);if(i===0)b.click()});
}catch(err){$('#pdf-files').textContent=err.message}}

/* 사진 열람은 직원 포털 내부의 네 번째 탭으로 렌더링합니다. */
async function loadPhotos(){
 const seq=++photoSerial,series=$('#photo-series'),field=$('#photo-search-category').value;
 const query=(field==='shot_date'?$('#photo-date').value:$('#photo-search').value.trim());
 $('#photo-error').textContent='';$('#photo-count').textContent='사진기록물을 조회하는 중입니다.';
 const params=new URLSearchParams({field});if(series.value)params.set('series',series.value);if(query)params.set('q',query);
 const data=await api('/api/v2/photos?'+params.toString());if(seq!==photoSerial)return;
 const wm=data.watermark,status=$('#photo-watermark-status');
 if(status)status.textContent=wm?.ready?'워터마크 적용 중 · '+wm.version:wm?'워터마크 글꼴·로고 파일을 확인해 주세요.':'워터마크 서버 미적용 · 파일 덮어쓰기 후 관리자·직원 서버를 모두 재시작해 주세요.';
 if(!photoSeriesReady){for(const item of data.series||[]){const option=document.createElement('option');option.value=item.id;option.textContent=item.title;series.append(option)}photoSeriesReady=true}
 const rows=data.items||[],grid=$('#photo-results');grid.replaceChildren();
 if(field==='shot_date'&&!query){$('#photo-count').textContent='촬영일자를 선택해 주세요.';const empty=document.createElement('div');empty.className='photo-empty';empty.textContent='날짜를 선택하면 해당 날짜에 촬영한 사진기록물을 조회합니다.';grid.append(empty);return}
 $('#photo-count').textContent=`사진기록물 ${rows.length}건`;
 if(!rows.length){const empty=document.createElement('div');empty.className='photo-empty';empty.textContent='검색된 사진기록물이 없습니다.';grid.append(empty);return}
 for(const item of rows){
  const card=document.createElement('button');card.type='button';card.className='photo-card';card.dataset.photoItem=item.id;
  const img=document.createElement('img');img.className='photo-card-thumb';img.alt=item.title+' 대표 사진';img.loading='lazy';
  if(item.cover_file)img.src=`/api/v2/photos/files/${item.cover_file}/preview?wm=20261105v2`;
  const info=document.createElement('span');info.className='photo-card-info';
  const title=document.createElement('strong');title.textContent=item.title;
  const sub=document.createElement('small');sub.textContent=`${item.series_title} · ${item.shot_date||'촬영일 미입력'} · 사진 ${item.file_count}장`;
  const badge=document.createElement('span');badge.className='tag '+(item.effective_disclosure==='공개'?'public':'private');badge.textContent=item.effective_disclosure||item.disclosure;
  info.append(title,sub,badge);card.append(img,info);grid.append(card);
 }
}
function changePhotoSearchCategory(){
 const field=$('#photo-search-category').value,isDate=field==='shot_date';
 $('#photo-search').hidden=isDate;$('#photo-date').hidden=!isDate;
 $('#photo-search').value='';$('#photo-date').value='';
 const hints={all:'사진명, 생산부서, 촬영장소, 주요 인물 검색',title:'사진명을 입력하세요',department:'생산부서를 입력하세요',people:'주요 인물의 이름이나 직위를 입력하세요'};
 $('#photo-search').placeholder=hints[field]||'검색어를 입력하세요';
 clearTimeout(loadPhotos.timer);loadPhotos().catch(e=>$('#photo-error').textContent=e.message);
}
function showPhotoFile(index){
 if(index<0||index>=photoFiles.length)return;photoIndex=index;
 const selected=photoFiles[index],img=$('#photo-large');
 clearTimeout(photoExpiryTimer);
 if(selected.grant_expires_at){const remaining=new Date(selected.grant_expires_at).getTime()-Date.now();
 if(remaining<=0){img.removeAttribute('src');$('#photo-position').textContent='열람기간이 만료되었습니다. 다시 신청해 주세요.';return}
 photoExpiryTimer=setTimeout(()=>showPhotoFile(photoIndex),Math.min(remaining+10,2147483647));}
 img.alt=selected.original_name+' 확대 열람';img.src=`/api/v2/photos/files/${selected.id}/view?wm=20261105v2`;
 $('#photo-position').textContent=`${index+1} / ${photoFiles.length} · ${selected.original_name}`;
 $('#photo-prev').disabled=index===0;$('#photo-next').disabled=index===photoFiles.length-1;
 $('#photo-file-tabs').querySelectorAll('button').forEach((button,i)=>button.classList.toggle('active',i===index));
}
async function showPhotoItem(id){
 const serial=++photoDetailSerial;clearTimeout(photoExpiryTimer);$('#photo-large').removeAttribute('src');
 const data=await api(`/api/v2/photos/items/${encodeURIComponent(id)}`),item=data.item,series=data.series;
 if(serial!==photoDetailSerial)return;
 currentPhoto={...item,effective_disclosure:data.effective_disclosure};photoFiles=data.files||[];photoIndex=0;
 $('#photo-apply').hidden=!data.requires_approval;
 $('#photo-access-note').textContent=data.requires_approval?(data.can_view?'승인된 사진만 표시합니다. 열람기간이 끝나면 다시 신청하세요.':'승인 전에는 사진을 표시하지 않습니다. 열람신청을 제출해 주세요.'):'공개 사진 · 즉시 열람 가능';
 $('#photo-dialog-title').textContent=item.title;
 $('#photo-detail-meta').innerHTML=[['기록물철명',series.title],['생산부서',series.department],['촬영일자',item.shot_date],['촬영장소',item.shot_place],['촬영자',item.photographer],['주요 인물·직위',item.people],['저작권·이용조건',item.rights],['공개구분',data.effective_disclosure],['사진 수량',(data.file_count||0)+'장 / 열람 가능 '+photoFiles.length+'장']].map(([k,v])=>field(k,v)).join('');
 $('#photo-detail-summary').textContent=item.summary||'내용요약이 등록되지 않았습니다.';
 const tabs=$('#photo-file-tabs');tabs.replaceChildren();
 for(const [i,f]of photoFiles.entries()){const button=document.createElement('button');button.type='button';button.textContent=`${i+1}. ${f.original_name}`;button.onclick=()=>showPhotoFile(i);tabs.append(button)}
 $('#photo-large').removeAttribute('src');
 $('#photo-dialog').showModal();
 if(photoFiles.length)showPhotoFile(0);
 else{$('#photo-large').alt=data.requires_approval?'열람 승인이 필요합니다.':'등록된 사진 파일이 없습니다.';$('#photo-position').textContent=data.requires_approval?'열람신청 후 승인된 사진만 표시됩니다.':'등록된 사진이 없습니다.';$('#photo-prev').disabled=true;$('#photo-next').disabled=true}
}

document.addEventListener('click',e=>{const close=e.target.closest('[data-close]');if(close){closeDialog(close.dataset.close);return}const menu=e.target.closest('[data-tab]');if(menu){setTab(menu.dataset.tab);return}const photo=e.target.closest('[data-photo-item]');if(photo){showPhotoItem(photo.dataset.photoItem).catch(err=>$('#photo-error').textContent=err.message);return}const d=e.target.closest('[data-detail]');if(d){showDetail(d.dataset.detail).catch(x=>alert(x.message));return}const req=e.target.closest('[data-request]');if(req){requestDialog(req.dataset.request);return}const pdf=e.target.closest('[data-pdf-public]');if(pdf){closeDialog('detail-dialog');pdfPublic(pdf.dataset.pdfPublic);return}const original=e.target.closest('[data-original]');if(original){pdfOriginal(original.dataset.original).catch(x=>alert(x.message));return}const approved=e.target.closest('[data-approved]');if(approved){pdfApproved(approved.dataset.approved)}});
$('#login-form').addEventListener('submit',async e=>{e.preventDefault();let f=new FormData(e.target);$('#message').textContent='';try{await api('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:f.get('username'),password:f.get('password')})});await start()}catch(err){$('#message').textContent=err.message}});
$('#search').oninput=refreshCatalogSearch;for(const filterId of ['search-category','type-filter','disclosure-filter','retention-filter']){document.getElementById(filterId).onchange=filterId==='search-category'?refreshCatalogSearch:drawCatalog;}$('#refresh').onclick=()=>loadCatalog().catch(e=>alert(e.message));$('#request-refresh').onclick=()=>loadRequests().catch(e=>alert(e.message));$('#apply-method').onchange=methodHelp;$('#apply-form').onsubmit=submitRequest;
$('#history-period').onchange=toggleHistoryCustom;
$('#history-form').onsubmit=e=>{e.preventDefault();historyPage=1;loadHistory()};
$('#history-prev').onclick=()=>{if(historyPage>1){historyPage--;loadHistory()}};
$('#history-next').onclick=()=>{if(historyPage<historyTotalPages){historyPage++;loadHistory()}};
$('#photo-refresh').onclick=()=>loadPhotos().catch(e=>$('#photo-error').textContent=e.message);
$('#photo-series').onchange=()=>loadPhotos().catch(e=>$('#photo-error').textContent=e.message);
$('#photo-search-category').onchange=changePhotoSearchCategory;
$('#photo-search').oninput=()=>{clearTimeout(loadPhotos.timer);loadPhotos.timer=setTimeout(()=>loadPhotos().catch(e=>$('#photo-error').textContent=e.message),320)};
$('#photo-date').onchange=()=>loadPhotos().catch(e=>$('#photo-error').textContent=e.message);
$('#photo-prev').onclick=()=>showPhotoFile(photoIndex-1);
$('#photo-next').onclick=()=>showPhotoFile(photoIndex+1);
$('#photo-dialog').addEventListener('close',()=>{$('#photo-large').removeAttribute('src');photoFiles=[]});
$('#photo-dialog').addEventListener('keydown',e=>{if(e.key==='ArrowLeft'){e.preventDefault();showPhotoFile(photoIndex-1)}else if(e.key==='ArrowRight'){e.preventDefault();showPhotoFile(photoIndex+1)}});
toggleHistoryCustom();
for(const id of ['detail-dialog','apply-dialog','pdf-dialog','photo-dialog']){const d=document.getElementById(id);d.onclick=e=>{if(e.target===d)closeDialog(id)}}
start();

function photoRequestDialog(){if(!currentPhoto)return;applyKind='photo';
 $('#apply-record-id').value=currentPhoto.id;$('#apply-record-title').textContent=currentPhoto.title+' · 시청각 사진';
 $('#apply-method').value='online';$('#apply-method').options[0].textContent='시청각 사진 온라인 열람';$('#apply-method').disabled=true;
 $('#apply-reason').value='';$('#apply-message').textContent='';methodHelp();closeDialog('photo-dialog');$('#apply-dialog').showModal();}
$('#photo-apply').onclick=photoRequestDialog;
$('#photo-large').onerror=()=>{$('#photo-large').removeAttribute('src');$('#photo-position').textContent='열람기간 만료 또는 사진 접근 불가 · 다시 조회하거나 신청해 주세요.'};
// Clear an already displayed protected image when its grant expires.
$('#photo-dialog').addEventListener('close',()=>clearTimeout(photoExpiryTimer));
