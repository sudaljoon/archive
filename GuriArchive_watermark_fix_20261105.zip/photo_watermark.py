"""Personalized in-memory photo derivatives. Never writes original or cached images."""
import datetime as dt
import io
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps, UnidentifiedImageError
import core

ASSETS = Path(__file__).resolve().parent / 'watermark_assets'
KST = dt.timezone(dt.timedelta(hours=9))
VERSION = '2026.11.05-v2'


def status():
    try:
        if not (ASSETS / 'GuriArchiveWatermarkSans.otf').is_file():
            raise OSError('Missing font')
        if not (core.STATIC_ROOT / 'logo.png').is_file():
            raise OSError('Missing logo')
        _font(13)
        _logo()
        return {'version': VERSION, 'ready': True}
    except (OSError, ValueError):
        return {'version': VERSION, 'ready': False}


def timestamp():
    return dt.datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S KST')


@lru_cache(maxsize=1)
def _logo():
    # Reuse the institution's existing transparent logo; alpha preserves its exact shape.
    with Image.open(core.STATIC_ROOT / 'logo.png') as im:
        alpha = im.convert('RGBA').getchannel('A')
        if alpha.getbbox() is None:
            raise OSError('Empty institution logo')
        return alpha.crop(alpha.getbbox())


@lru_cache(maxsize=48)
def _font(size):
    # Bundled font keeps Korean readable on Windows and Linux without font installation.
    return ImageFont.truetype(str(ASSETS / 'GuriArchiveWatermarkSans.otf'), size)


def render(path, user, viewed_at):
    """Append a readable identity strip to a bounded derivative; no EXIF or source writes."""
    try:
        with Image.open(path) as source:
            if source.width * source.height > 80_000_000:
                raise ValueError('Image exceeds supported size')
            image = ImageOps.exif_transpose(source).convert('RGB')
            image.thumbnail((1800, 1800), Image.Resampling.LANCZOS)
        width = max(640, image.width)
        font_size = max(13, min(26, width // 65))
        padding = max(16, width // 70)
        line_height = round(font_size * 1.5)
        footer_height = line_height * 3 + padding * 2
        canvas = Image.new('RGB', (width, image.height + footer_height), '#edf1f4')
        canvas.paste(image, ((width - image.width) // 2, 0))
        draw = ImageDraw.Draw(canvas)
        draw.rectangle((0, image.height, width, canvas.height), fill='#173754')
        alpha = _logo().copy()
        alpha.thumbnail((int(width * .33), footer_height - padding * 2), Image.Resampling.LANCZOS)
        alpha = alpha.point(lambda value: round(value * .84))
        canvas.paste('white', (padding, image.height + (footer_height - alpha.height) // 2), alpha)
        identity = str(user).replace('\r', ' ').replace('\n', ' ').replace('\x00', '')[:64]
        labels = (f'열람자 ID: {identity}', f'열람일시: {viewed_at}', '열람용 · 원본 다운로드 불가')
        text_x = int(width * .39)
        available = width - text_x - padding
        for line_no, label in enumerate(labels):
            size = font_size
            while size > 8 and draw.textlength(label, font=_font(size)) > available:
                size -= 1
            draw.text((text_x, image.height + padding + line_height * line_no), label,
                      font=_font(size), fill='white', stroke_width=0)
        out = io.BytesIO()
        canvas.save(out, 'JPEG', quality=87, optimize=True)
        return out.getvalue()
    except (OSError, ValueError, SyntaxError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        # Fail closed: never fall back to an unmarked response if assets or rendering fail.
        raise core.UserError('워터마크 생성에 실패했습니다. 로고·글꼴 및 사진 파일을 확인해 주세요.', 503) from exc
