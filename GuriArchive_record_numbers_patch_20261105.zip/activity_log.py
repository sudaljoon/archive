"""Read-only administrator audit trail for GuriArchive v2.7 pilot.
Never store password, cookies, tokens, request bodies, PDF contents or client-supplied IP headers.
Log timestamps are UTC; presentation converts to KST.
"""
import csv
import datetime as dt
import hashlib
import io
import json
import re
import secrets
import sqlite3
from urllib.parse import parse_qs, urlsplit
import core

TYPES={'접속이력','기록물 이용','관리자 작업','보안'}
EVENTS={'내부관리번호 부여','간행물 등록','간행물 수정','간행물 소장관리','간행물 송부관리','간행물 PDF 첨부','간행물 PDF 열람','시청각 상세정보 조회','시청각 이미지 열람','시청각 원본 다운로드','로그인 성공','로그인 실패','로그인 제한','로그아웃','세션 만료','세션 무효화','상세정보 조회','PDF 원문 열람','승인 PDF 열람','열람신청','열람 승인','열람 반려','온라인 열람 완료','실물 반출','실물 반납','자료 저장','기록물 등록','기록물 수정','실물 폐기','행정박물 변경','PDF 업로드','승인용 PDF 업로드','관리자 비밀번호 변경','계정 변경','권한 없는 접근','기타 작업'}
MY_EVENT_GROUPS={
    '접속':('로그인 성공','로그아웃','세션 만료','세션 무효화'),
    '조회':('상세정보 조회','시청각 상세정보 조회','시청각 이미지 열람','시청각 원본 다운로드'),
    'PDF':('PDF 원문 열람','승인 PDF 열람'),
    '신청':('열람신청',),
    '완료':('온라인 열람 완료',),
}

def ensure_tables(cfg):
    with core.dbconnect(cfg) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS activity_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL,
            category TEXT NOT NULL, event TEXT NOT NULL, username TEXT NOT NULL DEFAULT '',
            role TEXT NOT NULL DEFAULT '', ip TEXT NOT NULL DEFAULT '',
            session_ref TEXT NOT NULL DEFAULT '', target_type TEXT NOT NULL DEFAULT '',
            target_id TEXT NOT NULL DEFAULT '', target_title TEXT NOT NULL DEFAULT '',
            result TEXT NOT NULL DEFAULT '성공', detail TEXT NOT NULL DEFAULT '')''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_activity_when ON activity_events(at DESC)')
        db.execute('CREATE INDEX IF NOT EXISTS idx_activity_actor ON activity_events(username,at DESC)')
        db.execute('CREATE INDEX IF NOT EXISTS idx_activity_target ON activity_events(target_type,target_id,at DESC)')
        db.execute('''CREATE TABLE IF NOT EXISTS activity_sessions(
            session_ref TEXT PRIMARY KEY, username TEXT NOT NULL, role TEXT NOT NULL,
            login_at TEXT NOT NULL, last_at TEXT NOT NULL, logout_at TEXT NOT NULL DEFAULT '',
            reason TEXT NOT NULL DEFAULT '', ip TEXT NOT NULL DEFAULT '')''')

def _clean(x, limit=140):
    return str(x if x is not None else '').replace('\x00','').replace('\r',' ').replace('\n',' ').strip()[:limit]

def write(handler,category,event,*,ses=None,username=None,role=None,kind='',target='',title='',result='성공',detail='',db=None):
    """Use only after authorization and action; never turn a user operation into a failure if logging fails."""
    if category not in TYPES:category='관리자 작업'
    if event not in EVENTS:event='기타 작업'
    ses=ses if ses is not None else {}
    row=(core.now(),category,event,_clean(username if username is not None else ses.get('user',''),64),
         _clean(role if role is not None else ses.get('role',''),16),_clean(getattr(handler,'client_address',('',0))[0],64),
         _clean(ses.get('activity_ref',''),40),_clean(kind,32),_clean(target,100),_clean(title,180),
         _clean(result,20),_clean(detail,320))
    try:
        if db is not None:
            if row[6]:db.execute('UPDATE activity_sessions SET last_at=? WHERE session_ref=? AND logout_at=\'\'',(row[0],row[6]))
            db.execute('''INSERT INTO activity_events(at,category,event,username,role,ip,session_ref,target_type,target_id,target_title,result,detail)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',row)
        else:
            with core.dbconnect(handler.cfg) as conn:
                if row[6]:conn.execute('UPDATE activity_sessions SET last_at=? WHERE session_ref=? AND logout_at=\'\'',(row[0],row[6]))
                conn.execute('''INSERT INTO activity_events(at,category,event,username,role,ip,session_ref,target_type,target_id,target_title,result,detail)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',row)
    except (sqlite3.Error, OSError):
        import logging
        logging.exception('Activity audit write failure; investigate before production use')

def login(handler, ses):
    session_ref=secrets.token_hex(12)
    ses['activity_ref']=session_ref
    with core.dbconnect(handler.cfg) as db:
        t=core.now()
        db.execute('INSERT INTO activity_sessions(session_ref,username,role,login_at,last_at,ip) VALUES(?,?,?,?,?,?)',
                   (session_ref,ses['user'],ses['role'],t,t,handler.client_address[0]))
        write(handler,'접속이력','로그인 성공',ses=ses,db=db)

def logout(handler, ses, reason='로그아웃'):
    if not ses:return
    with core.dbconnect(handler.cfg) as db:
        ref=ses.get('activity_ref','')
        if ref:
            db.execute("UPDATE activity_sessions SET logout_at=?,reason=?,last_at=? WHERE session_ref=? AND logout_at=''",
                       (core.now(),reason,core.now(),ref))
        write(handler,'접속이력',reason if reason in ('로그아웃','세션 만료','세션 무효화') else '로그아웃',ses=ses,db=db)

def scan_expired(handler, token, ses):
    # Explicitly distinguish inferred expiry from deliberate logout.
    if ses and ses.get('activity_ref'):
        logout(handler,ses,'세션 만료')

def _query(handler):
    p=parse_qs(urlsplit(handler.path).query,keep_blank_values=False)
    def one(k,maxlen=100):return _clean(p.get(k,[''])[0],maxlen)
    start,end=one('from',10),one('to',10)
    for val in (start,end):
        if val:
            try:dt.date.fromisoformat(val)
            except ValueError:raise core.UserError('날짜 형식이 올바르지 않습니다.')
    if start and end and start>end:raise core.UserError('시작일이 종료일보다 늦습니다.')
    clauses=[]; args=[]
    # User-facing calendar dates follow Asia/Seoul (UTC+09:00), database timestamps UTC.
    kst=dt.timezone(dt.timedelta(hours=9))
    if start:
        begin=dt.datetime.combine(dt.date.fromisoformat(start),dt.time.min,tzinfo=kst).astimezone(dt.timezone.utc)
        clauses.append('at >= ?');args.append(begin.isoformat(timespec='seconds'))
    if end:
        finish=dt.datetime.combine(dt.date.fromisoformat(end)+dt.timedelta(days=1),dt.time.min,tzinfo=kst).astimezone(dt.timezone.utc)
        clauses.append('at < ?');args.append(finish.isoformat(timespec='seconds'))
    cat=one('category',20)
    if cat and cat not in TYPES:raise core.UserError('이력 구분이 잘못되었습니다.')
    if cat:clauses.append('category=?');args.append(cat)
    event=one('event',40)
    if event:clauses.append('event LIKE ?');args.append('%'+event+'%')
    actor=one('username',64)
    if actor:clauses.append('username LIKE ?');args.append('%'+actor+'%')
    ip=one('ip',64)
    if ip:clauses.append('ip LIKE ?');args.append('%'+ip+'%')
    target=one('target',100)
    if target:clauses.append('(target_id LIKE ? OR target_title LIKE ?)');args.extend(['%'+target+'%']*2)
    result=one('result',20)
    if result:clauses.append('result=?');args.append(result)
    where=' WHERE '+' AND '.join(clauses) if clauses else ''
    try:page=max(1,min(int(one('page',8) or '1'),100000))
    except ValueError:page=1
    return where,args,page

def records(handler,export=False):
    core.confirm_role(handler,'admin')
    where,args,page=_query(handler)
    with core.dbconnect(handler.cfg) as db:
        total=db.execute('SELECT COUNT(*) FROM activity_events'+where,args).fetchone()[0]
        limit=10000 if export else 100
        offset=0 if export else (page-1)*limit
        rows=[dict(r) for r in db.execute('SELECT * FROM activity_events'+where+' ORDER BY id DESC LIMIT ? OFFSET ?',args+[limit,offset])]
    if not export:return handler.json_out({'rows':rows,'total':total,'page':page,'page_size':limit})
    columns=[('at','일시(UTC)'),('category','구분'),('event','업무'),('username','계정'),('role','권한'),('ip','접속IP'),('session_ref','세션식별번호'),('target_type','대상유형'),('target_id','대상번호'),('target_title','기록물철명'),('result','결과'),('detail','비고')]
    output=io.StringIO(); writer=csv.writer(output)
    writer.writerow([label for _,label in columns])
    for r in rows:
        values=[]
        for k,_ in columns:
            val=str(r.get(k) or '')
            # CSV formula injection prevention for spreadsheet viewers.
            if val.lstrip().startswith(('=','+','-','@','\t','\r')):val="'"+val
            values.append(val)
        writer.writerow(values)
    handler.response_bytes(('\ufeff'+output.getvalue()).encode('utf-8'),ctype='text/csv; charset=utf-8',extra={'Content-Disposition':'attachment; filename="activity_history.csv"'})

def my_records(handler):
    """Paginated, read-only history of the authenticated employee only.

    Never accept an account name or role from the client. Do not expose other
    employees' events, sessions, IP addresses, or internal audit details.
    """
    ses=core.confirm_role(handler)
    if ses['role']!='viewer':
        raise core.UserError('직원 열람용 계정으로 접속해 주세요.',403)
    p=parse_qs(urlsplit(handler.path).query,keep_blank_values=True)
    def one(k,limit=80):return _clean(p.get(k,[''])[0],limit)
    kst=dt.timezone(dt.timedelta(hours=9))
    today=dt.datetime.now(kst).date()
    raw_start,raw_end=one('from',10),one('to',10)
    try:
        start=dt.date.fromisoformat(raw_start) if raw_start else today-dt.timedelta(days=29)
        end=dt.date.fromisoformat(raw_end) if raw_end else today
        if start>end or end.year>=9999:raise ValueError()
    except ValueError:
        raise core.UserError('조회기간을 올바르게 입력해 주세요.')
    begin=dt.datetime.combine(start,dt.time.min,tzinfo=kst).astimezone(dt.timezone.utc).isoformat(timespec='seconds')
    finish=dt.datetime.combine(end+dt.timedelta(days=1),dt.time.min,tzinfo=kst).astimezone(dt.timezone.utc).isoformat(timespec='seconds')
    group=one('type',16) or 'all'
    if group!='all' and group not in MY_EVENT_GROUPS:
        raise core.UserError('이용 구분이 올바르지 않습니다.')
    try:page=max(1,min(int(one('page',8) or '1'),100000))
    except ValueError:raise core.UserError('페이지 번호가 올바르지 않습니다.')
    keyword=one('q',80)
    all_events=tuple(e for group_events in MY_EVENT_GROUPS.values() for e in group_events)
    base=['username=?',"role='viewer'",'at>=?','at<?',
          'event IN ('+','.join('?' for _ in all_events)+')']
    base_args=[ses['user'],begin,finish,*all_events]
    if keyword:
        pattern='%'+keyword.replace('!','!!').replace('%','!%').replace('_','!_')+'%'
        base.append("(target_title LIKE ? ESCAPE '!' OR target_id LIKE ? ESCAPE '!')")
        base_args.extend((pattern,pattern))
    base_where=' WHERE '+' AND '.join(base)
    rows_where=base_where
    rows_args=list(base_args)
    if group!='all':
        events=MY_EVENT_GROUPS[group]
        rows_where+=' AND event IN ('+','.join('?' for _ in events)+')'
        rows_args.extend(events)
    page_size=30
    with core.dbconnect(handler.cfg) as db:
        totals={r['event']:r['n'] for r in db.execute(
            'SELECT event,COUNT(*) n FROM activity_events'+base_where+' GROUP BY event',base_args)}
        total=db.execute('SELECT COUNT(*) FROM activity_events'+rows_where,rows_args).fetchone()[0]
        rows=[dict(r) for r in db.execute(
            'SELECT at,event,target_id,target_title,result FROM activity_events'+rows_where+
            ' ORDER BY at DESC,id DESC LIMIT ? OFFSET ?',rows_args+[page_size,(page-1)*page_size])]
    summary={
        'record_views':sum(totals.get(e,0) for e in MY_EVENT_GROUPS['조회']),
        'pdf_views':sum(totals.get(e,0) for e in MY_EVENT_GROUPS['PDF']),
        'requests':sum(totals.get(e,0) for e in MY_EVENT_GROUPS['신청']),
    }
    return handler.json_out({'rows':rows,'total':total,'page':page,
                             'page_size':page_size,'summary':summary})

def sessions(handler):
    core.confirm_role(handler,'admin')
    with core.dbconnect(handler.cfg) as db:
        rows=[dict(r) for r in db.execute('SELECT username,role,login_at,last_at,logout_at,reason,ip FROM activity_sessions ORDER BY login_at DESC LIMIT 300')]
    handler.json_out({'sessions':rows})
