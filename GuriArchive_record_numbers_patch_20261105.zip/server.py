"""구리농수산물공사 서고관리 v2.0 — v1.8 UI 복원형 서버 시범판.

기존 core.py의 인증/SQLite 기본 모듈을 활용하며, 실제 기록물 데이터는
archive_state 테이블에서 관리합니다. 내부망 배포 전 보안/승인 필수.
"""
import base64
import datetime as dt
import io
import json
import logging
import re
import secrets
import sqlite3
import sys
import time
from pathlib import Path
from http.server import ThreadingHTTPServer
import core
import account_admin
import pdf_attachments
import access_requests
import activity_log
import pdf_ocr_search
import photo_records
import publications
import record_numbers

ROOT=core.ROOT
CONFIG_PATH=core.CONFIG_PATH
STATIC_ROOT=core.STATIC_ROOT
config=core.config
dbconnect=core.dbconnect
secure_hash=core.secure_hash
UserError=core.UserError
WRITE_LOCK=core.WRITE_LOCK

EMPTY={'version':1,'sample':False,'records':[],'loans':[],'inspections':[],'logs':[],'transfers':[],'artifacts':[]}
MAX_STATE=45_000_000

def initialize_db(cfg):
    core.initialize_db(cfg)
    account_admin.ensure_tables(cfg)
    pdf_attachments.ensure_tables(cfg)
    access_requests.ensure_tables(cfg)
    activity_log.ensure_tables(cfg)
    pdf_ocr_search.ensure_tables(cfg)
    photo_records.ensure_tables(cfg)
    publications.ensure_tables(cfg)
    record_numbers.ensure_tables(cfg)
    with dbconnect(cfg) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS archive_state (
            id INTEGER PRIMARY KEY CHECK(id=1), json_data TEXT NOT NULL,
            revision INTEGER NOT NULL, updated_at TEXT NOT NULL, updated_by TEXT NOT NULL)''')
        db.execute('''INSERT OR IGNORE INTO archive_state(id,json_data,revision,updated_at,updated_by)
                      VALUES(1,?,0,?,?)''',(json.dumps(EMPTY,ensure_ascii=False),core.now(),'system'))

def validate_state(doc,old,restore=False):
    if not isinstance(doc,dict) or doc.get('version')!=1: raise UserError('지원하지 않는 자료 형식입니다.')
    arrays=('records','artifacts','transfers','loans','inspections','logs')
    for a in arrays:
        if not isinstance(doc.get(a),list): raise UserError(a+' 목록이 올바르지 않습니다.')
    if sum(len(doc[x]) for x in arrays)>250_000: raise UserError('저장 항목 수 상한을 초과했습니다.')
    for k in ('records','artifacts'):
        ids=set()
        for item in doc[k]:
            if not isinstance(item,dict) or not isinstance(item.get('id'),str) or len(item['id'])>90:
                raise UserError(f'{k} 관리번호가 올바르지 않습니다.')
            if item['id'] in ids: raise UserError(f'{k} 관리번호 중복이 발견됐습니다.')
            ids.add(item['id'])
            if len(str(item.get('title','')))>400: raise UserError('기록물명 길이를 확인하세요.')
    record_ids={r['id'] for r in doc['records']}
    for l in doc['loans']:
        if not isinstance(l,dict) or l.get('recordId') not in record_ids: raise UserError('반출입 자료에 존재하지 않는 기록물번호가 있습니다.')
    for i in doc['inspections']:
        if not isinstance(i,dict) or i.get('recordId') not in record_ids: raise UserError('점검 자료에 존재하지 않는 기록물번호가 있습니다.')
    old_rec={r['id']:r for r in old['records']}
    new_rec={r['id']:r for r in doc['records']}
    if not restore:
        lost=set(old_rec)-set(new_rec)
        if lost: raise UserError('기존 기록물 정보를 임의로 삭제할 수 없습니다. 폐기 완료 상태로 관리하세요.')
        for rid,prev in old_rec.items():
            curr=new_rec[rid];old_ev=prev.get('evaluation') or {}; new_ev=curr.get('evaluation') or {}
            was_disposed=old_ev.get('decision')=='폐기 결정' and bool(old_ev.get('executedAt'))
            now_disposed=new_ev.get('decision')=='폐기 결정' and bool(new_ev.get('executedAt'))
            if was_disposed and curr!=prev:
                raise UserError('폐기 완료 기록물의 정보와 이력은 변경할 수 없습니다.')
            if new_ev.get('decision') and (new_ev != old_ev) and not restore and not was_disposed:
                if not all(new_ev.get(k) for k in ('decisionDate','committeeDoc','reviewer','reason')) or not all(new_ev.get(k) is True for k in ('opinionChecked','expertChecked','committeeChecked')):
                    raise UserError('심의일·문서번호·담당자·사유 및 법정 검토 확인항목을 확인하세요.')
            if now_disposed and not was_disposed:
                if old_ev.get('decision')!='폐기 결정':
                    raise UserError('폐기 결정이 기록된 후에만 실제 폐기를 완료할 수 있습니다.')
                if any(l['recordId']==rid and not l.get('returnDate') for l in doc['loans']):
                    raise UserError('반출 중인 기록물은 폐기 완료할 수 없습니다.')
                if not new_ev.get('executedAt') or not new_ev.get('executor') or not new_ev.get('executionDoc'):
                    raise UserError('폐기일·집행자·증빙문서 정보를 확인하세요.')
        # Items confirmed as transferred must remain linked to the record
        old_transfer={i.get('id'):i for b in old['transfers'] for i in b.get('items',[]) if isinstance(i,dict)}
        new_transfer={i.get('id'):i for b in doc['transfers'] for i in b.get('items',[]) if isinstance(i,dict)}
        for key,item in new_transfer.items():
            prev=old_transfer.get(key)
            if item.get('status')=='등록 완료' and (not prev or prev.get('status')!='등록 완료'):
                if not prev or prev.get('status')!='확인 완료' or not item.get('recordId') or item['recordId'] not in record_ids:
                    raise UserError('이관자료는 실물대조 완료 후에만 정식 등록할 수 있습니다.')
        for key,prev in old_transfer.items():
            if prev.get('status')=='등록 완료':
                now=new_transfer.get(key)
                if not now or now.get('recordId')!=prev.get('recordId') or now.get('status')!='등록 완료':
                    raise UserError('정식 등록된 이관 기록물과의 연결은 변경할 수 없습니다.')
    for item in doc['artifacts']:
        if item.get('photo') and len(str(item['photo']))>9_000_000:
            raise UserError('행정박물 이미지 크기가 너무 큽니다.')
    return doc

def process_artifact_photos(doc,cfg):
    """Extract newly uploaded Data URL photos to the server media path (DAS when configured)."""
    folder=Path(cfg['media_dir'])/'museum'
    for a in doc['artifacts']:
        photo=a.get('photo') or ''
        if not isinstance(photo,str): raise UserError('행정박물 사진 형식 오류')
        if not photo.startswith('data:'): continue
        if not photo.startswith(('data:image/jpeg;base64,','data:image/png;base64,','data:image/webp;base64,')):
            raise UserError('JPG·PNG·WEBP 이미지만 업로드할 수 있습니다.')
        try:
            from PIL import Image,ImageOps,UnidentifiedImageError
            raw=base64.b64decode(photo.split(',',1)[1],validate=True)
            if len(raw)>7_000_000: raise UserError('사진 크기는 최대 7MB입니다.')
            with Image.open(io.BytesIO(raw)) as im:
                if im.format not in ('JPEG','PNG','WEBP') or im.width*im.height>30_000_000:
                    raise UserError('지원하지 않는 이미지 또는 너무 큰 이미지입니다.')
                rgb=ImageOps.exif_transpose(im).convert('RGB')
                rgb.thumbnail((2400,2400))
                buf=io.BytesIO();rgb.save(buf,'WEBP',quality=86)
            folder.mkdir(parents=True,exist_ok=True)
            name=secrets.token_hex(20)+'.webp'
            (folder/name).write_bytes(buf.getvalue())
            a['photo']='/api/v2/photo/'+name
        except UserError:raise
        except Exception as e:
            raise UserError('행정박물 사진을 저장할 수 없습니다: '+str(e)[:150])

def stats_summary(before,after):
    x={r['id']:r for r in before['records']};y={r['id']:r for r in after['records']}
    new=len(set(y)-set(x));modified=sum(x[i]!=y[i] for i in set(x)&set(y))
    disposed=sum(bool(y[i].get('evaluation',{}).get('executedAt')) and not bool(x[i].get('evaluation',{}).get('executedAt')) for i in set(x)&set(y))
    return f'일반기록물 신규 {new}철 / 수정 {modified}철 / 실물폐기 {disposed}철 / 행정박물 {len(after["artifacts"])}건 / 이관 접수 {len(after["transfers"])}차수'

class FullArchiveHandler(core.ArchiveHandler):
    server_version='GuriArchives/2.5-pilot'
    def current_session(self):
        ses=super().current_session()
        if not account_admin.session_valid(self.cfg,ses):
            if ses and ses.get('activity_ref'):
                activity_log.logout(self,ses,'세션 무효화')
                # Remove the invalid in-process session to avoid repeated event logs.
                from http.cookies import SimpleCookie
                cookies=SimpleCookie()
                try:cookies.load(self.headers.get('Cookie',''))
                except Exception:pass
                token=cookies.get('guri_session')
                if token:core.ACTIVE_SESSIONS.pop(token.value,None)
            return None
        return ses

    def error_out(self,exc):
        if isinstance(exc,UserError) and exc.code in (401,403):
            path=self.path.split('?',1)[0]
            if path.startswith(('/api/','/manager','/accounts','/requests','/activity')):
                activity_log.write(self,'보안','권한 없는 접근',ses=self.current_session() or {},
                                   kind='route',target=path[:100],result='차단',detail=str(exc)[:100])
        return super().error_out(exc)

    def route_get(self):
        path=self.path.split('?',1)[0]
        if path=='/api/v2/record-numbers':return record_numbers.handler_get(self)
        if path in ('/publications','/publications.js','/publications.css'):
            core.confirm_role(self,'admin')
            name='publications.html' if path=='/publications' else path.lstrip('/')
            kind='text/html' if path=='/publications' else 'text/javascript' if path.endswith('.js') else 'text/css'
            return self.response_bytes((STATIC_ROOT/name).read_bytes(),ctype=kind+'; charset=utf-8')
        if path in ('/api/v2/publications','/api/v2/publications.csv'):
            return publications.listing(self,export=path.endswith('.csv'))
        pub=re.fullmatch(r'/api/v2/publications/([a-f0-9]{24})(?:/files/([a-f0-9]{32})/content)?',path)
        if pub:
            return publications.content(self,*pub.groups()) if pub.group(2) else publications.detail(self,pub.group(1))
        if path in ('/photos','/photos/public'):
            core.confirm_role(self,'admin' if path=='/photos' else 'viewer')
            return self.response_bytes((STATIC_ROOT/('photos.html' if path=='/photos' else 'index.html')).read_bytes(),ctype='text/html; charset=utf-8')
        if path=='/photos.js':
            core.confirm_role(self)
            return self.response_bytes((STATIC_ROOT/path.lstrip('/')).read_bytes(),ctype='text/javascript; charset=utf-8')
        if path=='/api/v2/photos/links':return photo_records.links(self)
        if path=='/api/v2/photos/classifications':return photo_records.classifications(self)
        if path=='/api/v2/photos':return photo_records.listing(self)
        match=re.fullmatch(r'/api/v2/photos/items/([a-f0-9]{24})',path)
        if match:return photo_records.detail(self,match.group(1))
        match=re.fullmatch(r'/api/v2/photos/files/([a-f0-9]{32})/(preview|view|original)',path)
        if match:return photo_records.image(self,match.group(1),preview=match.group(2)=='preview',view=match.group(2)=='view')
        if path=='/ocr':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'ocr.html').read_bytes(),ctype='text/html; charset=utf-8')
        if path=='/ocr.js':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'ocr.js').read_bytes(),ctype='text/javascript; charset=utf-8')
        if path=='/api/v2/ocr/files':return pdf_ocr_search.listing(self)
        if path=='/api/v2/ocr/search':return pdf_ocr_search.search(self)
        if path=='/activity':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'activity.html').read_bytes(),ctype='text/html; charset=utf-8')
        if path=='/activity.js':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'activity.js').read_bytes(),ctype='text/javascript; charset=utf-8')
        if path=='/api/v2/activity':return activity_log.records(self)
        if path=='/api/v2/activity.csv':return activity_log.records(self,export=True)
        if path=='/api/v2/activity/sessions':return activity_log.sessions(self)
        if path=='/api/v2/my-activity':return activity_log.my_records(self)
        if pdf_attachments.is_pdf_get_path(path):
            return pdf_attachments.handle_get(self, path)
        if path=='/api/v2/catalog':return access_requests.catalog(self)
        if path=='/api/v2/access-requests':return access_requests.listing(self)
        m=access_requests.REQUEST_RE.fullmatch(path)
        if m and m.group(1) and m.group(2):
            rid, action = m.group(1), m.group(2)
            if action=='approval-copy/content':
                return access_requests.approved_content(self,rid)
            if action=='photo-files':
                import photo_access
                return photo_access.options(self,rid)
            if action=='pdf-files':
                return access_requests.pdf_file_options(self,rid)
            if action=='original-pdfs':
                return access_requests.original_pdf_listing(self,rid)
            selected=re.fullmatch(r'original-pdfs/([a-f0-9]{32})/content',action)
            if selected:
                return access_requests.original_pdf_content(self,rid,selected.group(1))
        if path=='/requests':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'requests_admin.html').read_bytes(),ctype='text/html; charset=utf-8')
        if path=='/requests_admin.js':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'requests_admin.js').read_bytes(),ctype='text/javascript; charset=utf-8')
        if path.startswith('/api/v2/records/') and path.endswith('/detail'):
            import urllib.parse
            mr=re.fullmatch(r'/api/v2/records/([A-Za-z0-9_-]{1,90})/detail',path)
            if not mr:raise UserError('잘못된 기록물 주소입니다.',404)
            return access_requests.detail(self,mr.group(1))
        if path=='/':
            return self.response_bytes((STATIC_ROOT/'index.html').read_bytes(),ctype='text/html; charset=utf-8')
        if path in ('/portal.js','/portal.css'):
            return self.response_bytes((STATIC_ROOT/path.lstrip('/')).read_bytes(),ctype=('text/javascript' if path.endswith('.js') else 'text/css')+'; charset=utf-8')
        if path=='/accounts/admin':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'admin_account.html').read_bytes(),ctype='text/html; charset=utf-8')
        if path=='/accounts':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'accounts.html').read_bytes(),ctype='text/html; charset=utf-8')
        if path in ('/accounts.js','/accounts-logo.png','/admin-account.js'):
            core.confirm_role(self,'admin')
            name=path.lstrip('/')
            ctype='image/png' if path.endswith('.png') else 'text/javascript; charset=utf-8'
            return self.response_bytes((STATIC_ROOT/name).read_bytes(),ctype=ctype)
        if path=='/api/v2/accounts':
            return account_admin.list_viewers(self)
        if path=='/api/v2/admin-account':
            return account_admin.admin_profile(self)
        if path=='/manager':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'manager.html').read_bytes(),ctype='text/html; charset=utf-8')
        if path=='/manager.js':
            core.confirm_role(self,'admin')
            return self.response_bytes((STATIC_ROOT/'manager.js').read_bytes(),ctype='text/javascript; charset=utf-8')
        if path=='/api/v2/state':
            core.confirm_role(self,'admin')
            with dbconnect(self.cfg) as db:
                db.execute('BEGIN')
                row=db.execute('SELECT * FROM archive_state WHERE id=1').fetchone()
                doc=record_numbers.decorate(db,json.loads(row['json_data']))
                id_sequence=record_numbers.system_id_sequence(db,doc)
            return self.json_out({'data':doc,'revision':row['revision'],'recordIdSequence':id_sequence})
        if path=='/api/v2/public':
            core.confirm_role(self)
            with dbconnect(self.cfg) as db:
                row=db.execute('SELECT json_data,revision FROM archive_state WHERE id=1').fetchone()
                state=record_numbers.decorate(db,json.loads(row['json_data']))
            records=[]
            for r in state['records']:
                ev=r.get('evaluation') or {}
                if r.get('disclosure')!='공개' or (ev.get('decision')=='폐기 결정' and ev.get('executedAt')): continue
                records.append({k:r.get(k,'') for k in ('id','managementNo','legacyManagementNo','title','dept','series','year','retention','format','count','location','box','disclosure')})
            arts=[]
            for a in state['artifacts']:
                if a.get('disclosure')!='공개':continue
                arts.append({k:a.get(k,'') for k in ('id','title','dept','type','material','dimensions','productionDate','quantity','summary','location','disclosure','photo')})
            return self.json_out({'records':records,'artifacts':arts,'updated_at':row['revision']})
        if path.startswith('/api/v2/photo/'):
            core.confirm_role(self)
            name=path.rsplit('/',1)[-1]
            if not re.fullmatch(r'[a-f0-9]{40}\.webp',name): raise UserError('잘못된 사진 이름',404)
            with dbconnect(self.cfg) as db:
                row=db.execute('SELECT json_data FROM archive_state WHERE id=1').fetchone()
            state=json.loads(row['json_data'])
            ref='/api/v2/photo/'+name
            artifacts=[a for a in state['artifacts'] if a.get('photo')==ref]
            if not artifacts: raise UserError('사진을 찾을 수 없습니다.',404)
            ses=self.current_session()
            if ses['role']!='admin' and not any(a.get('disclosure')=='공개' for a in artifacts):
                raise UserError('열람 권한이 없습니다.',403)
            photo=Path(self.cfg['media_dir'])/'museum'/name
            if not photo.is_file(): raise UserError('원본 사진이 저장장치에 없습니다.',404)
            return self.response_bytes(photo.read_bytes(),ctype='image/webp')
        # Disable old v1.9 data endpoints; they use a different DB schema.
        if path.startswith('/api/') and path not in ('/api/session',): raise UserError('이전 버전 API는 사용할 수 없습니다.',404)
        return super().route_get()
    def route_put(self):
        path=self.path.split('?',1)[0]
        match=re.fullmatch(r'/api/v2/photos/(series|items)/([a-f0-9]{24})',path)
        if match:return photo_records.save(self,match.group(1),match.group(2))
        if path!='/api/v2/state': raise UserError('허용되지 않는 수정 요청입니다.',404)
        session=self.check_csrf()
        if session['role']!='admin':raise UserError('관리자만 자료를 저장할 수 있습니다.',403)
        if 'application/json' not in self.headers.get('Content-Type',''):
            raise UserError('JSON 요청만 지원합니다.')
        payload=json.loads(self.input_bytes(MAX_STATE))
        if not isinstance(payload,dict) or not isinstance(payload.get('revision'),int):
            raise UserError('저장 버전 정보가 없습니다.')
        obj=payload.get('data')
        with WRITE_LOCK,dbconnect(self.cfg) as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT * FROM archive_state WHERE id=1').fetchone()
            if payload['revision']!=row['revision']:
                raise UserError('다른 창에서 기록물이 변경됐습니다. 자료가 덮어써지지 않도록 저장을 중단했습니다. 다시 로그인하고 새로고침하세요.',409)
            prev=record_numbers.decorate(db,json.loads(row['json_data']))
            if payload.get('restore'):record_numbers.import_restore(db,obj,session['user'])
            if isinstance(obj,dict) and isinstance(obj.get('records'),list):record_numbers.decorate(db,obj,strict=True)
            validate_state(obj,prev,bool(payload.get('restore')))
            record_numbers.allocate_new(db,prev,obj,session['user'],restore=bool(payload.get('restore')))
            old_photos={a.get("id"):a.get("photo","") for a in obj["artifacts"]}
            process_artifact_photos(obj,self.cfg)
            photo_updates={a["id"]:a["photo"] for a in obj["artifacts"] if old_photos.get(a["id"],"")!=a.get("photo","")}
            info=stats_summary(prev,obj)
            revision=row['revision']+1
            db.execute('UPDATE archive_state SET json_data=?,revision=?,updated_at=?,updated_by=? WHERE id=1',
                       (json.dumps(obj,ensure_ascii=False,separators=(',',':')),revision,core.now(),session['user']))
            pdf_ocr_search.remove_nonpublic_index(db,obj)
            access_requests.sync_legacy_returns(db,obj,session['user'])
            core.audit(db,session['user'],'v2.0 기록물 데이터 저장','archive_state',1,info)
            activity_log.write(self,'관리자 작업','자료 저장',ses=session,kind='archive_state',target='1',detail=info,db=db)
            previous={r['id']:r for r in prev['records']}
            for rec in obj['records']:
                before=previous.get(rec['id'])
                if before is None:
                    event='기록물 등록'
                elif before!=rec:
                    event='실물 폐기' if not (before.get('evaluation') or {}).get('executedAt') and (rec.get('evaluation') or {}).get('executedAt') else '기록물 수정'
                else:continue
                activity_log.write(self,'관리자 작업',event,ses=session,kind='record',target=rec['id'],title=rec.get('title',''),db=db)
            id_sequence=record_numbers.system_id_sequence(db,obj)
            old_art={a['id']:a for a in prev['artifacts']}
            for art in obj['artifacts']:
                if old_art.get(art['id'])!=art:
                    activity_log.write(self,'관리자 작업','행정박물 변경',ses=session,kind='artifact',target=art['id'],title=art.get('title',''),db=db)
        # When a record changes from partial/private to public, its attachments
        # become eligible for automatic full-text search without a manual index job.
        try:
            pdf_ocr_search.queue_auto_index(self.cfg)
        except Exception:
            logging.exception('Could not schedule public PDF text extraction after record change')
        self.json_out({'ok':True,'revision':revision,'photos':photo_updates,'recordIdSequence':id_sequence,'managementNumbers':{r['id']:{k:r.get(k,'') for k in record_numbers.FIELDS} for r in obj['records']}})
    def route_post(self):
        path=self.path.split('?',1)[0]
        if path=='/api/v2/record-numbers/apply':return record_numbers.handler_apply(self)
        if path=='/api/v2/publications':return publications.save(self)
        pub=re.fullmatch(r'/api/v2/publications/([a-f0-9]{24})(?:/(copies|shipments|files)(?:/([a-f0-9]{24}))?)?',path)
        if pub:
            pid,kind,cid=pub.groups()
            if kind=='files' and not cid:return publications.upload(self,pid)
            if kind in ('copies','shipments'):return publications.child_save(self,pid,kind,cid)
            if not kind:return publications.save(self,pid)
        if path=='/api/v2/photos/links':return photo_records.links(self,update=True)
        batch=re.fullmatch(r'/api/v2/photos/series/([a-f0-9]{24})/batch',path)
        if batch:return photo_records.upload(self,series_id=batch.group(1))
        match=re.fullmatch(r'/api/v2/photos/items/([a-f0-9]{24})/files',path)
        if match:return photo_records.upload(self,match.group(1))
        if path=='/api/v2/photos/series':return photo_records.save(self,'series')
        if path=='/api/v2/photos/items':return photo_records.save(self,'items')
        if pdf_attachments.is_pdf_upload_path(path):
            return pdf_attachments.handle_upload(self, path)
        if path=='/api/v2/ocr/start':return pdf_ocr_search.start(self)
        if path=='/api/v2/access-requests':return access_requests.create(self)
        m=access_requests.REQUEST_RE.fullmatch(path)
        if m and m.group(1) and m.group(2):
            rid,action=m.groups()
            if action=='decision':return access_requests.decision(self,rid)
            if action=='approval-copy':return access_requests.approval_copy_upload(self,rid)
            if action=='issue':return access_requests.issue(self,rid)
            if action=='return':return access_requests.return_item(self,rid)
            if action=='complete':return access_requests.online_complete(self,rid)

        if path=='/api/login':
            return account_admin.login(self)
        if path=='/api/v2/admin-account/password':
            return account_admin.update_admin_password(self)
        if path in ('/api/v2/accounts/create','/api/v2/accounts/password','/api/v2/accounts/status'):
            return account_admin.admin_action(self,path)
        if path!='/api/logout':
            raise UserError('허용되지 않는 요청입니다.',404)
        ses=self.check_csrf()
        activity_log.logout(self,ses)
        return super().route_post()

def make_server(cfg=None,host=None,port=None):
    cfg=cfg or config(); initialize_db(cfg)
    web=ThreadingHTTPServer((host or cfg.get('bind','127.0.0.1'),int(port or cfg.get('port',8765))),FullArchiveHandler)
    web.cfg=cfg
    # Backfill attachments from older releases, and recover interrupted jobs.
    # This runs only on the administrator server, not the read-only viewer.
    try:
        pdf_ocr_search.queue_auto_index(cfg)
    except Exception:
        logging.exception('Automatic PDF OCR startup discovery failed; server still starts')
    return web

def main():
    logging.basicConfig(format='%(asctime)s %(levelname)s: %(message)s',level=logging.INFO)
    try:
        cfg=config();srv=make_server(cfg)
        print(f'GuriArchive v2.0: http://{srv.server_address[0]}:{srv.server_address[1]}')
        print('관리자 기능: 로그인 후 /manager / 종료: Ctrl+C')
        if cfg.get('bind') not in ('127.0.0.1','localhost'):
            print('경고: 외부 접속은 기관 보안승인, 계정정책, HTTPS 설정 이후에만 허용하세요.')
        srv.serve_forever(poll_interval=.5)
    except KeyboardInterrupt:print('서버 종료')
    except Exception as e:
        print('서버 시작 실패: '+str(e));sys.exit(1)
if __name__=='__main__':main()
